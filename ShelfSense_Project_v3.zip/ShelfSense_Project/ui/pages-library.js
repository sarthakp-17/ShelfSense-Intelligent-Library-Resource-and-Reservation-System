'use strict';
/* ===================================================================
   Dashboard, Book Management, Member Management
   =================================================================== */

// ---------------- shared validation (mirrors LibraryService; the engine re-checks) ----------------
const ID_RE = /^[A-Za-z0-9_-]{1,20}$/;
const noPipe = v => !v.includes('|');

function bookDialog(book) {
  const editing = !!book;
  const categories = [...new Set(state.books.map(b => b.category))].sort();
  formDialog({
    title: editing ? `Edit ${book.id}` : 'Add a book',
    submitLabel: editing ? 'Save changes' : 'Add book',
    fields: [
      { name: 'id', label: 'Book ID', value: editing ? book.id : '', disabled: editing, placeholder: 'e.g. B125', maxlength: 20, help: editing ? 'The ID cannot be changed.' : 'Letters, digits, - or _ (up to 20).' },
      { name: 'category', label: 'Category', value: editing ? book.category : '', list: categories, placeholder: 'e.g. Programming' },
      { name: 'title', label: 'Title', value: editing ? book.title : '', full: true },
      { name: 'author', label: 'Author', value: editing ? book.author : '', full: true },
    ],
    validate: v => {
      const e = {};
      if (!editing && !ID_RE.test(v.id)) e.id = 'Use 1-20 letters, digits, - or _.';
      else if (!editing && by.book.has(v.id)) e.id = `Book ID ${v.id} already exists.`;
      for (const k of ['title', 'author', 'category']) {
        if (!v[k]) e[k] = 'Required.';
        else if (!noPipe(v[k])) e[k] = 'The | character is not allowed.';
      }
      return e;
    },
    onSubmit: v => mutate(editing ? '/api/books/update' : '/api/books/add', { ...v, id: editing ? book.id : v.id }),
  });
}

function memberDialog(member) {
  const editing = !!member;
  formDialog({
    title: editing ? `Edit ${member.id}` : 'Register a member',
    submitLabel: editing ? 'Save changes' : 'Register member',
    fields: [
      { name: 'id', label: 'Member ID', value: editing ? member.id : '', disabled: editing, placeholder: 'e.g. M113', maxlength: 20, help: editing ? 'The ID cannot be changed.' : 'Letters, digits, - or _ (up to 20).' },
      { name: 'name', label: 'Full name', value: editing ? member.name : '' },
      { name: 'email', label: 'Email', value: editing ? member.email : '', optional: true, type: 'email' },
      { name: 'phone', label: 'Phone', value: editing ? member.phone : '', optional: true },
    ],
    validate: v => {
      const e = {};
      if (!editing && !ID_RE.test(v.id)) e.id = 'Use 1-20 letters, digits, - or _.';
      else if (!editing && by.member.has(v.id)) e.id = `Member ID ${v.id} already exists.`;
      if (!v.name) e.name = 'Required.';
      for (const k of ['name', 'email', 'phone']) if (!noPipe(v[k])) e[k] = 'The | character is not allowed.';
      if (v.email && !/^[^\s@]+@[^\s@]+$/.test(v.email)) e.email = 'Enter a valid email address or leave it empty.';
      if (v.phone && !/^[0-9+\- ]+$/.test(v.phone)) e.phone = 'Digits, spaces, + or - only.';
      return e;
    },
    onSubmit: v => mutate(editing ? '/api/members/update' : '/api/members/add', { ...v, id: editing ? member.id : v.id }),
  });
}

function bookDeleteBlock(b) {
  if (b.status !== 'Available') return `${b.id} is ${b.status.toLowerCase()}. Return it before deleting.`;
  if (b.queue > 0) return `${b.id} has ${plural(b.queue, 'reservation')}. Cancel them before deleting.`;
  return '';
}
function memberDeleteBlock(m) {
  if (m.activeLoans > 0) return `${m.name} has ${plural(m.activeLoans, 'book')} on loan.`;
  if (m.pending > 0) return `${m.name} has ${plural(m.pending, 'pending reservation')}.`;
  return '';
}
async function deleteBook(b) {
  const ok = await confirmDialog({ title: 'Delete this book?', message: `<b>${esc(b.title)}</b> (${esc(b.id)}) will be removed from the catalogue. Its past loans stay in the borrowing records.`, confirmLabel: 'Delete book', danger: true });
  if (ok) { await mutate('/api/books/delete', { id: b.id }); if (drawerClose) drawerClose(); }
}
async function deleteMember(m) {
  const ok = await confirmDialog({ title: 'Delete this member?', message: `<b>${esc(m.name)}</b> (${esc(m.id)}) will be removed. Their past loans stay in the borrowing records.`, confirmLabel: 'Delete member', danger: true });
  if (ok) { await mutate('/api/members/delete', { id: m.id }); if (drawerClose) drawerClose(); }
}

// ---------------- detail drawers ----------------
function openBookDrawer(id) {
  const b = by.book.get(id);
  if (!b) return;
  const loans = state.records.filter(r => r.bookId === id).reverse();
  const queue = by.queue.get(id) || [];
  const active = by.active.get(id);
  const block = bookDeleteBlock(b);
  const head = `<div class="row" style="margin-bottom:8px">${spine(b.id)}${statusPill(b.status)}</div><div class="detail-title">${esc(b.title)}</div><div class="muted">${esc(b.author)}</div>`;
  const body = `
    <div class="drawer-section"><dl class="kv">
      <dt>Category</dt><dd>${esc(b.category)}</dd>
      <dt>Times issued</dt><dd class="num">${b.timesIssued}</dd>
      ${active ? `<dt>Borrower</dt><dd>${esc(memberName(active.memberId))} <span class="member-tag">${esc(active.memberId)}</span></dd>
      <dt>Issued on</dt><dd>${fmtDate(active.issueDate)}</dd><dt>Due</dt><dd>${fmtDate(active.dueDate)} ${duePill(active.daysLeft)}</dd>` : ''}
    </dl></div>
    <div class="drawer-section row wrap">
      ${b.status === 'Available' ? `<button class="btn primary sm" data-act="issue">${icon('issue', 'sm')}Issue this book</button>` : `<button class="btn primary sm" data-act="reserve">${icon('bookmark', 'sm')}Reserve</button>`}
      ${active ? `<button class="btn sm" data-act="return">${icon('ret', 'sm')}Return</button>` : ''}
      <button class="btn sm" data-act="edit">${icon('edit', 'sm')}Edit</button>
      <button class="btn sm" data-act="delete" ${block ? `aria-disabled="true" title="${esc(block)}"` : ''}>${icon('trash', 'sm')}Delete</button>
    </div>
    <div class="drawer-section"><h3>Reservation queue</h3>
      ${queue.length ? `<div class="queue-card"><ol>${queue.map(q => `<li><span class="pos ${q.position === 1 ? 'first' : ''}">${q.position}</span><div style="flex:1"><b>${esc(memberName(q.memberId))}</b> <span class="member-tag">${esc(q.memberId)}</span><div class="small muted">Reserved ${fmtDate(q.date)}</div></div></li>`).join('')}</ol></div>`
      : `<p class="muted small">Nobody is waiting for this book.</p>`}
    </div>
    <div class="drawer-section"><h3>Loan history</h3>
      ${loans.length ? tableHTML([
        { key: 'm', label: 'Member', render: r => `${esc(memberName(r.memberId))}<div class="sub">${esc(r.memberId)}</div>` },
        { key: 'i', label: 'Issued', render: r => `<span class="nowrap">${fmtDate(r.issueDate)}</span>` },
        { key: 'd', label: 'Due', render: r => `<span class="nowrap">${fmtDate(r.dueDate)}</span>` },
        { key: 's', label: 'Status', render: r => r.status === 'Issued' ? duePill(r.daysLeft) : `<span class="pill grey plain">Returned${r.fine > 0 ? ', ' + money(r.fine) : ''}</span>` },
      ], loans) : `<p class="muted small">This book has not been issued yet.</p>`}
    </div>`;
  openDrawer(head, body, (d, close) => {
    const act = (name, fn) => { const el = d.querySelector(`[data-act="${name}"]`); if (el) el.onclick = fn; };
    act('issue', () => { close(); go('circulation', { tab: 'issue', book: b.id }); });
    act('reserve', () => { close(); go('reservations', { book: b.id }); });
    act('return', () => { close(); go('circulation', { tab: 'return', book: b.id }); });
    act('edit', () => bookDialog(b));
    act('delete', () => deleteBook(b));
  });
}

function openMemberDrawer(id) {
  const m = by.member.get(id);
  if (!m) return;
  const current = state.records.filter(r => r.memberId === id && r.status === 'Issued').sort((a, b) => a.daysLeft - b.daysLeft);
  const past = state.records.filter(r => r.memberId === id && r.status !== 'Issued').reverse();
  const reservations = state.queue.filter(q => q.memberId === id);
  const block = memberDeleteBlock(m);
  const head = `<div class="row" style="margin-bottom:6px"><span class="member-tag">${esc(m.id)}</span>${m.overdue ? `<span class="pill bad">${plural(m.overdue, 'overdue book')}</span>` : ''}</div><div class="detail-title">${esc(m.name)}</div>`;
  const body = `
    <div class="drawer-section"><dl class="kv">
      <dt>Email</dt><dd>${esc(m.email) || '<span class="faint">Not given</span>'}</dd>
      <dt>Phone</dt><dd>${esc(m.phone) || '<span class="faint">Not given</span>'}</dd>
      <dt>Total loans</dt><dd class="num">${m.totalBorrows}</dd>
      <dt>Fines recorded</dt><dd class="num">${money(m.fines)}</dd>
    </dl></div>
    <div class="drawer-section row wrap">
      <button class="btn primary sm" data-act="issue">${icon('issue', 'sm')}Issue a book</button>
      <button class="btn sm" data-act="edit">${icon('edit', 'sm')}Edit</button>
      <button class="btn sm" data-act="delete" ${block ? `aria-disabled="true" title="${esc(block)}"` : ''}>${icon('trash', 'sm')}Delete</button>
    </div>
    ${block ? `<p class="small muted" style="margin-top:-12px">${esc(block)} Members can be deleted once they have no loans or reservations.</p>` : ''}
    <div class="drawer-section"><h3>Books on loan (${current.length})</h3>
      ${current.length ? `<ul class="feed panel">${current.map(r => `<li><div class="fi ${r.daysLeft < 0 ? 'bad' : 'blue'}">${icon('book', 'sm')}</div><div class="fb"><div class="ft">${esc(bookTitle(r.bookId))}</div><div class="fm">${esc(r.bookId)}, due ${fmtDate(r.dueDate)}</div></div><div class="fr">${duePill(r.daysLeft)}${r.estFine > 0 ? `<div class="small muted" style="margin-top:3px">${money(r.estFine)} so far</div>` : ''}</div></li>`).join('')}</ul>`
      : `<p class="muted small">No books on loan.</p>`}
    </div>
    <div class="drawer-section"><h3>Reservations (${reservations.length})</h3>
      ${reservations.length ? `<ul class="feed panel">${reservations.map(q => `<li><div class="pos ${q.position === 1 ? 'first' : ''}">${q.position}</div><div class="fb"><div class="ft">${esc(bookTitle(q.bookId))}</div><div class="fm">Position ${q.position} in the queue, reserved ${fmtDate(q.date)}</div></div></li>`).join('')}</ul>`
      : `<p class="muted small">No pending reservations.</p>`}
    </div>
    <div class="drawer-section"><h3>Returned books (${past.length})</h3>
      ${past.length ? tableHTML([
        { key: 'b', label: 'Book', render: r => `${esc(bookTitle(r.bookId))}<div class="sub">${esc(r.bookId)}</div>` },
        { key: 'i', label: 'Issued', render: r => `<span class="nowrap">${fmtDate(r.issueDate)}</span>` },
        { key: 'f', label: 'Fine', cls: 'num', render: r => r.fine > 0 ? money(r.fine) : '<span class="faint">None</span>' },
      ], past) : `<p class="muted small">No returned books yet.</p>`}
    </div>`;
  openDrawer(head, body, (d, close) => {
    d.querySelector('[data-act="issue"]').onclick = () => { close(); go('circulation', { tab: 'issue', member: m.id }); };
    d.querySelector('[data-act="edit"]').onclick = () => memberDialog(m);
    d.querySelector('[data-act="delete"]').onclick = () => deleteMember(m);
  });
}

// =================================================================
// Dashboard
// =================================================================
PAGES.dashboard = {
  title: 'Dashboard',
  build(root) {
    const s = state.stats;
    const t = new Date(dayNum(state.today) * 86400000);
    const weekday = t.toLocaleDateString('en-GB', { weekday: 'long', timeZone: 'UTC' });
    root.innerHTML = `
      ${pageHead('Dashboard', `${weekday}, ${fmtDate(state.today)}`, `<div class="search" style="width:340px">${icon('search')}<input class="input" id="quickSearch" placeholder="Find a book by ID, title or author"><span class="kbd">Ctrl K</span></div>`)}
      ${warningsBanner()}
      <section class="desk" aria-label="Library totals">
        ${deskItem('books', 'Total books', s.totalBooks, `${plural(new Set(state.books.map(b => b.category)).size, 'category', 'categories')}`)}
        ${deskItem('books?status=Available', 'Available', s.available, s.totalBooks ? `${Math.round(s.available / s.totalBooks * 100)}% of the catalogue` : 'No books yet', '#3DBE83')}
        ${deskItem('circulation', 'Issued', s.issued, s.dueSoon ? `${s.dueSoon} due within ${plural(state.settings.dueSoonDays, 'day')}` : 'None due soon', '#5B8EF5')}
        ${deskItem('members', 'Registered members', s.members, `${state.members.filter(m => m.activeLoans > 0).length} with books on loan`)}
        ${deskItem('reservations', 'Pending reservations', s.pendingReservations, `${by.queue.size} ${by.queue.size === 1 ? 'book has' : 'books have'} a queue`, '#9A90F4')}
        ${deskItem('due?tab=overdue', 'Overdue', s.overdue, s.overdue ? `${money(s.finesAccruing)} in fines so far` : 'Nothing overdue', '#FF8A7A', s.overdue > 0)}
      </section>
      <section class="quick" aria-label="Quick actions">
        <button data-q="addBook"><span class="qi">${icon('bookPlus')}</span><span><div class="qt">Add book</div><div class="qs">New catalogue entry</div></span></button>
        <button data-q="issue"><span class="qi">${icon('issue')}</span><span><div class="qt">Issue book</div><div class="qs">Lend to a member</div></span></button>
        <button data-q="return"><span class="qi">${icon('ret')}</span><span><div class="qt">Return book</div><div class="qs">Fines worked out for you</div></span></button>
        <button data-q="member"><span class="qi">${icon('userPlus')}</span><span><div class="qt">Register member</div><div class="qs">New student or staff</div></span></button>
      </section>
      <div class="grid two" style="margin-bottom:18px">${overduePanel()}${upcomingPanel()}</div>
      <div class="grid three">${recentPanel('Recently issued', ['ISSUE', 'AUTO_ISSUE'], 'issue', 'blue', 'No books have been issued yet.')}${recentPanel('Recent returns', ['RETURN'], 'ret', 'ok', 'No books have been returned yet.')}${recentlyAddedPanel()}</div>`;

    $$('.desk button', root).forEach(b => b.onclick = () => { const [p, q] = b.dataset.go.split('?'); go(p, q ? Object.fromEntries(new URLSearchParams(q)) : undefined); });
    const qs = $('#quickSearch', root);
    qs.addEventListener('keydown', e => { if (e.key === 'Enter') go('search', { q: qs.value.trim() }); });
    $('[data-q="addBook"]', root).onclick = () => bookDialog();
    $('[data-q="issue"]', root).onclick = () => go('circulation', { tab: 'issue' });
    $('[data-q="return"]', root).onclick = () => go('circulation', { tab: 'return' });
    $('[data-q="member"]', root).onclick = () => memberDialog();
    $$('li[data-book]', root).forEach(li => li.onclick = () => li.dataset.return ? go('circulation', { tab: 'return', book: li.dataset.book }) : openBookDrawer(li.dataset.book));
  },
};

function deskItem(target, label, value, detail, flag, alert) {
  return `<button data-go="${target}"><div class="k">${flag ? `<span class="flag" style="background:${flag}"></span>` : ''}${esc(label)}</div><div class="v ${alert ? 'alert' : ''}">${value}</div><div class="d">${esc(detail)}</div></button>`;
}

function overduePanel() {
  const rows = state.dueOrder.filter(d => d.daysLeft < 0);
  const items = rows.slice(0, 6).map(d => {
    const rec = by.active.get(d.bookId);
    return `<li class="clickable" data-book="${esc(d.bookId)}" data-return="1" title="Open the return form for this book">
      <div class="fi bad">${icon('alert', 'sm')}</div>
      <div class="fb"><div class="ft">${esc(bookTitle(d.bookId))}</div><div class="fm">${esc(memberName(d.memberId))} (${esc(d.memberId)}), due ${fmtDate(d.dueDate)}</div></div>
      <div class="fr"><span class="pill bad">${plural(-d.daysLeft, 'day')} late</span><div class="small muted" style="margin-top:4px">${money(rec ? rec.estFine : 0)}</div></div></li>`;
  }).join('');
  return `<section class="panel"><div class="panel-head"><h2>Overdue notifications</h2>${rows.length > 6 ? `<button class="link small" onclick="go('due',{tab:'overdue'})">View all ${rows.length}</button>` : `<span class="hint">Select one to return it</span>`}</div>
    <div class="panel-body flush">${items ? `<ul class="feed">${items}</ul>` : emptyState({ iconName: 'check', title: 'Nothing is overdue', text: 'Every book on loan is within its due date.', compact: true })}</div></section>`;
}

function upcomingPanel() {
  const rows = state.dueOrder.filter(d => d.daysLeft >= 0).slice(0, 6);
  const items = rows.map(d => `<li class="clickable" data-book="${esc(d.bookId)}">
      <div class="fi ${d.daysLeft <= state.settings.dueSoonDays ? 'warn' : ''}">${icon('calendar', 'sm')}</div>
      <div class="fb"><div class="ft">${esc(bookTitle(d.bookId))}</div><div class="fm">${esc(memberName(d.memberId))}, due ${fmtDate(d.dueDate)}</div></div>
      <div class="fr">${duePill(d.daysLeft)}</div></li>`).join('');
  return `<section class="panel"><div class="panel-head"><h2>Upcoming due dates</h2><span class="hint">Earliest first, from the due-date min-heap</span></div>
    <div class="panel-body flush">${items ? `<ul class="feed">${items}</ul>` : emptyState({ iconName: 'calendar', title: 'No upcoming due dates', text: 'Books you issue will appear here in due-date order.', compact: true })}</div></section>`;
}

function recentPanel(title, types, ic, tone, emptyText) {
  const rows = state.transactions.filter(t => types.includes(t.type)).slice(0, 5);
  const items = rows.map(t => `<li class="clickable" data-book="${esc(t.bookId)}">
      <div class="fi ${tone}">${icon(ic, 'sm')}</div>
      <div class="fb"><div class="ft">${esc(bookTitle(t.bookId))}</div><div class="fm">${esc(memberName(t.memberId))}${t.type === 'AUTO_ISSUE' ? ', from the reservation queue' : ''}</div></div>
      <div class="fr muted nowrap">${fmtDate((t.time || '').split(' ')[0])}</div></li>`).join('');
  return `<section class="panel"><div class="panel-head"><h2>${esc(title)}</h2></div>
    <div class="panel-body flush">${items ? `<ul class="feed">${items}</ul>` : emptyState({ iconName: ic, title: emptyText, compact: true })}</div></section>`;
}

function recentlyAddedPanel() {
  // New books are appended at the tail of the BookLinkedList, so the last nodes are the newest.
  const added = new Map();
  for (const t of state.transactions) if (t.type === 'ADD_BOOK' && !added.has(t.bookId)) added.set(t.bookId, t.time);
  const rows = state.books.slice(-5).reverse();
  const items = rows.map(b => `<li class="clickable" data-book="${esc(b.id)}">
      <div class="fi">${icon('book', 'sm')}</div>
      <div class="fb"><div class="ft">${esc(b.title)}</div><div class="fm">${esc(b.author)}</div></div>
      <div class="fr muted nowrap">${added.has(b.id) ? fmtDate(added.get(b.id).split(' ')[0]) : spine(b.id)}</div></li>`).join('');
  return `<section class="panel"><div class="panel-head"><h2>Recently added books</h2></div>
    <div class="panel-body flush">${items ? `<ul class="feed">${items}</ul>` : emptyState({ iconName: 'book', title: 'The catalogue is empty', text: 'Add your first book to get started.', compact: true, action: `<button class="btn primary sm" onclick="bookDialog()">${icon('plus', 'sm')}Add book</button>` })}</div></section>`;
}

// =================================================================
// Book Management (search + sort run in the C++ engine)
// =================================================================
ui.books = { q: '', field: 'all', status: '', sortKey: 'id', sortDir: 'asc' };

PAGES.books = {
  title: 'Book Management',
  build(root, params) {
    const v = ui.books;
    if (params.has('status')) v.status = params.get('status');
    root.innerHTML = `
      ${pageHead('Book Management', 'Add, edit and remove books in the catalogue.', `<button class="btn primary" id="addBook">${icon('plus')}Add book</button>`)}
      <section class="panel">
        <div class="toolbar">
          <div class="search">${icon('search')}<input class="input" id="bq" placeholder="Search by book ID, title or author" value="${esc(v.q)}"></div>
          <select class="input" id="bfield" style="width:150px" aria-label="Search in">
            ${[['all', 'All fields'], ['id', 'Book ID'], ['title', 'Title'], ['author', 'Author']].map(([k, l]) => `<option value="${k}" ${v.field === k ? 'selected' : ''}>${l}</option>`).join('')}
          </select>
          <div class="seg" id="bstatus"></div>
          <span class="spacer"></span>
          <label class="small muted" for="bsort">Sort by</label>
          <select class="input" id="bsort" style="width:130px">
            ${[['id', 'Book ID'], ['title', 'Title'], ['author', 'Author'], ['category', 'Category']].map(([k, l]) => `<option value="${k}" ${v.sortKey === k ? 'selected' : ''}>${l}</option>`).join('')}
          </select>
          <button class="icon-btn" id="bdir" title="Reverse order">${icon(v.sortDir === 'desc' ? 'arrowDown' : 'arrowUp')}</button>
        </div>
        <div id="btable"></div>
        <div class="table-foot" id="bfoot"></div>
      </section>`;
    $('#addBook').onclick = () => bookDialog();
    const run = debounce(() => this.update(root), 120);
    $('#bq').addEventListener('input', e => { v.q = e.target.value; run(); });
    $('#bfield').onchange = e => { v.field = e.target.value; this.update(root); };
    $('#bsort').onchange = e => { v.sortKey = e.target.value; this.update(root); };
    $('#bdir').onclick = () => { v.sortDir = v.sortDir === 'asc' ? 'desc' : 'asc'; $('#bdir').innerHTML = icon(v.sortDir === 'desc' ? 'arrowDown' : 'arrowUp'); this.update(root); };
    this.update(root);
  },
  async update(root) {
    const v = ui.books;
    const counts = { '': state.books.length, Available: state.stats.available, Issued: state.stats.issued, Reserved: state.stats.reserved };
    $('#bstatus', root).innerHTML = [['', 'All'], ['Available', 'Available'], ['Issued', 'Issued'], ['Reserved', 'Reserved']]
      .map(([k, l]) => `<button class="${v.status === k ? 'on' : ''}" data-s="${k}">${l}<span class="c">${counts[k]}</span></button>`).join('');
    $$('#bstatus button', root).forEach(b => b.onclick = () => { v.status = b.dataset.s; this.update(root); });

    let res;
    try { res = await apiGet('/api/search', { entity: 'books', q: v.q, field: v.field, status: v.status, sort: v.sortKey, dir: v.sortDir }); }
    catch (e) { toast(e.message, 'bad'); return; }
    if (currentPage !== 'books') return;
    const rows = res.ids.map(id => by.book.get(id)).filter(Boolean);
    const columns = [
      { key: 'id', label: 'Book ID', sort: 1, render: b => spine(b.id) },
      { key: 'title', label: 'Title', sort: 1, render: b => `<div class="title-cell">${esc(b.title)}</div><div class="sub">${esc(b.category)}</div>` },
      { key: 'author', label: 'Author', sort: 1, render: b => esc(b.author) },
      { key: 'status', label: 'Status', render: b => { const late = b.due && dayNum(b.due) < dayNum(state.today); return `${statusPill(b.status)}${b.borrower ? `<div class="sub" ${late ? 'style="color:var(--bad)"' : ''}>${esc(memberName(b.borrower))}, ${late ? 'overdue since' : 'due'} ${fmtDate(b.due)}</div>` : ''}`; } },
      { key: 'queue', label: 'Queue', cls: 'num', render: b => b.queue ? `<span class="pill res plain">${b.queue} waiting</span>` : '<span class="faint">None</span>' },
      { key: 'actions', label: 'Actions', cls: 'actions', render: b => {
        const block = bookDeleteBlock(b);
        return `<button class="icon-btn" data-view="${esc(b.id)}" title="View details">${icon('eye')}</button><button class="icon-btn" data-edit="${esc(b.id)}" title="Edit">${icon('edit')}</button><button class="icon-btn bad" data-del="${esc(b.id)}" title="${esc(block || 'Delete')}" ${block ? 'disabled' : ''}>${icon('trash')}</button>`;
      } },
    ];
    const empty = state.books.length
      ? emptyState({ iconName: 'search', title: 'No books match', text: 'Try another word, search all fields, or clear the status filter.', action: `<button class="btn sm" id="bclear">Clear search and filters</button>` })
      : emptyState({ iconName: 'book', title: 'No books in the catalogue yet', text: 'Books you add are stored in the BookLinkedList and saved to books.txt.', action: `<button class="btn primary" onclick="bookDialog()">${icon('plus')}Add your first book</button>` });
    const box = $('#btable', root);
    box.innerHTML = tableHTML(columns, rows, v, { empty, rowAttr: b => `class="clickable" data-row="${esc(b.id)}"` });
    bindSort(box, v, () => { $('#bsort', root).value = v.sortKey; $('#bdir', root).innerHTML = icon(v.sortDir === 'desc' ? 'arrowDown' : 'arrowUp'); this.update(root); });
    $$('[data-row]', box).forEach(tr => tr.onclick = e => { if (!e.target.closest('button')) openBookDrawer(tr.dataset.row); });
    $$('[data-view]', box).forEach(b => b.onclick = () => openBookDrawer(b.dataset.view));
    $$('[data-edit]', box).forEach(b => b.onclick = () => bookDialog(by.book.get(b.dataset.edit)));
    $$('[data-del]', box).forEach(b => b.onclick = () => deleteBook(by.book.get(b.dataset.del)));
    const clear = $('#bclear', box);
    if (clear) clear.onclick = () => { Object.assign(v, { q: '', field: 'all', status: '' }); this.build(root, new URLSearchParams()); };
    const sortNames = { id: 'book ID', title: 'title', author: 'author', category: 'category' };
    $('#bfoot', root).innerHTML = `<span>${rows.length} of ${plural(state.books.length, 'book')} shown</span><span>Linear search checked ${plural(res.linearComparisons, 'record')}; merge sort ordered the results by ${sortNames[v.sortKey]}.${res.exactId ? ` Exact ID ${esc(res.exactId)} found by binary search in ${plural(res.binaryComparisons, 'comparison')}.` : ''}</span>`;
  },
};

// =================================================================
// Member Management
// =================================================================
ui.members = { q: '', filter: 'all', sortKey: 'id', sortDir: 'asc' };

PAGES.members = {
  title: 'Member Management',
  build(root) {
    const v = ui.members;
    root.innerHTML = `
      ${pageHead('Member Management', 'Register members and see what each one has borrowed or reserved.', `<button class="btn primary" id="addMember">${icon('userPlus')}Register member</button>`)}
      <section class="panel">
        <div class="toolbar">
          <div class="search">${icon('search')}<input class="input" id="mq" placeholder="Search by member ID, name or email" value="${esc(v.q)}"></div>
          <div class="seg" id="mfilter"></div>
        </div>
        <div id="mtable"></div>
        <div class="table-foot" id="mfoot"></div>
      </section>`;
    $('#addMember').onclick = () => memberDialog();
    const run = debounce(() => this.update(root), 120);
    $('#mq').addEventListener('input', e => { v.q = e.target.value; run(); });
    this.update(root);
  },
  async update(root) {
    const v = ui.members;
    const filters = [
      ['all', 'All', () => true],
      ['loans', 'With books on loan', m => m.activeLoans > 0],
      ['overdue', 'With overdue books', m => m.overdue > 0],
      ['reserved', 'With reservations', m => m.pending > 0],
    ];
    $('#mfilter', root).innerHTML = filters.map(([k, l, f]) => `<button class="${v.filter === k ? 'on' : ''}" data-f="${k}">${l}<span class="c">${state.members.filter(f).length}</span></button>`).join('');
    $$('#mfilter button', root).forEach(b => b.onclick = () => { v.filter = b.dataset.f; this.update(root); });

    let res;
    try { res = await apiGet('/api/search', { entity: 'members', q: v.q, field: 'all', sort: v.sortKey, dir: v.sortDir }); }
    catch (e) { toast(e.message, 'bad'); return; }
    if (currentPage !== 'members') return;
    const keep = filters.find(f => f[0] === v.filter)[2];
    const rows = res.ids.map(id => by.member.get(id)).filter(m => m && keep(m));
    const columns = [
      { key: 'id', label: 'Member ID', sort: 1, render: m => `<span class="member-tag">${esc(m.id)}</span>` },
      { key: 'name', label: 'Name', sort: 1, render: m => `<div class="title-cell">${esc(m.name)}</div><div class="sub">${esc(m.email) || 'No email'}</div>` },
      { key: 'phone', label: 'Phone', render: m => esc(m.phone) || '<span class="faint">None</span>' },
      { key: 'loans', label: 'On loan', cls: 'num', render: m => m.activeLoans || '<span class="faint">0</span>' },
      { key: 'overdue', label: 'Overdue', render: m => m.overdue ? `<span class="pill bad">${m.overdue} overdue</span>` : '<span class="faint">None</span>' },
      { key: 'res', label: 'Reservations', cls: 'num', render: m => m.pending || '<span class="faint">0</span>' },
      { key: 'fines', label: 'Fines recorded', cls: 'num', render: m => m.fines > 0 ? money(m.fines) : '<span class="faint">None</span>' },
      { key: 'actions', label: 'Actions', cls: 'actions', render: m => {
        const block = memberDeleteBlock(m);
        return `<button class="icon-btn" data-view="${esc(m.id)}" title="View profile">${icon('eye')}</button><button class="icon-btn" data-edit="${esc(m.id)}" title="Edit">${icon('edit')}</button><button class="icon-btn bad" data-del="${esc(m.id)}" title="${esc(block ? block + ' It cannot be deleted yet.' : 'Delete')}" ${block ? 'disabled' : ''}>${icon('trash')}</button>`;
      } },
    ];
    const empty = state.members.length
      ? emptyState({ iconName: 'search', title: 'No members match', text: 'Check the spelling or choose a different filter.' })
      : emptyState({ iconName: 'users', title: 'No members registered yet', text: 'Register a member before issuing books.', action: `<button class="btn primary" onclick="memberDialog()">${icon('userPlus')}Register member</button>` });
    const box = $('#mtable', root);
    box.innerHTML = tableHTML(columns, rows, v, { empty, rowAttr: m => `class="clickable" data-row="${esc(m.id)}"` });
    bindSort(box, v, () => this.update(root));
    $$('[data-row]', box).forEach(tr => tr.onclick = e => { if (!e.target.closest('button')) openMemberDrawer(tr.dataset.row); });
    $$('[data-view]', box).forEach(b => b.onclick = () => openMemberDrawer(b.dataset.view));
    $$('[data-edit]', box).forEach(b => b.onclick = () => memberDialog(by.member.get(b.dataset.edit)));
    $$('[data-del]', box).forEach(b => b.onclick = () => deleteMember(by.member.get(b.dataset.del)));
    $('#mfoot', root).innerHTML = `<span>${rows.length} of ${plural(state.members.length, 'member')} shown</span><span>Searched with linear search; ordered with merge sort.</span>`;
  },
};
