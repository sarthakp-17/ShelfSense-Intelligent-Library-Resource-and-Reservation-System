'use strict';
/* ===================================================================
   ShelfSense UI core
   - api():   talks to the C++ engine (all rules and data live there)
   - helpers: dates, money, escaping, lookups
   - components: icons, tables, dialogs, drawers, toasts, pickers
   The page keeps no data of its own: after every change it reloads
   /api/state from the engine and redraws.
   =================================================================== */

const TOKEN = document.querySelector('meta[name="shelfsense-token"]').content;

let state = null;          // last /api/state snapshot
const ui = {};             // per-page view state (filters, selections)

// ---------------- API ----------------
async function api(path, data) {
  const opts = { headers: { 'X-ShelfSense-Token': TOKEN } };
  if (data !== undefined) {
    opts.method = 'POST';
    opts.headers['Content-Type'] = 'application/x-www-form-urlencoded';
    opts.body = new URLSearchParams(data).toString();
  }
  let res;
  try {
    res = await fetch(path, opts);
  } catch (e) {
    setEngineOnline(false);
    throw new Error('The ShelfSense engine is not responding. Restart ShelfSense.');
  }
  let json;
  try { json = await res.json(); } catch (e) { json = { ok: false, message: 'Unexpected reply from the engine.' }; }
  if (res.status === 403) throw new Error(json.message || 'Request refused.');
  return json;
}

const apiGet = (path, params) => api(path + (params ? '?' + new URLSearchParams(params) : ''));

async function loadState() {
  state = await apiGet('/api/state');
  index();
  setEngineOnline(true);
  return state;
}

// Lookup maps rebuilt after every state load
const by = { book: new Map(), member: new Map(), active: new Map(), queue: new Map() };
function index() {
  by.book = new Map(state.books.map(b => [b.id, b]));
  by.member = new Map(state.members.map(m => [m.id, m]));
  by.active = new Map(state.records.filter(r => r.status === 'Issued').map(r => [r.bookId, r]));
  by.queue = new Map();
  for (const q of state.queue) {
    if (!by.queue.has(q.bookId)) by.queue.set(q.bookId, []);
    by.queue.get(q.bookId).push(q);
  }
}

// Runs a change, shows the engine's answer, reloads state and redraws.
async function mutate(path, data, opts = {}) {
  let r;
  try {
    r = await api(path, data);
  } catch (e) {
    toast(e.message, 'bad');
    return { ok: false, message: e.message };
  }
  if (r.ok) {
    if (!opts.silent) toast(r.message, r.saved === false ? 'warn' : 'ok', r.saved === false ? 9000 : 4500);
    await loadState();
    render();
  }
  return r;
}

// ---------------- formatting ----------------
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function fmtDate(d) {             // DD-MM-YYYY -> 18 Oct 2026
  if (!d || d.length !== 10) return d || '';
  const [dd, mm, yy] = d.split('-');
  return `${+dd} ${MONTHS[+mm - 1] || mm} ${yy}`;
}
function fmtStamp(t) {            // DD-MM-YYYY HH:MM
  if (!t) return '';
  const [d, time] = t.split(' ');
  return fmtDate(d) + (time ? ', ' + time : '');
}
const toISO = d => (d && d.length === 10) ? `${d.slice(6)}-${d.slice(3, 5)}-${d.slice(0, 2)}` : '';
const fromISO = iso => (iso && iso.length === 10) ? `${iso.slice(8)}-${iso.slice(5, 7)}-${iso.slice(0, 4)}` : '';
function dayNum(d) { if (!d || d.length !== 10) return NaN; return Date.UTC(+d.slice(6), +d.slice(3, 5) - 1, +d.slice(0, 2)) / 86400000; }
function addDays(d, n) {          // presentation only (pre-filling date inputs); the engine re-validates
  const t = new Date((dayNum(d) + n) * 86400000);
  return `${String(t.getUTCDate()).padStart(2, '0')}-${String(t.getUTCMonth() + 1).padStart(2, '0')}-${t.getUTCFullYear()}`;
}
const money = v => 'Rs. ' + Number(v || 0).toFixed(2);
const plural = (n, one, many) => `${n} ${n === 1 ? one : (many || one + 's')}`;
function daysText(daysLeft) {
  if (daysLeft < 0) return plural(-daysLeft, 'day') + ' overdue';
  if (daysLeft === 0) return 'Due today';
  if (daysLeft === 1) return 'Due tomorrow';
  return plural(daysLeft, 'day') + ' left';
}
function duePill(daysLeft) {
  const soon = state.settings.dueSoonDays;
  const cls = daysLeft < 0 ? 'bad' : (daysLeft <= soon ? 'warn' : 'blue');
  return `<span class="pill ${cls}">${daysText(daysLeft)}</span>`;
}
function statusPill(status) {
  const cls = { Available: 'ok', Issued: 'blue', Reserved: 'res' }[status] || 'grey';
  return `<span class="pill ${cls}">${esc(status)}</span>`;
}
const spine = id => `<span class="spine">${esc(id)}</span>`;
const bookTitle = id => (by.book.get(id) || {}).title || id;
const memberName = id => (by.member.get(id) || {}).name || id;
function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
function h(html) { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; }
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

function downloadCSV(filename, header, rows) {
  const cell = v => { const s = String(v == null ? '' : v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  const csv = [header, ...rows].map(r => r.map(cell).join(',')).join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' }));
  a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  toast(`Exported ${plural(rows.length, 'row')} to ${filename}.`, 'ok');
}

// ---------------- icons ----------------
const ICONS = {
  dashboard: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  book: '<path d="M5 4.5A1.5 1.5 0 0 1 6.5 3H19v15H6.5A1.5 1.5 0 0 0 5 19.5 1.5 1.5 0 0 0 6.5 21H19"/><path d="M9 7h6"/>',
  bookPlus: '<path d="M5 4.5A1.5 1.5 0 0 1 6.5 3H19v15H6.5A1.5 1.5 0 0 0 5 19.5 1.5 1.5 0 0 0 6.5 21H19"/><path d="M12 7v6M9 10h6"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.4 3.3-5.5 6.5-5.5s5.9 2.1 6.5 5.5"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8"/><path d="M18 14.8c1.9.7 3.2 2.5 3.5 5.2"/>',
  userPlus: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.4 3.3-5.5 6.5-5.5s5.9 2.1 6.5 5.5"/><path d="M19 8v6M16 11h6"/>',
  swap: '<path d="M7 4 3 8l4 4"/><path d="M3 8h14"/><path d="m17 20 4-4-4-4"/><path d="M21 16H7"/>',
  issue: '<path d="M14 4h6v6"/><path d="M20 4 11 13"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
  ret: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>',
  bookmark: '<path d="M6 3h12v18l-6-4.5L6 21z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  history: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v4h4"/><path d="M12 8v4l3 2"/>',
  chart: '<path d="M5 20V11"/><path d="M11 20V5"/><path d="M17 20v-7"/><path d="M3 20h18"/>',
  settings: '<path d="M4 6h9"/><path d="M19 6h1"/><circle cx="16" cy="6" r="2.5"/><path d="M4 12h3"/><path d="M13 12h7"/><circle cx="10" cy="12" r="2.5"/><path d="M4 18h11"/><circle cx="18" cy="18" r="2.5"/>',
  power: '<path d="M12 3v8"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  edit: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
  trash: '<path d="M4 7h16"/><path d="M10 11v6M14 11v6"/><path d="M6 7l1 13h10l1-13"/><path d="M9 7V4h6v3"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  alert: '<path d="M12 3.5 2.5 20h19z"/><path d="M12 10v4"/><path d="M12 17.2v.01"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><path d="M12 8h.01"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  download: '<path d="M12 4v11"/><path d="m7 10 5 5 5-5"/><path d="M5 20h14"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14.3-4.9L4 8"/><path d="M4 3v5h5"/><path d="M4 13a8 8 0 0 0 14.3 4.9L20 16"/><path d="M20 21v-5h-5"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  shield: '<path d="M12 3 4 6v6c0 4.5 3.4 8 8 9 4.6-1 8-4.5 8-9V6z"/><path d="m9 12 2 2 4-4"/>',
  list: '<path d="M9 6h12M9 12h12M9 18h12"/><path d="M4 6h.01M4 12h.01M4 18h.01"/>',
  arrowUp: '<path d="M12 19V5"/><path d="m6 11 6-6 6 6"/>',
  arrowDown: '<path d="M12 5v14"/><path d="m6 13 6 6 6-6"/>',
  printer: '<path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
  inbox: '<path d="M3 13h5l2 3h4l2-3h5"/><path d="M5 5h14l2 8v6H3v-6z"/>',
  coin: '<circle cx="12" cy="12" r="9"/><path d="M15 9h-4.5a1.5 1.5 0 0 0 0 3h3a1.5 1.5 0 0 1 0 3H9"/><path d="M12 7v2M12 15v2"/>',
};
function icon(name, cls = '') {
  return `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name] || ''}</svg>`;
}

// ---------------- toasts ----------------
function toast(message, kind = 'ok', ms = 4500) {
  const box = $('#toasts');
  const ic = { ok: 'check', bad: 'alert', warn: 'alert', info: 'info' }[kind] || 'info';
  const el = h(`<div class="toast ${kind}" role="status">${icon(ic)}<div class="tb">${esc(message)}</div><button aria-label="Dismiss">${icon('x', 'sm')}</button></div>`);
  el.querySelector('button').onclick = () => el.remove();
  box.appendChild(el);
  setTimeout(() => el.remove(), ms);
}

// ---------------- dialogs ----------------
// openDialog returns { el, close }. Esc and the scrim close it.
function openDialog({ title, body, actions = [], narrow = false, onClose }) {
  const scrim = h(`<div class="scrim" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="dialog ${narrow ? 'narrow' : ''}">
        <div class="dialog-head"><h2>${esc(title)}</h2><button class="icon-btn" data-x aria-label="Close">${icon('x')}</button></div>
        <div class="dialog-body"></div>
        <div class="dialog-foot"></div>
      </div></div>`);
  const bodyEl = scrim.querySelector('.dialog-body');
  if (typeof body === 'string') bodyEl.innerHTML = body; else if (body) bodyEl.appendChild(body);
  const foot = scrim.querySelector('.dialog-foot');
  const prevFocus = document.activeElement;
  let closed = false;
  const close = () => {
    if (closed) return; closed = true;
    scrim.remove(); document.removeEventListener('keydown', onKey);
    if (prevFocus && prevFocus.focus) prevFocus.focus();
    if (onClose) onClose();
  };
  const onKey = e => { if (e.key === 'Escape') close(); };
  for (const a of actions) {
    const b = h(`<button class="btn ${a.kind || ''}">${a.icon ? icon(a.icon) : ''}${esc(a.label)}</button>`);
    b.onclick = () => a.onClick ? a.onClick({ close, button: b, el: scrim }) : close();
    foot.appendChild(b);
  }
  scrim.querySelector('[data-x]').onclick = close;
  scrim.addEventListener('mousedown', e => { if (e.target === scrim) close(); });
  document.addEventListener('keydown', onKey);
  document.body.appendChild(scrim);
  const first = scrim.querySelector('.dialog-body input:not([disabled]), .dialog-body select, .dialog-foot .btn.primary, .dialog-foot .btn.danger');
  // Focus at once (not on a timer): a delayed focus could pull the cursor out of
  // a field the person has already started typing in.
  if (first && !scrim.contains(document.activeElement)) first.focus();
  return { el: scrim, close };
}

function confirmDialog({ title, message, confirmLabel = 'Confirm', danger = false, details = '' }) {
  return new Promise(resolve => {
    let result = false;
    openDialog({
      title, narrow: true,
      body: `<p class="lead">${message}</p>${details}`,
      onClose: () => resolve(result),
      actions: [
        { label: 'Cancel' },
        { label: confirmLabel, kind: danger ? 'danger' : 'primary', onClick: ({ close }) => { result = true; close(); } },
      ],
    });
  });
}

// Form dialog: fields -> validated values -> onSubmit(values) returning the engine result
function formDialog({ title, fields, submitLabel, onSubmit, validate }) {
  const form = h(`<form class="form-grid" novalidate></form>`);
  for (const f of fields) {
    const id = 'f_' + f.name;
    const input = f.type === 'select'
      ? `<select class="input" id="${id}" name="${f.name}">${f.options.map(o => `<option value="${esc(o.value)}" ${o.value === f.value ? 'selected' : ''}>${esc(o.label)}</option>`).join('')}</select>`
      : `<input class="input" id="${id}" name="${f.name}" type="${f.type || 'text'}" value="${esc(f.value || '')}" ${f.disabled ? 'disabled' : ''} ${f.list ? `list="${id}_list"` : ''} placeholder="${esc(f.placeholder || '')}" autocomplete="off" ${f.maxlength ? `maxlength="${f.maxlength}"` : ''}>`;
    const list = f.list ? `<datalist id="${id}_list">${f.list.map(v => `<option value="${esc(v)}">`).join('')}</datalist>` : '';
    form.appendChild(h(`<div class="field ${f.full ? 'full' : ''}"><label for="${id}">${esc(f.label)}${f.optional ? ' <span class="faint">(optional)</span>' : ''}</label>${input}${list}${f.help ? `<div class="help">${esc(f.help)}</div>` : ''}<div class="error" data-err="${f.name}"></div></div>`));
  }
  form.appendChild(h(`<div class="full banner bad form-error hidden">${icon('alert')}<div class="grow" data-form-error></div></div>`));
  const submit = async ({ close, button }) => {
    const values = {};
    for (const f of fields) values[f.name] = (form.elements[f.name].value || '').trim();
    $$('.error', form).forEach(e => (e.textContent = ''));
    $$('.input', form).forEach(e => e.classList.remove('invalid'));
    const errors = validate ? validate(values) : {};
    const keys = Object.keys(errors);
    if (keys.length) {
      for (const k of keys) {
        $(`[data-err="${k}"]`, form).textContent = errors[k];
        form.elements[k].classList.add('invalid');
      }
      form.elements[keys[0]].focus();
      return;
    }
    button.disabled = true;
    const r = await onSubmit(values);
    button.disabled = false;
    if (r && r.ok) close();
    else if (r) {
      const box = $('.form-error', form);
      box.classList.remove('hidden');
      $('[data-form-error]', box).textContent = r.message;
    }
  };
  const dlg = openDialog({ title, body: form, actions: [{ label: 'Cancel' }, { label: submitLabel, kind: 'primary', onClick: submit }] });
  form.addEventListener('submit', e => { e.preventDefault(); });
  form.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.tagName === 'INPUT') { e.preventDefault(); $('.dialog-foot .btn.primary', dlg.el).click(); }
  });
  return dlg;
}

// ---------------- drawer ----------------
let drawerClose = null;
function openDrawer(headHtml, bodyHtml, bind) {
  if (drawerClose) drawerClose();
  const scrim = h('<div class="drawer-scrim"></div>');
  const d = h(`<aside class="drawer" role="dialog" aria-modal="true"><div class="drawer-head"><div style="flex:1;min-width:0">${headHtml}</div><button class="icon-btn" data-x aria-label="Close">${icon('x')}</button></div><div class="drawer-body">${bodyHtml}</div></aside>`);
  const onKey = e => { if (e.key === 'Escape' && !document.querySelector('.scrim')) close(); };
  const close = () => { scrim.remove(); d.remove(); document.removeEventListener('keydown', onKey); drawerClose = null; };
  scrim.onclick = close;
  d.querySelector('[data-x]').onclick = close;
  document.addEventListener('keydown', onKey);
  document.body.append(scrim, d);
  drawerClose = close;
  if (bind) bind(d, close);
  return close;
}

// ---------------- empty state ----------------
function emptyState({ iconName = 'inbox', title, text = '', action = '', compact = false }) {
  return `<div class="empty ${compact ? 'compact' : ''}"><div class="em-icon">${icon(iconName, 'lg')}</div><h3>${esc(title)}</h3>${text ? `<p>${text}</p>` : ''}${action}</div>`;
}

// ---------------- sortable table ----------------
// columns: [{ key, label, sort: row => value | null, render: row => html, cls }]
// view: { sortKey, sortDir } stored in ui[...] so it survives redraws
function tableHTML(columns, rows, view, opts = {}) {
  if (!rows.length) return opts.empty || emptyState({ title: 'Nothing to show', compact: true });
  const head = columns.map(c => {
    const sortable = !!c.sort;
    const arrow = sortable && view && view.sortKey === c.key ? `<span class="arrow">${view.sortDir === 'desc' ? '↓' : '↑'}</span>` : '';
    return `<th class="${sortable ? 'sortable' : ''} ${c.cls || ''}" ${sortable ? `data-sort="${c.key}"` : ''}>${esc(c.label)}${arrow}</th>`;
  }).join('');
  const body = rows.map(r => `<tr ${opts.rowAttr ? opts.rowAttr(r) : ''}>${columns.map(c => `<td class="${c.cls || ''}">${c.render(r)}</td>`).join('')}</tr>`).join('');
  return `<div class="table-wrap"><table class="data"><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
}
function sortRows(columns, rows, view) {
  const col = columns.find(c => c.key === view.sortKey && c.sort);
  if (!col) return rows;
  const dir = view.sortDir === 'desc' ? -1 : 1;
  const coll = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
  return rows.slice().sort((a, b) => {
    const x = col.sort(a), y = col.sort(b);
    if (typeof x === 'number' && typeof y === 'number') return (x - y) * dir;
    return coll.compare(String(x), String(y)) * dir;
  });
}
function bindSort(root, view, redraw) {
  $$('th[data-sort]', root).forEach(th => th.onclick = () => {
    if (view.sortKey === th.dataset.sort) view.sortDir = view.sortDir === 'asc' ? 'desc' : 'asc';
    else { view.sortKey = th.dataset.sort; view.sortDir = 'asc'; }
    redraw();
  });
}

// ---------------- pickers (member / book / loan) ----------------
// A typeahead that searches a list and calls onPick(item). Selection is shown as a chip.
function makePicker({ el, placeholder, items, match, renderItem, renderChosen, onPick, value }) {
  let chosen = value || null;
  function draw() {
    if (chosen) {
      el.innerHTML = `<div class="chosen">${renderChosen(chosen)}<button class="icon-btn" type="button" aria-label="Change selection">${icon('x')}</button></div>`;
      el.querySelector('button').onclick = () => { chosen = null; onPick(null); draw(); el.querySelector('input').focus(); };
      return;
    }
    el.innerHTML = `<div class="picker"><div class="search">${icon('search')}<input class="input" placeholder="${esc(placeholder)}" autocomplete="off"></div></div>`;
    const input = el.querySelector('input');
    const wrap = el.querySelector('.picker');
    let list = null, hl = 0, current = [];
    const closeList = () => { if (list) { list.remove(); list = null; } };
    const showList = () => {
      const q = input.value.trim().toLowerCase();
      current = items().filter(it => match(it, q)).slice(0, 40);
      closeList();
      list = h(`<div class="picker-list" role="listbox"></div>`);
      if (!current.length) list.innerHTML = `<div class="picker-empty">No matches for “${esc(input.value)}”.</div>`;
      current.forEach((it, i) => {
        const row = h(`<div class="picker-item ${i === hl ? 'hl' : ''}" role="option">${renderItem(it)}</div>`);
        row.onmousedown = e => { e.preventDefault(); choose(it); };
        list.appendChild(row);
      });
      wrap.appendChild(list);
    };
    const choose = it => { chosen = it; closeList(); onPick(it); draw(); };
    input.addEventListener('focus', () => { hl = 0; showList(); });
    input.addEventListener('input', () => { hl = 0; showList(); });
    input.addEventListener('blur', () => setTimeout(closeList, 120));
    input.addEventListener('keydown', e => {
      if (!list) return;
      if (e.key === 'ArrowDown') { hl = Math.min(hl + 1, current.length - 1); showList(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { hl = Math.max(hl - 1, 0); showList(); e.preventDefault(); }
      else if (e.key === 'Enter' && current[hl]) { e.preventDefault(); choose(current[hl]); }
      else if (e.key === 'Escape') closeList();
    });
  }
  draw();
  return { get: () => chosen, set: it => { chosen = it; draw(); } };
}

const memberPickerConfig = (onPick, value) => ({
  placeholder: 'Search members by ID or name',
  items: () => state.members.slice().sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true })),
  match: (m, q) => !q || m.id.toLowerCase().includes(q) || m.name.toLowerCase().includes(q),
  renderItem: m => `<span class="member-tag">${esc(m.id)}</span><div class="pt"><b>${esc(m.name)}</b><span>${plural(m.activeLoans, 'book')} on loan${m.overdue ? ` · <span style="color:var(--bad)">${m.overdue} overdue</span>` : ''}</span></div>`,
  renderChosen: m => `<span class="member-tag">${esc(m.id)}</span><div class="ct"><b>${esc(m.name)}</b><span>${esc(m.email || 'No email')} · ${plural(m.activeLoans, 'book')} on loan</span></div>`,
  onPick, value,
});
const bookPickerConfig = (onPick, value, filter = () => true, placeholder = 'Search books by ID, title or author') => ({
  placeholder,
  items: () => state.books.filter(filter).sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true })),
  match: (b, q) => !q || b.id.toLowerCase().includes(q) || b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q),
  renderItem: b => `${spine(b.id)}<div class="pt"><b>${esc(b.title)}</b><span>${esc(b.author)}</span></div>${statusPill(b.status)}`,
  renderChosen: b => `${spine(b.id)}<div class="ct"><b>${esc(b.title)}</b><span>${esc(b.author)} · ${esc(b.category)}</span></div>${statusPill(b.status)}`,
  onPick, value,
});

// ---------------- engine connection ----------------
function setEngineOnline(on) {
  const e = $('#engine');
  if (!e) return;
  e.classList.toggle('offline', !on);
  $('#engineText').textContent = on ? 'Engine running, data saved' : 'Engine not responding';
}
