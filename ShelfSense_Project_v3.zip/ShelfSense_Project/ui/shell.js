'use strict';
/* ===================================================================
   Shell: sidebar navigation, routing, theme, engine heartbeat, exit.
   Each page registers { title, icon, build(root), update?(root) }.
   build() draws the page; update() (optional) redraws only the data
   parts so typed search text and focus survive a state reload.
   =================================================================== */

const PAGES = {};
const NAV = [
  { group: 'Library' },
  { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
  { id: 'books', label: 'Book Management', icon: 'book', count: () => state.stats.totalBooks },
  { id: 'members', label: 'Member Management', icon: 'users', count: () => state.stats.members },
  { group: 'Circulation' },
  { id: 'circulation', label: 'Issue & Return', icon: 'swap', count: () => state.stats.activeLoans },
  { id: 'reservations', label: 'Reservations', icon: 'bookmark', count: () => state.stats.pendingReservations },
  { id: 'search', label: 'Search & Explore', icon: 'search' },
  { id: 'due', label: 'Due Dates & Fines', icon: 'clock', count: () => state.stats.overdue, alert: true },
  { group: 'Insight' },
  { id: 'transactions', label: 'Transaction History', icon: 'history' },
  { id: 'reports', label: 'Reports', icon: 'chart' },
  { group: 'System' },
  { id: 'settings', label: 'Settings', icon: 'settings' },
];

let currentPage = null;
let builtPage = null;

function route() {
  const [id, query] = (location.hash.replace(/^#\/?/, '') || 'dashboard').split('?');
  return { id: PAGES[id] ? id : 'dashboard', params: new URLSearchParams(query || '') };
}
function go(id, params) {
  const q = params ? '?' + new URLSearchParams(params) : '';
  if (location.hash === `#/${id}${q}`) render(true);
  else location.hash = `#/${id}${q}`;
}

function drawNav() {
  const nav = $('#nav');
  nav.innerHTML = NAV.map(n => {
    if (n.group) return `<div class="nav-group">${esc(n.group)}</div>`;
    let count = '';
    if (n.count && state) {
      const c = n.count();
      if (!n.alert || c > 0) count = `<span class="count ${n.alert && c > 0 ? 'alert' : ''}">${c}</span>`;
    }
    return `<a href="#/${n.id}" data-id="${n.id}" title="${esc(n.label)}" class="${currentPage === n.id ? 'active' : ''}">${icon(n.icon)}<span class="label">${esc(n.label)}</span>${count}</a>`;
  }).join('');
}

// Full redraw on navigation; data-only update on state reload where supported.
function render(force) {
  if (!state) return;
  const { id, params } = route();
  const page = PAGES[id];
  currentPage = id;
  applyTheme();
  drawNav();
  const root = $('#page');
  if (force || builtPage !== id || !page.update) {
    if (drawerClose) drawerClose();
    root.innerHTML = '';
    page.build(root, params);
    builtPage = id;
    $('#main').scrollTop = 0;
    document.title = `${page.title} - ShelfSense`;
  } else {
    page.update(root);
  }
}

// Common page header
function pageHead(title, sub, actionsHtml = '') {
  return `<div class="page-head"><div><h1>${esc(title)}</h1>${sub ? `<div class="sub">${sub}</div>` : ''}</div><div class="actions">${actionsHtml}</div></div>`;
}

// Load-time data problems are shown at the top of the dashboard and settings
function warningsBanner() {
  if (!state.warnings.length) return '';
  return `<div class="banner bad">${icon('alert')}<div class="grow"><b>${plural(state.warnings.length, 'data problem')} found when ShelfSense started.</b> ${esc(state.warnings[0])}${state.warnings.length > 1 ? ` <button class="link" onclick="go('settings')">See all in Settings</button>` : ''}</div></div>`;
}

// ---------------- theme ----------------
const media = window.matchMedia('(prefers-color-scheme: dark)');
function applyTheme() {
  const pref = state ? state.settings.theme : 'system';
  const dark = pref === 'dark' || (pref === 'system' && media.matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  const t = $('#themeToggle');
  if (t) {
    t.innerHTML = icon(dark ? 'sun' : 'moon') + `<span class="label">${dark ? 'Light theme' : 'Dark theme'}</span>`;
    t.title = dark ? 'Switch to light theme' : 'Switch to dark theme';
  }
}
media.addEventListener('change', applyTheme);
async function toggleTheme() {
  const dark = document.documentElement.dataset.theme === 'dark';
  const s = state.settings;
  const r = await mutate('/api/settings', { finePerDay: s.finePerDay, loanDays: s.loanDays, dueSoonDays: s.dueSoonDays, theme: dark ? 'light' : 'dark' }, { silent: true });
  if (!r.ok) toast(r.message, 'bad');
  applyTheme();
}

// ---------------- exit ----------------
async function exitApp() {
  const ok = await confirmDialog({
    title: 'Exit ShelfSense?',
    message: 'Every change is already saved to the data folder. ShelfSense will save once more and close.',
    confirmLabel: 'Exit ShelfSense',
  });
  if (!ok) return;
  let r;
  try { r = await api('/api/shutdown', {}); } catch (e) { r = { ok: false, message: e.message }; }
  stopHeartbeat();
  document.body.appendChild(h(`<div class="closed-screen"><div><h1>ShelfSense has closed</h1><p>${esc(r.message || '')}</p><p>You can close this window.</p></div></div>`));
  setTimeout(() => window.close(), 400);   // allowed for the app window ShelfSense opened
}

// ---------------- heartbeat ----------------
// Lets the engine know the window is open; when the window closes the engine
// saves and exits by itself.
let beatTimer = null;
function beat() {
  fetch('/api/heartbeat', { method: 'POST' }).then(() => setEngineOnline(true)).catch(() => setEngineOnline(false));
}
function stopHeartbeat() { clearInterval(beatTimer); beatTimer = null; }
window.addEventListener('pagehide', () => { if (beatTimer) { try { navigator.sendBeacon('/api/bye', 'x'); } catch (e) { } } });

// ---------------- start ----------------
async function start() {
  $('#app').innerHTML = `
    <aside class="sidebar">
      <div class="brand">
        <svg class="brand-mark" viewBox="0 0 34 34" aria-hidden="true">
          <rect width="34" height="34" rx="9" fill="#2D6BE4"/>
          <rect x="8" y="9" width="4.5" height="16" rx="1.2" fill="#fff"/>
          <rect x="14.5" y="7" width="4.5" height="18" rx="1.2" fill="#fff" opacity=".82"/>
          <rect x="21" y="11" width="4.6" height="14.5" rx="1.2" fill="#fff" opacity=".64" transform="rotate(-12 23.3 18)"/>
          <rect x="7" y="25.5" width="20" height="1.8" rx=".9" fill="#fff"/>
        </svg>
        <div class="brand-text"><div class="brand-name">ShelfSense</div><div class="brand-sub">Library resources and reservations</div></div>
      </div>
      <nav class="nav" id="nav" aria-label="Main"></nav>
      <div class="sidebar-foot nav">
        <a href="javascript:void 0" id="themeToggle"></a>
        <a href="javascript:void 0" id="exitBtn" class="exit" title="Exit Application">${icon('power')}<span class="label">Exit Application</span></a>
        <div class="engine" id="engine"><span class="dot"></span><span id="engineText">Connecting to engine</span></div>
      </div>
    </aside>
    <main class="main" id="main"><div class="page" id="page"></div></main>`;
  $('#exitBtn').onclick = exitApp;
  $('#themeToggle').onclick = toggleTheme;

  try {
    await loadState();
  } catch (e) {
    $('#page').innerHTML = emptyState({ iconName: 'alert', title: 'ShelfSense could not load the library', text: esc(e.message) });
    setEngineOnline(false);
    return;
  }
  applyTheme();
  window.addEventListener('hashchange', () => render(true));
  render(true);
  beat();
  beatTimer = setInterval(beat, 4000);

  // Ctrl+K: jump to Search & Explore
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      if (currentPage === 'dashboard' && $('#quickSearch')) $('#quickSearch').focus();
      else go('search');   // the Search page focuses its input when it opens
    }
  });
}
document.addEventListener('DOMContentLoaded', start);
