'use strict';
/* ===================================================================
   Issue & Return, Reservations
   The engine enforces every rule (availability, FIFO, dates, fines);
   the checks shown here only explain the situation before confirming.
   =================================================================== */

function dateField(id, label, ddmmyyyy, help = '') {
  return `<div class="field"><label for="${id}">${esc(label)}</label><input class="input" type="date" id="${id}" value="${toISO(ddmmyyyy)}">${help ? `<div class="help">${help}</div>` : ''}</div>`;
}
function checkItem(st, text) {
  const ic = { pass: 'check', fail: 'x', warn: 'alert', todo: 'check' }[st];
  return `<li class="${st}"><span class="ck">${icon(ic)}</span><span>${text}</span></li>`;
}
const loanPickerConfig = (onPick, value) => ({
  placeholder: 'Search loans by book ID, title or member',
  items: () => state.dueOrder.map(d => ({ ...d, rec: by.active.get(d.bookId) })),
  match: (d, q) => !q || d.bookId.toLowerCase().includes(q) || bookTitle(d.bookId).toLowerCase().includes(q) || d.memberId.toLowerCase().includes(q) || memberName(d.memberId).toLowerCase().includes(q),
  renderItem: d => `${spine(d.bookId)}<div class="pt"><b>${esc(bookTitle(d.bookId))}</b><span>${esc(memberName(d.memberId))} (${esc(d.memberId)})</span></div>${duePill(d.daysLeft)}`,
  renderChosen: d => `${spine(d.bookId)}<div class="ct"><b>${esc(bookTitle(d.bookId))}</b><span>On loan to ${esc(memberName(d.memberId))} (${esc(d.memberId)})</span></div>${duePill(d.daysLeft)}`,
  onPick, value,
});
const loanFor = bookId => { const d = state.dueOrder.find(x => x.bookId === bookId); return d ? { ...d, rec: by.active.get(bookId) } : null; };

// =================================================================
// Issue & Return
// =================================================================
ui.circ = { tab: 'issue' };

PAGES.circulation = {
  title: 'Issue & Return',
  build(root, params) {
    const v = ui.circ;
    if (params.get('tab')) v.tab = params.get('tab');
    root.innerHTML = `
      ${pageHead('Issue & Return', 'Lend books, take them back and extend due dates.')}
      <div class="tabs" role="tablist">
        <button data-tab="issue">${icon('issue', 'sm')}Issue book</button>
        <button data-tab="return">${icon('ret', 'sm')}Return book</button>
        <button data-tab="renew">${icon('refresh', 'sm')}Renew loan</button>
      </div>
      <div id="circTab"></div>
      <section class="panel" style="margin-top:18px">
        <div class="panel-head"><h2>Books on loan</h2><span class="hint">Ordered by due date with the min-heap</span></div>
        <div class="panel-body flush" id="loanTable"></div>
      </section>`;
    $$('.tabs button', root).forEach(b => {
      b.classList.toggle('on', b.dataset.tab === v.tab);
      b.onclick = () => go('circulation', { tab: b.dataset.tab });
    });
    if (v.tab === 'return') this.returnTab($('#circTab', root), params);
    else if (v.tab === 'renew') this.renewTab($('#circTab', root), params);
    else this.issueTab($('#circTab', root), params);
    this.loanTable($('#loanTable', root));
  },

  issueTab(box, params) {
    const sel = {
      member: by.member.get(params.get('member')) || null,
      book: by.book.get(params.get('book')) || null,
      issue: state.today,
      due: addDays(state.today, state.settings.loanDays),
    };
    box.innerHTML = `<div class="grid side">
      <section class="panel"><div class="panel-head"><h2>Issue a book</h2></div><div class="panel-body stack">
        <div class="field"><label>Member</label><div id="pkMember"></div></div>
        <div class="field"><label>Book</label><div id="pkBook"></div></div>
        <div class="form-grid">${dateField('issueDate', 'Issue date', sel.issue)}${dateField('dueDate', 'Due date', sel.due, `Default loan period: ${plural(state.settings.loanDays, 'day')} (change it in Settings).`)}</div>
        <div><button class="btn primary" id="doIssue">${icon('issue')}Issue book</button></div>
      </div></section>
      <section class="panel"><div class="panel-head"><h2>Before you confirm</h2></div><div class="panel-body" id="issueChecks"></div></section>
    </div>`;
    const checks = () => {
      const m = sel.member, b = sel.book;
      const iss = fromISO($('#issueDate').value), due = fromISO($('#dueDate').value);
      const datesOk = iss && due && dayNum(due) >= dayNum(iss);
      const list = [
        m ? checkItem('pass', `${esc(m.name)} is a registered member.`) : checkItem('todo', 'Choose a member.'),
        !b ? checkItem('todo', 'Choose a book.')
          : b.status === 'Available' ? checkItem('pass', `${esc(b.title)} is available.`)
          : checkItem('fail', `${esc(b.title)} is ${b.status.toLowerCase()}${b.borrower ? ` (with ${esc(memberName(b.borrower))} until ${fmtDate(b.due)})` : ''}. <button class="link" id="toReserve">Reserve it instead</button>`),
        !iss || !due ? checkItem('fail', 'Enter both dates.')
          : datesOk ? checkItem('pass', `Loan of ${plural(dayNum(due) - dayNum(iss), 'day')}, due ${fmtDate(due)}.`)
          : checkItem('fail', 'The due date is before the issue date.'),
      ];
      if (m && m.overdue) list.push(checkItem('warn', `${esc(m.name)} already has ${plural(m.overdue, 'overdue book')}. The issue is still allowed.`));
      if (b && b.queue && b.status === 'Available') list.push(checkItem('warn', `${plural(b.queue, 'member')} reserved this book.`));
      $('#issueChecks').innerHTML = `<ul class="checks">${list.join('')}</ul>`;
      const r = $('#toReserve'); if (r) r.onclick = () => go('reservations', { book: b.id, member: m ? m.id : '' });
      $('#doIssue').disabled = !(m && b && b.status === 'Available' && datesOk);
    };
    makePicker({ el: $('#pkMember', box), ...memberPickerConfig(m => { sel.member = m; checks(); }, sel.member) });
    makePicker({ el: $('#pkBook', box), ...bookPickerConfig(b => { sel.book = b; checks(); }, sel.book, () => true, 'Search books by ID, title or author (available ones can be issued)') });
    $('#issueDate').onchange = () => { const iss = fromISO($('#issueDate').value); if (iss) $('#dueDate').value = toISO(addDays(iss, state.settings.loanDays)); checks(); };
    $('#dueDate').onchange = checks;
    $('#doIssue').onclick = async () => {
      const iss = fromISO($('#issueDate').value), due = fromISO($('#dueDate').value);
      const ok = await confirmDialog({
        title: 'Issue this book?',
        message: `<b>${esc(sel.book.title)}</b> will be issued to <b>${esc(sel.member.name)}</b>.`,
        details: `<dl class="kv" style="margin-top:14px"><dt>Book</dt><dd>${spine(sel.book.id)}</dd><dt>Member</dt><dd>${esc(sel.member.id)}</dd><dt>Issue date</dt><dd>${fmtDate(iss)}</dd><dt>Due date</dt><dd>${fmtDate(due)}</dd></dl>`,
        confirmLabel: 'Issue book',
      });
      if (ok) {
        const r = await mutate('/api/issue', { memberId: sel.member.id, bookId: sel.book.id, issueDate: iss, dueDate: due });
        if (!r.ok) toast(r.message, 'bad', 7000);
        else go('circulation', { tab: 'issue' });
      }
    };
    checks();
  },

  returnTab(box, params) {
    let loan = params.get('book') ? loanFor(params.get('book')) : null;
    if (params.get('book') && !loan) toast(`${params.get('book')} is not currently on loan.`, 'warn');
    box.innerHTML = `<div class="grid side">
      <section class="panel"><div class="panel-head"><h2>Return a book</h2></div><div class="panel-body stack">
        <div class="field"><label>Loan</label><div id="pkLoan"></div></div>
        <div class="form-grid">${dateField('retDate', 'Return date', state.today)}<div></div></div>
        <div id="nextBox"></div>
        <div><button class="btn primary" id="doReturn" disabled>${icon('ret')}Confirm return</button></div>
      </div></section>
      <section class="panel"><div class="panel-head"><h2>Return summary</h2></div><div class="panel-body" id="retSummary"></div></section>
    </div>`;
    let preview = null;
    const refresh = async () => {
      preview = null;
      $('#doReturn').disabled = true;
      $('#nextBox').innerHTML = '';
      if (!loan) {
        $('#retSummary').innerHTML = emptyState({ iconName: 'ret', title: 'Choose a loan', text: state.dueOrder.length ? 'Search by book or member. Only books currently on loan are listed.' : 'There are no books on loan right now.', compact: true });
        return;
      }
      const date = fromISO($('#retDate').value);
      const r = await apiGet('/api/return/preview', { bookId: loan.bookId, date });
      if (!r.ok) { $('#retSummary').innerHTML = `<div class="banner bad">${icon('alert')}<div class="grow">${esc(r.message)}</div></div>`; return; }
      preview = r;
      const late = r.lateDays > 0;
      $('#retSummary').innerHTML = `<dl class="kv">
          <dt>Book</dt><dd>${spine(loan.bookId)} ${esc(bookTitle(loan.bookId))}</dd>
          <dt>Member</dt><dd>${esc(memberName(r.borrowerId))} <span class="member-tag">${esc(r.borrowerId)}</span></dd>
          <dt>Issued</dt><dd>${fmtDate(loan.issueDate)}</dd>
          <dt>Due</dt><dd>${fmtDate(r.dueDate)}</dd>
          <dt>Returned</dt><dd>${fmtDate(date)}</dd>
          <dt>Overdue days</dt><dd class="num ${late ? 'fig-bad' : ''}">${late ? plural(r.lateDays, 'day') : 'None, on time'}</dd>
        </dl>
        <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--line)" class="row"><span class="muted">Fine</span><span class="spacer"></span><span class="figure ${late ? 'fig-bad' : 'fig-ok'}">${money(r.fine)}</span></div>
        <p class="small muted" style="margin-top:6px">${late ? `${plural(r.lateDays, 'day')} × ${money(state.settings.finePerDay)} per day.` : 'No fine for an on-time return.'}</p>`;
      if (r.nextInQueue) {
        $('#nextBox').innerHTML = `<div class="banner info">${icon('bookmark')}<div class="grow"><b>${esc(memberName(r.nextInQueue))} (${esc(r.nextInQueue)}) is first in the reservation queue.</b> The book will be issued to them automatically on return.
          <div class="field" style="margin-top:10px;max-width:220px"><label for="nextDue">Due date for ${esc(memberName(r.nextInQueue))}</label><input type="date" class="input" id="nextDue" value="${toISO(addDays(date, state.settings.loanDays))}"></div></div></div>`;
      }
      $('#doReturn').disabled = false;
    };
    makePicker({ el: $('#pkLoan', box), ...loanPickerConfig(d => { loan = d; refresh(); }, loan) });
    $('#retDate').onchange = refresh;
    $('#doReturn').onclick = async () => {
      if (!preview) return;
      const date = fromISO($('#retDate').value);
      const next = $('#nextDue') ? fromISO($('#nextDue').value) : '';
      const ok = await confirmDialog({
        title: 'Confirm this return?',
        message: `<b>${esc(bookTitle(loan.bookId))}</b> returned by <b>${esc(memberName(preview.borrowerId))}</b> on ${fmtDate(date)}.`,
        details: `<dl class="kv" style="margin-top:14px"><dt>Overdue days</dt><dd>${preview.lateDays}</dd><dt>Fine</dt><dd>${money(preview.fine)}</dd>${preview.nextInQueue ? `<dt>Next borrower</dt><dd>${esc(memberName(preview.nextInQueue))}, due ${fmtDate(next)}</dd>` : `<dt>Book becomes</dt><dd>Available</dd>`}</dl>`,
        confirmLabel: 'Confirm return',
      });
      if (!ok) return;
      const r = await mutate('/api/return', { bookId: loan.bookId, returnDate: date, nextDueDate: next });
      if (!r.ok) toast(r.message, 'bad', 7000);
      else go('circulation', { tab: 'return' });
    };
    refresh();
  },

  renewTab(box, params) {
    let loan = params.get('book') ? loanFor(params.get('book')) : null;
    box.innerHTML = `<div class="grid side">
      <section class="panel"><div class="panel-head"><h2>Renew a loan</h2></div><div class="panel-body stack">
        <div class="field"><label>Loan</label><div id="pkRenew"></div></div>
        <div class="form-grid"><div class="field"><label>Current due date</label><input class="input" id="curDue" disabled></div>${dateField('newDue', 'New due date', '')}</div>
        <div><button class="btn primary" id="doRenew" disabled>${icon('refresh')}Renew loan</button></div>
      </div></section>
      <section class="panel"><div class="panel-head"><h2>About renewals</h2></div><div class="panel-body"><p class="muted">The new due date must be later than the current one. Renewing resets any fine on the loan, as in the console version's <code>renewRecord()</code>.</p>
        <p class="muted" style="margin-top:10px">If other members are waiting for the book, consider returning it to the queue instead.</p><div id="renewNote" style="margin-top:12px"></div></div></section>
    </div>`;
    const sync = () => {
      $('#doRenew').disabled = !loan;
      $('#curDue').value = loan ? fmtDate(loan.dueDate) : '';
      $('#newDue').value = loan ? toISO(addDays(loan.dueDate, state.settings.loanDays)) : '';
      const q = loan ? (by.queue.get(loan.bookId) || []).length : 0;
      $('#renewNote').innerHTML = q ? `<div class="banner">${icon('alert')}<div class="grow">${plural(q, 'member is', 'members are')} waiting for this book.</div></div>` : '';
    };
    makePicker({ el: $('#pkRenew', box), ...loanPickerConfig(d => { loan = d; sync(); }, loan) });
    $('#doRenew').onclick = async () => {
      const nd = fromISO($('#newDue').value);
      if (!nd) { toast('Choose a new due date.', 'bad'); return; }
      const ok = await confirmDialog({ title: 'Renew this loan?', message: `<b>${esc(bookTitle(loan.bookId))}</b> for ${esc(memberName(loan.memberId))}: due date moves from ${fmtDate(loan.dueDate)} to <b>${fmtDate(nd)}</b>.`, confirmLabel: 'Renew loan' });
      if (!ok) return;
      const r = await mutate('/api/renew', { bookId: loan.bookId, newDueDate: nd });
      if (!r.ok) toast(r.message, 'bad', 7000);
      else go('circulation', { tab: 'renew' });
    };
    sync();
  },

  loanTable(box) {
    const rows = state.dueOrder;
    box.innerHTML = tableHTML([
      { key: 'b', label: 'Book', render: d => `<div class="row">${spine(d.bookId)}<span class="title-cell">${esc(bookTitle(d.bookId))}</span></div>` },
      { key: 'm', label: 'Member', render: d => `<span class="nw">${esc(memberName(d.memberId))}</span><div class="sub">${esc(d.memberId)}</div>` },
      { key: 'i', label: 'Issued', render: d => `<span class="nowrap">${fmtDate(d.issueDate)}</span>` },
      { key: 'd', label: 'Due', render: d => `<span class="nowrap">${fmtDate(d.dueDate)}</span>` },
      { key: 's', label: 'Status', render: d => duePill(d.daysLeft) },
      { key: 'a', label: '', cls: 'actions', render: d => `<button class="btn sm" data-ret="${esc(d.bookId)}">Return</button> <button class="btn sm ghost" data-ren="${esc(d.bookId)}">Renew</button>` },
    ], rows, null, { empty: emptyState({ iconName: 'book', title: 'No books are on loan', text: 'Issued books will be listed here, earliest due date first.', compact: true }) });
    $$('[data-ret]', box).forEach(b => b.onclick = () => go('circulation', { tab: 'return', book: b.dataset.ret }));
    $$('[data-ren]', box).forEach(b => b.onclick = () => go('circulation', { tab: 'renew', book: b.dataset.ren }));
  },
};

// =================================================================
// Reservations (FIFO queue)
// =================================================================
ui.res = { hist: 'all', hq: '' };

PAGES.reservations = {
  title: 'Reservations',
  build(root, params) {
    root.innerHTML = `
      ${pageHead('Reservations', 'Members queue for books that are on loan. The first to reserve is served first.')}
      <div class="grid side">
        <section class="panel"><div class="panel-head"><h2>Waiting lists</h2><span class="hint">${plural(state.queue.length, 'reservation')} across ${plural(by.queue.size, 'book')}</span></div><div class="panel-body" id="queues"></div></section>
        <section class="panel" id="reserveForm"></section>
      </div>
      <section class="panel" style="margin-top:18px">
        <div class="panel-head"><h2>Reservation history</h2></div>
        <div class="toolbar"><div class="search">${icon('search')}<input class="input" id="hq" placeholder="Search by member or book" value="${esc(ui.res.hq)}"></div><div class="seg" id="hseg"></div></div>
        <div id="htable"></div>
      </section>`;
    this.queues($('#queues', root));
    this.form($('#reserveForm', root), params);
    $('#hq', root).addEventListener('input', debounce(e => { ui.res.hq = e.target.value; this.history(root); }, 100));
    this.history(root);
  },

  queues(box) {
    const books = [...by.queue.keys()];
    if (!books.length) {
      box.innerHTML = emptyState({ iconName: 'bookmark', title: 'No one is waiting', text: 'When a member reserves a book that is on loan, they join its queue here.' });
      return;
    }
    box.innerHTML = books.map(id => {
      const b = by.book.get(id) || { id, title: id, status: 'Unknown' };
      const q = by.queue.get(id);
      const loan = by.active.get(id);
      const canProcess = b.status !== 'Issued';
      return `<div class="queue-card">
        <div class="qh">${spine(id)}<div style="flex:1;min-width:0"><b>${esc(b.title)}</b><div class="small muted">${loan ? `On loan to ${esc(memberName(loan.memberId))}, due ${fmtDate(loan.dueDate)}${loan.daysLeft < 0 ? ` <b style="color:var(--bad)">(${plural(-loan.daysLeft, 'day')} overdue)</b>` : ''}. Goes to #1 automatically on return.` : `Not on loan (status: ${esc(b.status)}).`}</div></div>
          ${canProcess ? `<button class="btn primary sm" data-process="${esc(id)}">${icon('issue', 'sm')}Issue to #1</button>` : statusPill(b.status)}</div>
        <ol>${q.map(r => `<li><span class="pos ${r.position === 1 ? 'first' : ''}">${r.position}</span>
          <div style="flex:1;min-width:0"><b>${esc(memberName(r.memberId))}</b> <span class="member-tag">${esc(r.memberId)}</span><div class="small muted">Reserved ${fmtDate(r.date)}${r.position === 1 ? ', next in line' : ''}</div></div>
          <button class="btn sm ghost" data-cancel="${esc(r.memberId)}|${esc(id)}">Cancel</button></li>`).join('')}</ol></div>`;
    }).join('');
    $$('[data-cancel]', box).forEach(btn => btn.onclick = async () => {
      const [mid, bid] = btn.dataset.cancel.split('|');
      const ok = await confirmDialog({ title: 'Cancel this reservation?', message: `${esc(memberName(mid))} will leave the queue for <b>${esc(bookTitle(bid))}</b>. Members behind them move up one place.`, confirmLabel: 'Cancel reservation', danger: true });
      if (ok) await mutate('/api/reservations/cancel', { memberId: mid, bookId: bid });
    });
    $$('[data-process]', box).forEach(btn => btn.onclick = () => {
      const id = btn.dataset.process;
      const first = by.queue.get(id)[0];
      openDialog({
        title: 'Issue to the first in the queue', narrow: true,
        body: `<p class="lead"><b>${esc(bookTitle(id))}</b> goes to <b>${esc(memberName(first.memberId))}</b>, who reserved it first (${fmtDate(first.date)}).</p><div class="form-grid" style="margin-top:14px">${dateField('pIssue', 'Issue date', state.today)}${dateField('pDue', 'Due date', addDays(state.today, state.settings.loanDays))}</div><div class="banner bad form-error hidden" style="margin-top:12px">${icon('alert')}<div class="grow" data-msg></div></div>`,
        actions: [{ label: 'Cancel' }, { label: 'Issue book', kind: 'primary', onClick: async ({ close, el }) => {
          const r = await mutate('/api/reservations/process', { bookId: id, issueDate: fromISO($('#pIssue', el).value), dueDate: fromISO($('#pDue', el).value) });
          if (r.ok) close(); else { $('.form-error', el).classList.remove('hidden'); $('[data-msg]', el).textContent = r.message; }
        } }],
      });
    });
  },

  form(box, params) {
    const sel = { member: by.member.get(params.get('member')) || null, book: by.book.get(params.get('book')) || null };
    box.innerHTML = `<div class="panel-head"><h2>Reserve a book</h2></div><div class="panel-body stack">
      <div class="field"><label>Member</label><div id="rMember"></div></div>
      <div class="field"><label>Book</label><div id="rBook"></div><div class="help">Only books that are on loan or already reserved are listed. Available books can be issued directly.</div></div>
      ${dateField('rDate', 'Reservation date', state.today)}
      <ul class="checks" id="rChecks"></ul>
      <div><button class="btn primary" id="doReserve">${icon('bookmark')}Reserve book</button></div></div>`;
    const check = () => {
      const m = sel.member, b = sel.book, out = [];
      let ok = !!(m && b);
      if (b) {
        const q = by.queue.get(b.id) || [];
        out.push(checkItem('pass', `${esc(b.title)} is ${b.status.toLowerCase()}. ${q.length ? plural(q.length, 'member is', 'members are') + ' already waiting.' : 'Nobody is waiting yet.'}`));
        if (m) {
          if (b.borrower === m.id) { out.push(checkItem('fail', `${esc(m.name)} already has this book.`)); ok = false; }
          else if (q.some(r => r.memberId === m.id)) { out.push(checkItem('fail', `${esc(m.name)} is already in this queue.`)); ok = false; }
          else out.push(checkItem('pass', `${esc(m.name)} will be number ${q.length + 1} in the queue.`));
        }
      }
      $('#rChecks').innerHTML = out.join('');
      $('#doReserve').disabled = !ok;
    };
    makePicker({ el: $('#rMember', box), ...memberPickerConfig(m => { sel.member = m; check(); }, sel.member) });
    makePicker({ el: $('#rBook', box), ...bookPickerConfig(b => { sel.book = b; check(); }, sel.book && sel.book.status !== 'Available' ? sel.book : null, b => b.status !== 'Available', 'Search books that are on loan') });
    if (sel.book && sel.book.status === 'Available') toast(`${sel.book.title} is available, so it can be issued directly.`, 'info');
    $('#doReserve').onclick = async () => {
      const r = await mutate('/api/reserve', { memberId: sel.member.id, bookId: sel.book.id, date: fromISO($('#rDate').value) });
      if (!r.ok) toast(r.message, 'bad', 7000);
      else go('reservations');
    };
    check();
  },

  history(root) {
    const v = ui.res;
    const all = state.history.slice().reverse();
    const kinds = [['all', 'All'], ['Pending', 'Pending'], ['Fulfilled', 'Fulfilled'], ['Cancelled', 'Cancelled']];
    $('#hseg', root).innerHTML = kinds.map(([k, l]) => `<button class="${v.hist === k ? 'on' : ''}" data-k="${k}">${l}<span class="c">${k === 'all' ? all.length : all.filter(r => r.status === k).length}</span></button>`).join('');
    $$('#hseg button', root).forEach(b => b.onclick = () => { v.hist = b.dataset.k; this.history(root); });
    const q = v.hq.trim().toLowerCase();
    const rows = all.filter(r => (v.hist === 'all' || r.status === v.hist) && (!q || [r.memberId, r.bookId, memberName(r.memberId), bookTitle(r.bookId)].some(s => s.toLowerCase().includes(q))));
    const tone = { Pending: 'warn', Fulfilled: 'ok', Cancelled: 'grey' };
    $('#htable', root).innerHTML = tableHTML([
      { key: 'm', label: 'Member', render: r => `${esc(memberName(r.memberId))}<div class="sub">${esc(r.memberId)}</div>` },
      { key: 'b', label: 'Book', render: r => `<div class="row">${spine(r.bookId)}<span>${esc(bookTitle(r.bookId))}</span></div>` },
      { key: 'd', label: 'Reserved on', render: r => fmtDate(r.date) },
      { key: 's', label: 'Status', render: r => `<span class="pill ${tone[r.status] || 'grey'}">${esc(r.status)}</span>` },
    ], rows, null, { empty: emptyState({ iconName: 'history', title: all.length ? 'No reservations match' : 'No reservations yet', compact: true }) });
  },
};
