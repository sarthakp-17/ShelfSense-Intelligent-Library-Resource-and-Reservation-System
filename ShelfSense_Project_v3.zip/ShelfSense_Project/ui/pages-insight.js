'use strict';
/* ===================================================================
   Search & Explore, Due Dates & Fines, Transaction History,
   Reports, Settings
   =================================================================== */

// =================================================================
// Search & Explore (linear search + merge sort + binary search in C++)
// =================================================================
ui.search = { q: '', field: 'all', status: '', sortKey: 'title', sortDir: 'asc', selected: null };

PAGES.search = {
  title: 'Search & Explore',
  build(root, params) {
    const v = ui.search;
    if (params.has('q')) { v.q = params.get('q'); v.selected = null; }
    const seg = (id, items, cur) => `<div class="seg" id="${id}">${items.map(([k, l]) => `<button data-k="${k}" class="${cur === k ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    root.innerHTML = `
      ${pageHead('Search & Explore', 'Find any book and see where it is right now.')}
      <div class="big-search" style="margin-bottom:12px">${icon('search')}<input class="input" id="searchInput" placeholder="Type a book ID, title or author" value="${esc(v.q)}" autocomplete="off"></div>
      <div class="row wrap" style="margin-bottom:16px">
        ${seg('sfield', [['all', 'All fields'], ['id', 'Book ID'], ['title', 'Title'], ['author', 'Author']], v.field)}
        ${seg('sstatus', [['', 'Any status'], ['Available', 'Available'], ['Issued', 'Issued'], ['Reserved', 'Reserved']], v.status)}
        <span class="spacer"></span>
        <label class="small muted" for="ssort">Sort by</label>
        <select class="input" id="ssort" style="width:130px">${[['title', 'Title'], ['author', 'Author'], ['id', 'Book ID'], ['category', 'Category']].map(([k, l]) => `<option value="${k}" ${v.sortKey === k ? 'selected' : ''}>${l}</option>`).join('')}</select>
        <button class="icon-btn" id="sdir" title="Reverse order">${icon(v.sortDir === 'desc' ? 'arrowDown' : 'arrowUp')}</button>
      </div>
      <div class="grid side">
        <section class="panel"><div class="panel-head"><h2 id="scount">Results</h2><span class="algo-note" id="salgo"></span></div><div class="panel-body flush" id="sresults"></div></section>
        <section class="panel" id="sdetail" style="align-self:start;position:sticky;top:16px"></section>
      </div>`;
    const run = debounce(() => this.update(root), 110);
    $('#searchInput').addEventListener('input', e => { v.q = e.target.value; run(); });
    $$('#sfield button').forEach(b => b.onclick = () => { v.field = b.dataset.k; $$('#sfield button').forEach(x => x.classList.toggle('on', x === b)); this.update(root); });
    $$('#sstatus button').forEach(b => b.onclick = () => { v.status = b.dataset.k; $$('#sstatus button').forEach(x => x.classList.toggle('on', x === b)); this.update(root); });
    $('#ssort').onchange = e => { v.sortKey = e.target.value; this.update(root); };
    $('#sdir').onclick = () => { v.sortDir = v.sortDir === 'asc' ? 'desc' : 'asc'; $('#sdir').innerHTML = icon(v.sortDir === 'desc' ? 'arrowDown' : 'arrowUp'); this.update(root); };
    $('#searchInput').focus();
    this.update(root);
  },
  async update(root) {
    const v = ui.search;
    let res;
    try { res = await apiGet('/api/search', { entity: 'books', q: v.q, field: v.field, status: v.status, sort: v.sortKey, dir: v.sortDir }); }
    catch (e) { toast(e.message, 'bad'); return; }
    if (currentPage !== 'search') return;
    const rows = res.ids.map(id => by.book.get(id)).filter(Boolean);
    if (!v.selected || !rows.some(b => b.id === v.selected)) v.selected = res.exactId && rows.some(b => b.id === res.exactId) ? res.exactId : (rows[0] ? rows[0].id : null);
    $('#scount', root).textContent = v.q || v.status ? `${plural(rows.length, 'result')}` : `All ${plural(rows.length, 'book')}`;
    $('#salgo', root).innerHTML = `${icon('info', 'sm')}<span>${res.exactId ? `Exact ID found by binary search in ${plural(res.binaryComparisons, 'step')}. ` : ''}Linear search checked ${res.linearComparisons}; merge sort ordered them.</span>`;
    const box = $('#sresults', root);
    if (!rows.length) {
      box.innerHTML = emptyState({ iconName: 'search', title: state.books.length ? `Nothing found for “${v.q}”` : 'The catalogue is empty', text: state.books.length ? 'Check the spelling, search all fields, or set the status to any.' : 'Add books in Book Management first.' });
    } else {
      box.innerHTML = `<ul class="result-list">${rows.map(b => `<li data-id="${esc(b.id)}" class="${b.id === v.selected ? 'sel' : ''}">${spine(b.id)}<div class="rt"><b>${esc(b.title)}</b><span>${esc(b.author)}, ${esc(b.category)}</span></div>${statusPill(b.status)}</li>`).join('')}</ul>`;
      $$('li', box).forEach(li => li.onclick = () => { v.selected = li.dataset.id; $$('li', box).forEach(x => x.classList.toggle('sel', x === li)); this.detail(root); });
    }
    this.detail(root);
  },
  detail(root) {
    const box = $('#sdetail', root);
    const b = by.book.get(ui.search.selected);
    if (!b) { box.innerHTML = `<div class="panel-body">${emptyState({ iconName: 'book', title: 'Select a book', text: 'Its availability, borrower and waiting list appear here.', compact: true })}</div>`; return; }
    const loan = by.active.get(b.id);
    const q = by.queue.get(b.id) || [];
    const where = b.status === 'Available' ? `<div class="banner info" style="background:var(--ok-soft)">${icon('check')}<div class="grow"><b>On the shelf.</b> Ready to issue.</div></div>`
      : loan ? `<div class="banner info">${icon('clock')}<div class="grow"><b>On loan to ${esc(memberName(loan.memberId))}</b> until ${fmtDate(loan.dueDate)}. ${daysText(loan.daysLeft)}.</div></div>`
      : `<div class="banner">${icon('bookmark')}<div class="grow"><b>Held for the reservation queue.</b></div></div>`;
    box.innerHTML = `<div class="panel-body" style="padding-top:18px">
        <div class="row" style="margin-bottom:10px">${spine(b.id)}${statusPill(b.status)}</div>
        <div class="detail-title">${esc(b.title)}</div><div class="muted" style="margin-bottom:14px">${esc(b.author)}</div>
        ${where}
        <dl class="kv"><dt>Category</dt><dd>${esc(b.category)}</dd><dt>Times issued</dt><dd class="num">${b.timesIssued}</dd><dt>Waiting list</dt><dd>${q.length ? q.map(r => `${r.position}. ${esc(memberName(r.memberId))}`).join('<br>') : 'Nobody waiting'}</dd></dl>
        <div class="row wrap" style="margin-top:18px">
          ${b.status === 'Available' ? `<button class="btn primary sm" id="dIssue">${icon('issue', 'sm')}Issue this book</button>` : `<button class="btn primary sm" id="dReserve">${icon('bookmark', 'sm')}Reserve</button>`}
          <button class="btn sm" id="dMore">${icon('history', 'sm')}Loan history</button>
        </div></div>`;
    const bind = (id, fn) => { const el = $('#' + id, box); if (el) el.onclick = fn; };
    bind('dIssue', () => go('circulation', { tab: 'issue', book: b.id }));
    bind('dReserve', () => go('reservations', { book: b.id }));
    bind('dMore', () => openBookDrawer(b.id));
  },
};

// =================================================================
// Due Dates & Fines
// =================================================================
ui.due = { tab: 'all', q: '' };

PAGES.due = {
  title: 'Due Dates & Fines',
  build(root, params) {
    const v = ui.due;
    if (params.get('tab')) v.tab = params.get('tab');
    const s = state.stats, set = state.settings;
    const late = state.records.filter(r => r.status !== 'Issued' && r.fine > 0);
    root.innerHTML = `
      ${pageHead('Due Dates & Fines', 'Follow up on overdue books and loans that are due soon.')}
      <section class="panel" style="margin-bottom:18px"><div class="summary-strip">
        <div><div class="k">Overdue loans</div><div class="figure ${s.overdue ? 'fig-bad' : ''}">${s.overdue}</div><div class="d">${money(s.finesAccruing)} if returned today</div></div>
        <div><div class="k">Due within ${plural(set.dueSoonDays, 'day')}</div><div class="figure ${s.dueSoon ? 'fig-warn' : ''}">${s.dueSoon}</div><div class="d">Not yet overdue</div></div>
        <div><div class="k">Books on loan</div><div class="figure">${s.activeLoans}</div><div class="d">${plural(state.members.filter(m => m.activeLoans).length, 'member')}</div></div>
        <div><div class="k">Fines recorded on returns</div><div class="figure">${money(s.finesCollected)}</div><div class="d">From ${plural(late.length, 'late return')}</div></div>
      </div></section>
      <div class="tabs" id="dtabs"></div>
      <section class="panel">
        <div class="toolbar"><div class="search">${icon('search')}<input class="input" id="dq" placeholder="Filter by member or book" value="${esc(v.q)}"></div><span class="spacer"></span><button class="btn sm" id="dexport">${icon('download', 'sm')}Export CSV</button></div>
        <div id="dtable"></div>
      </section>
      <section class="panel" style="margin-top:18px"><div class="panel-body" style="padding-top:16px">
        <div class="row" style="align-items:flex-start;gap:14px"><span class="qi-solo">${icon('coin')}</span>
        <div style="flex:1"><h3>Fine policy</h3><p class="muted" style="margin-top:4px">${money(set.finePerDay)} for each day a book is returned after its due date${set.finePerDay !== set.defaultFinePerDay ? ` (the original console rule was ${money(set.defaultFinePerDay)})` : ', the same rule as the console version’s returnBook()'}. Fines on books still on loan are estimates: what the member would pay if the book came back today. Return dates are not stored in borrow_records.txt; they appear in Transaction History.</p></div>
        <button class="btn sm" onclick="go('settings')">Change in Settings</button></div>
      </div></section>`;
    $('#dq', root).addEventListener('input', debounce(e => { v.q = e.target.value; this.update(root); }, 100));
    $('#dexport', root).onclick = () => this.exportCSV();
    this.update(root);
  },
  rows() {
    const v = ui.due, q = v.q.trim().toLowerCase();
    const matches = r => !q || [r.bookId, r.memberId, bookTitle(r.bookId), memberName(r.memberId)].some(x => x.toLowerCase().includes(q));
    if (v.tab === 'fines') return state.records.filter(r => r.status !== 'Issued' && r.fine > 0 && matches(r)).reverse();
    const active = state.dueOrder.map(d => by.active.get(d.bookId)).filter(Boolean);   // heap order
    const pick = { all: () => true, overdue: r => r.state === 'overdue', soon: r => r.state === 'dueSoon' }[v.tab] || (() => true);
    return active.filter(r => pick(r) && matches(r));
  },
  update(root) {
    const v = ui.due, s = state.stats;
    const tabs = [['all', 'All on loan', s.activeLoans], ['overdue', 'Overdue', s.overdue], ['soon', 'Due soon', s.dueSoon], ['fines', 'Fines recorded', state.records.filter(r => r.status !== 'Issued' && r.fine > 0).length]];
    $('#dtabs', root).innerHTML = tabs.map(([k, l, n]) => `<button data-k="${k}" class="${v.tab === k ? 'on' : ''}">${l} <span class="pill grey plain">${n}</span></button>`).join('');
    $$('#dtabs button', root).forEach(b => b.onclick = () => { v.tab = b.dataset.k; this.update(root); });
    const rows = this.rows();
    const member = id => { const m = by.member.get(id); return `<span class="nw">${esc(m ? m.name : id)}</span><div class="sub nw">${esc(id)}${m && m.phone ? ', ' + esc(m.phone) : ''}</div>`; };
    const book = r => `<div class="row">${spine(r.bookId)}<span class="title-cell">${esc(bookTitle(r.bookId))}</span></div>`;
    let columns;
    if (v.tab === 'fines') {
      columns = [
        { key: 'b', label: 'Book', render: book },
        { key: 'm', label: 'Member', render: r => member(r.memberId) },
        { key: 'i', label: 'Issue date', render: r => fmtDate(r.issueDate) },
        { key: 'd', label: 'Due date', render: r => fmtDate(r.dueDate) },
        { key: 'f', label: 'Fine', cls: 'num', render: r => `<b>${money(r.fine)}</b>` },
      ];
    } else {
      columns = [
        { key: 'b', label: 'Book', render: book },
        { key: 'm', label: 'Member', render: r => member(r.memberId) },
        { key: 'd', label: 'Due date', render: r => `<span class="nowrap">${fmtDate(r.dueDate)}</span><div class="sub nowrap">Issued ${fmtDate(r.issueDate)}</div>` },
        { key: 'o', label: 'Overdue days', cls: 'num', render: r => r.daysLeft < 0 ? `<b class="fig-bad">${-r.daysLeft}</b>` : '<span class="faint">0</span>' },
        { key: 's', label: 'Status', render: r => duePill(r.daysLeft) },
        { key: 'f', label: 'Fine so far', cls: 'num', render: r => r.estFine > 0 ? money(r.estFine) : '<span class="faint">None</span>' },
        { key: 'a', label: '', cls: 'actions', render: r => `<button class="btn sm" data-ret="${esc(r.bookId)}">Return</button> <button class="btn sm ghost" data-ren="${esc(r.bookId)}">Renew</button>` },
      ];
    }
    const emptyText = { all: ['No books are on loan', 'Issued books will appear here.'], overdue: ['Nothing is overdue', 'Every loan is within its due date.'], soon: [`Nothing is due in the next ${plural(state.settings.dueSoonDays, 'day')}`, 'Loans due soon will appear here.'], fines: ['No fines recorded', 'Fines appear here when a book is returned late.'] }[v.tab];
    const box = $('#dtable', root);
    box.innerHTML = tableHTML(columns, rows, null, { empty: emptyState({ iconName: v.tab === 'overdue' ? 'check' : 'calendar', title: v.q ? 'No loans match the filter' : emptyText[0], text: v.q ? '' : emptyText[1], compact: true }), rowAttr: r => r.state === 'overdue' ? 'style="box-shadow:inset 3px 0 0 var(--bad)"' : r.state === 'dueSoon' ? 'style="box-shadow:inset 3px 0 0 var(--warn)"' : '' });
    $$('[data-ret]', box).forEach(b => b.onclick = () => go('circulation', { tab: 'return', book: b.dataset.ret }));
    $$('[data-ren]', box).forEach(b => b.onclick = () => go('circulation', { tab: 'renew', book: b.dataset.ren }));
  },
  exportCSV() {
    const rows = this.rows();
    if (ui.due.tab === 'fines') downloadCSV('shelfsense_fines.csv', ['Book ID', 'Title', 'Member ID', 'Member', 'Issue date', 'Due date', 'Fine'], rows.map(r => [r.bookId, bookTitle(r.bookId), r.memberId, memberName(r.memberId), r.issueDate, r.dueDate, r.fine]));
    else downloadCSV('shelfsense_due_dates.csv', ['Book ID', 'Title', 'Member ID', 'Member', 'Issue date', 'Due date', 'Overdue days', 'Fine so far'], rows.map(r => [r.bookId, bookTitle(r.bookId), r.memberId, memberName(r.memberId), r.issueDate, r.dueDate, Math.max(0, -r.daysLeft), r.estFine]));
  },
};

// =================================================================
// Transaction History (stack: newest on top)
// =================================================================
const TX = {
  ISSUE: ['Issue', 'blue'], RETURN: ['Return', 'ok'], AUTO_ISSUE: ['Issued from queue', 'res'], RENEW: ['Renewal', 'blue'],
  RESERVE: ['Reservation', 'res'], CANCEL_RESERVATION: ['Reservation cancelled', 'grey'],
  ADD_BOOK: ['Book added', 'grey'], UPDATE_BOOK: ['Book edited', 'grey'], DELETE_BOOK: ['Book deleted', 'bad'],
  ADD_MEMBER: ['Member registered', 'grey'], UPDATE_MEMBER: ['Member edited', 'grey'], DELETE_MEMBER: ['Member deleted', 'bad'],
  SETTINGS: ['Settings changed', 'grey'],
};
ui.tx = { q: '', type: '', member: '', book: '', from: '', to: '', limit: 200 };

PAGES.transactions = {
  title: 'Transaction History',
  build(root) {
    const v = ui.tx;
    const groups = [['', 'All types'], ['circ', 'Issues and returns'], ['res', 'Reservation activity'], ['cat', 'Catalogue and member changes'], ...Object.entries(TX).map(([k, [l]]) => [k, l])];
    root.innerHTML = `
      ${pageHead('Transaction History', 'Every issue, return, reservation and record change made in ShelfSense, newest first.', `<button class="btn" id="txExport">${icon('download')}Export CSV</button>`)}
      <section class="panel">
        <div class="toolbar">
          <div class="search narrow">${icon('search')}<input class="input" id="txq" placeholder="Search details" value="${esc(v.q)}"></div>
          <select class="input" id="txType" style="width:190px" aria-label="Type">${groups.map(([k, l]) => `<option value="${k}" ${v.type === k ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>
          <input class="input" id="txMember" list="txMembers" placeholder="Member ID" style="width:130px" value="${esc(v.member)}"><datalist id="txMembers">${state.members.map(m => `<option value="${esc(m.id)}">${esc(m.name)}</option>`).join('')}</datalist>
          <input class="input" id="txBook" list="txBooks" placeholder="Book ID" style="width:120px" value="${esc(v.book)}"><datalist id="txBooks">${state.books.map(b => `<option value="${esc(b.id)}">${esc(b.title)}</option>`).join('')}</datalist>
          <label class="small muted" for="txFrom">From</label><input class="input" type="date" id="txFrom" value="${v.from}">
          <label class="small muted" for="txTo">to</label><input class="input" type="date" id="txTo" value="${v.to}">
          <button class="btn ghost sm" id="txClear">Clear filters</button>
        </div>
        <div id="txTable"></div>
        <div class="table-foot" id="txFoot"></div>
      </section>`;
    const upd = debounce(() => { v.limit = 200; this.update(root); }, 100);
    $('#txq').oninput = e => { v.q = e.target.value; upd(); };
    $('#txType').onchange = e => { v.type = e.target.value; upd(); };
    $('#txMember').oninput = e => { v.member = e.target.value.trim(); upd(); };
    $('#txBook').oninput = e => { v.book = e.target.value.trim(); upd(); };
    $('#txFrom').onchange = e => { v.from = e.target.value; upd(); };
    $('#txTo').onchange = e => { v.to = e.target.value; upd(); };
    $('#txClear').onclick = () => { Object.assign(ui.tx, { q: '', type: '', member: '', book: '', from: '', to: '', limit: 200 }); this.build(root); };
    $('#txExport').onclick = () => downloadCSV('shelfsense_transactions.csv', ['No.', 'Date and time', 'Type', 'Member ID', 'Book ID', 'Details'], this.rows().map(t => [t.id, t.time, (TX[t.type] || [t.type])[0], t.memberId, t.bookId, t.details]));
    this.update(root);
  },
  rows() {
    const v = ui.tx;
    const groupOf = { circ: ['ISSUE', 'RETURN', 'AUTO_ISSUE', 'RENEW'], res: ['RESERVE', 'CANCEL_RESERVATION', 'AUTO_ISSUE'], cat: ['ADD_BOOK', 'UPDATE_BOOK', 'DELETE_BOOK', 'ADD_MEMBER', 'UPDATE_MEMBER', 'DELETE_MEMBER'] };
    const q = v.q.toLowerCase(), m = v.member.toLowerCase(), b = v.book.toLowerCase();
    const from = v.from ? dayNum(fromISO(v.from)) : -Infinity, to = v.to ? dayNum(fromISO(v.to)) : Infinity;
    return state.transactions.filter(t => {
      if (v.type && (groupOf[v.type] ? !groupOf[v.type].includes(t.type) : t.type !== v.type)) return false;
      if (m && t.memberId.toLowerCase() !== m) return false;
      if (b && t.bookId.toLowerCase() !== b) return false;
      const d = dayNum((t.time || '').split(' ')[0]);
      if (d < from || d > to) return false;
      return !q || t.details.toLowerCase().includes(q);
    });
  },
  update(root) {
    const v = ui.tx;
    const all = this.rows();
    const rows = all.slice(0, v.limit);
    const box = $('#txTable', root);
    box.innerHTML = tableHTML([
      { key: 'n', label: 'No.', cls: 'num', render: t => `<span class="faint">${t.id}</span>` },
      { key: 't', label: 'Date and time', render: t => `<span class="nowrap">${fmtStamp(t.time)}</span>` },
      { key: 'y', label: 'Type', render: t => { const [l, c] = TX[t.type] || [t.type, 'grey']; return `<span class="pill ${c}">${esc(l)}</span>`; } },
      { key: 'm', label: 'Member', render: t => t.memberId ? `<span class="nw">${esc(memberName(t.memberId))}</span><div class="sub">${esc(t.memberId)}</div>` : '<span class="faint">None</span>' },
      { key: 'b', label: 'Book', render: t => t.bookId ? spine(t.bookId) : '<span class="faint">None</span>' },
      { key: 'd', label: 'Details', render: t => esc(t.details) },
    ], rows, null, { empty: emptyState({ iconName: 'history', title: state.transactions.length ? 'No transactions match these filters' : 'No transactions yet', text: state.transactions.length ? 'Widen the date range or clear a filter.' : 'Issues, returns and reservations will be recorded here.', compact: true }) });
    $('#txFoot', root).innerHTML = `<span>${all.length < state.transactions.length ? `${all.length} of ${state.transactions.length}` : all.length} transactions${rows.length < all.length ? `, showing the newest ${rows.length} <button class="link" id="txMore">Show 200 more</button>` : ''}</span><span>Stored in the transaction stack (newest on top). Changes made in the console program are not recorded here.</span>`;
    const more = $('#txMore', root);
    if (more) more.onclick = () => { v.limit += 200; this.update(root); };
  },
};

// =================================================================
// Reports
// =================================================================
const MIN_HISTORY = 5;   // loans needed before "most issued" is meaningful
ui.reports = { activity: { sortKey: 'loans', sortDir: 'desc' } };

PAGES.reports = {
  title: 'Reports',
  build(root) {
    const s = state.stats;
    const cats = new Map();
    state.books.forEach(b => cats.set(b.category, (cats.get(b.category) || 0) + 1));
    const issueCounts = new Map();
    state.records.forEach(r => issueCounts.set(r.bookId, (issueCounts.get(r.bookId) || 0) + 1));
    const top = [...issueCounts.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], undefined, { numeric: true })).slice(0, 8);
    const bars = (pairs, label) => { const max = Math.max(...pairs.map(p => p[1]), 1); return `<div class="bars">${pairs.map(([k, n]) => `<div class="bar-row"><span class="bl" title="${esc(label(k))}">${esc(label(k))}</span><div class="bar-track"><div class="bar-fill" style="width:${(n / max * 100).toFixed(1)}%"></div></div><span class="bv">${n}</span></div>`).join('')}</div>`; };
    const hist = { Pending: 0, Fulfilled: 0, Cancelled: 0 };
    state.history.forEach(r => { if (hist[r.status] !== undefined) hist[r.status]++; });
    const histTotal = hist.Pending + hist.Fulfilled + hist.Cancelled;
    const onTime = s.returned ? Math.round((s.returned - s.returnedLate) / s.returned * 100) : null;

    root.innerHTML = `
      ${pageHead('Reports', `Library report for ${fmtDate(state.today)}. Every figure is calculated from the current data files.`, `<button class="btn" onclick="window.print()">${icon('printer')}Print</button>`)}
      <section class="panel" style="margin-bottom:18px"><div class="summary-strip" style="grid-template-columns:repeat(6,minmax(0,1fr))">
        <div><div class="k">Total books</div><div class="figure">${s.totalBooks}</div><div class="d">${plural(cats.size, 'category', 'categories')}</div></div>
        <div><div class="k">Registered members</div><div class="figure">${s.members}</div></div>
        <div><div class="k">Loans recorded</div><div class="figure">${s.totalRecords}</div><div class="d">${s.returned} returned</div></div>
        <div><div class="k">Currently issued</div><div class="figure">${s.activeLoans}</div><div class="d">${s.totalBooks ? Math.round(s.issued / s.totalBooks * 100) : 0}% of books</div></div>
        <div><div class="k">Overdue</div><div class="figure ${s.overdue ? 'fig-bad' : ''}">${s.overdue}</div></div>
        <div><div class="k">On-time returns</div><div class="figure">${onTime === null ? 'n/a' : onTime + '%'}</div><div class="d">${onTime === null ? 'No returns yet' : `${s.returned - s.returnedLate} of ${s.returned}`}</div></div>
      </div></section>
      <div class="grid two" style="margin-bottom:18px">
        <section class="panel"><div class="panel-head"><h2>Most frequently issued books</h2><span class="hint">${s.totalRecords >= MIN_HISTORY ? `Based on ${plural(s.totalRecords, 'loan')}` : ''}</span></div><div class="panel-body">
          ${s.totalRecords >= MIN_HISTORY ? bars(top, id => bookTitle(id)) : emptyState({ iconName: 'chart', title: 'Not enough loan history yet', text: `${plural(s.totalRecords, 'loan')} recorded. This report needs at least ${MIN_HISTORY} to be meaningful.`, compact: true })}
        </div></section>
        <section class="panel"><div class="panel-head"><h2>Books by category</h2></div><div class="panel-body">
          ${cats.size ? bars([...cats.entries()].sort((a, b) => b[1] - a[1]), k => k) : emptyState({ iconName: 'book', title: 'No books yet', compact: true })}
        </div></section>
      </div>
      <div class="stack" style="margin-bottom:18px">
        <section class="panel"><div class="panel-head"><h2>Currently issued books</h2><button class="btn sm ghost no-print" id="expIssued">${icon('download', 'sm')}CSV</button></div><div class="panel-body flush">${this.loanTable(state.dueOrder, 'No books are on loan.')}</div></section>
        <section class="panel"><div class="panel-head"><h2>Overdue books</h2><button class="btn sm ghost no-print" id="expOverdue">${icon('download', 'sm')}CSV</button></div><div class="panel-body flush">${this.loanTable(state.dueOrder.filter(d => d.daysLeft < 0), 'Nothing is overdue.')}</div></section>
      </div>
      <section class="panel" style="margin-bottom:18px"><div class="panel-head"><h2>Member activity</h2><button class="btn sm ghost no-print" id="expMembers">${icon('download', 'sm')}CSV</button></div><div class="panel-body flush" id="activity"></div></section>
      <section class="panel"><div class="panel-head"><h2>Reservation outcomes</h2></div><div class="panel-body">
        ${histTotal ? bars([['Fulfilled', hist.Fulfilled], ['Pending', hist.Pending], ['Cancelled', hist.Cancelled]], k => k) : emptyState({ iconName: 'bookmark', title: 'No reservations have been made yet', compact: true })}
      </div></section>`;
    this.activity(root);
    const loanCSV = (name, list) => downloadCSV(name, ['Book ID', 'Title', 'Member ID', 'Member', 'Issue date', 'Due date', 'Days left'], list.map(d => [d.bookId, bookTitle(d.bookId), d.memberId, memberName(d.memberId), d.issueDate, d.dueDate, d.daysLeft]));
    $('#expIssued').onclick = () => loanCSV('shelfsense_issued.csv', state.dueOrder);
    $('#expOverdue').onclick = () => loanCSV('shelfsense_overdue.csv', state.dueOrder.filter(d => d.daysLeft < 0));
    $('#expMembers').onclick = () => downloadCSV('shelfsense_member_activity.csv', ['Member ID', 'Name', 'Total loans', 'On loan', 'Overdue', 'Reservations', 'Fines recorded'], state.members.map(m => [m.id, m.name, m.totalBorrows, m.activeLoans, m.overdue, m.pending, m.fines]));
  },
  loanTable(list, emptyText) {
    return tableHTML([
      { key: 'b', label: 'Book', render: d => `<div class="row">${spine(d.bookId)}<span class="title-cell">${esc(bookTitle(d.bookId))}</span></div>` },
      { key: 'i', label: 'Issued', render: d => `<span class="nowrap">${fmtDate(d.issueDate)}</span>` },
      { key: 'm', label: 'Member', render: d => `<span class="nw">${esc(memberName(d.memberId))}</span>` },
      { key: 'd', label: 'Due', render: d => `<span class="nowrap">${fmtDate(d.dueDate)}</span>` },
      { key: 's', label: 'Status', render: d => duePill(d.daysLeft) },
    ], list, null, { empty: emptyState({ iconName: 'check', title: emptyText, compact: true }) });
  },
  activity(root) {
    const view = ui.reports.activity;
    const cols = [
      { key: 'name', label: 'Member', sort: m => m.name, render: m => `${esc(m.name)}<div class="sub">${esc(m.id)}</div>` },
      { key: 'loans', label: 'Total loans', cls: 'num', sort: m => m.totalBorrows, render: m => m.totalBorrows },
      { key: 'active', label: 'On loan', cls: 'num', sort: m => m.activeLoans, render: m => m.activeLoans },
      { key: 'overdue', label: 'Overdue', cls: 'num', sort: m => m.overdue, render: m => m.overdue ? `<b class="fig-bad">${m.overdue}</b>` : 0 },
      { key: 'res', label: 'Reservations', cls: 'num', sort: m => m.pending, render: m => m.pending },
      { key: 'fines', label: 'Fines recorded', cls: 'num', sort: m => m.fines, render: m => money(m.fines) },
    ];
    const box = $('#activity', root);
    box.innerHTML = tableHTML(cols, sortRows(cols, state.members, view), view, { empty: emptyState({ iconName: 'users', title: 'No members registered yet', compact: true }) });
    bindSort(box, view, () => this.activity(root));
  },
};

// =================================================================
// Settings
// =================================================================
PAGES.settings = {
  title: 'Settings',
  build(root) {
    const s = state.settings;
    root.innerHTML = `
      ${pageHead('Settings', 'Appearance, circulation rules and your data files.')}
      <div class="stack" style="max-width:920px">
        <section class="panel"><div class="panel-head"><h2>Appearance</h2></div><div class="panel-body">
          <div class="seg" id="themeSeg">${[['system', 'Match Windows'], ['light', 'Light'], ['dark', 'Dark']].map(([k, l]) => `<button data-k="${k}" class="${s.theme === k ? 'on' : ''}">${l}</button>`).join('')}</div>
        </div></section>

        <section class="panel"><div class="panel-head"><h2>Circulation rules</h2></div><div class="panel-body">
          <div class="form-grid" style="grid-template-columns:repeat(3,minmax(0,1fr))">
            <div class="field"><label for="sFine">Fine per late day (Rs.)</label><input class="input" id="sFine" type="number" min="0" max="1000" step="0.5" value="${s.finePerDay}"><div class="help">Console default: ${money(s.defaultFinePerDay)}</div></div>
            <div class="field"><label for="sLoan">Default loan period (days)</label><input class="input" id="sLoan" type="number" min="1" max="365" value="${s.loanDays}"><div class="help">Pre-fills due dates. You can still change each one.</div></div>
            <div class="field"><label for="sSoon">“Due soon” window (days)</label><input class="input" id="sSoon" type="number" min="0" max="60" value="${s.dueSoonDays}"><div class="help">Loans due within this many days are flagged.</div></div>
          </div>
          <p class="small muted" style="margin-top:12px">A new fine rate applies to returns from now on. Fines already recorded do not change.</p>
          <div class="row" style="margin-top:14px"><button class="btn primary" id="sSave">Save rules</button><button class="btn ghost" id="sReset">Restore defaults</button></div>
        </div></section>

        <section class="panel"><div class="panel-head"><h2>Data and backups</h2></div><div class="panel-body">
          <dl class="kv"><dt>Data folder</dt><dd><code>${esc(state.dataDir)}</code></dd><dt>Latest backup</dt><dd>${state.lastBackup ? `<code>${esc(state.lastBackup)}</code>` : '<span class="faint">None yet</span>'}</dd></dl>
          <p class="small muted" style="margin-top:12px">ShelfSense copies every data file into <code>backups</code> each time it starts, and keeps the newest 15 copies. Files are saved after every change by writing a temporary file and then replacing the old one, so an interrupted save cannot leave half a file.</p>
          <div class="row" style="margin-top:14px"><button class="btn" id="sOpen">${icon('folder')}Open data folder</button><button class="btn" id="sBackup">${icon('shield')}Back up now</button></div>
        </div></section>

        <section class="panel"><div class="panel-head"><h2>Data check</h2><span class="hint">Run when ShelfSense started</span></div><div class="panel-body">
          ${state.warnings.length ? `<ul class="checks">${state.warnings.map(w => checkItem('warn', esc(w))).join('')}</ul><p class="small muted" style="margin-top:12px">ShelfSense reports these problems but does not change the records by itself. The original files are kept in the start-up backup.</p>`
          : `<ul class="checks">${checkItem('pass', 'All data files were read completely, and books, loans and reservations agree with each other.')}</ul>`}
        </div></section>

        <section class="panel"><div class="panel-head"><h2>About ShelfSense</h2><span class="hint">Version ${esc(state.version)}</span></div><div class="panel-body flush">
          ${tableHTML([{ key: 'w', label: 'What', render: r => r[0] }, { key: 's', label: 'Data structure or algorithm', render: r => `<b>${r[1]}</b>` }, { key: 'c', label: 'Cost', render: r => `<span class="nowrap">${r[2]}</span>` }], [
            ['Books, members, loans', 'Singly linked lists', 'O(n) search'],
            ['Reservation waiting lists', 'FIFO queue', 'O(1) enqueue'],
            ['Due dates and overdue checks', 'Binary min-heap', 'O(log n) insert'],
            ['Transaction history', 'Stack', 'O(1) push'],
            ['Sorting tables', 'Merge sort', 'O(n log n)'],
            ['Exact ID lookup', 'Binary search', 'O(log n)'],
            ['Title and author search', 'Linear search', 'O(n)'],
            ['Storage', 'Pipe-separated text files', 'Saved after every change'],
          ], null)}
        </div></section>
      </div>`;
    const save = async theme => {
      const r = await mutate('/api/settings', { finePerDay: $('#sFine').value, loanDays: $('#sLoan').value, dueSoonDays: $('#sSoon').value, theme: theme || state.settings.theme });
      if (!r.ok) toast(r.message, 'bad', 7000);
      applyTheme();
    };
    $$('#themeSeg button').forEach(b => b.onclick = () => {
      const s2 = state.settings;
      mutate('/api/settings', { finePerDay: s2.finePerDay, loanDays: s2.loanDays, dueSoonDays: s2.dueSoonDays, theme: b.dataset.k }, { silent: true }).then(applyTheme);
    });
    $('#sSave').onclick = () => save();
    $('#sReset').onclick = () => { $('#sFine').value = state.settings.defaultFinePerDay; $('#sLoan').value = state.settings.defaultLoanDays; $('#sSoon').value = state.settings.defaultDueSoonDays; save(); };
    $('#sOpen').onclick = async () => { const r = await api('/api/open-data-folder', {}); toast(r.message, r.ok ? 'ok' : 'bad'); };
    $('#sBackup').onclick = async () => { const r = await mutate('/api/backup', {}); if (!r.ok) toast(r.message, 'bad', 7000); };
  },
};
