#ifndef BOOKLINKEDLIST_H
#define BOOKLINKEDLIST_H

#include "BookNode.h"
#include "ReservationQueue.h"
#include <vector>

class BookLinkedList
{
private:
    BookNode *head;

public:
    BookLinkedList();

    bool addBook(Book newBook);
    void displayBooks(const ReservationQueue &reservationQueue) const;
    void searchBook(string bookId) const;
    void updateBook(string bookId);
    void deleteBook(string bookId);
    bool saveToFile(const string &filename) const;
    bool loadFromFile(const string &filename);
    Book *findBook(string bookId);

    // ---- GUI-layer additions (non-interactive, no console I/O) ----
    ~BookLinkedList();
    vector<Book> getAllBooks() const;          // traverse list head -> tail
    bool updateBookDetails(string bookId, string newTitle,
                           string newAuthor, string newCategory);
    bool removeBook(string bookId);            // true if a node was unlinked
    int countBooks() const;
};

#endif