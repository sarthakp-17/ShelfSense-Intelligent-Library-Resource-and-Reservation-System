
#ifndef RESERVATIONQUEUE_H
#define RESERVATIONQUEUE_H

#include "ReservationNode.h"
#include <string>
#include <vector>

using namespace std;

class ReservationQueue
{
private:
    ReservationNode *front;
    ReservationNode *rear;

public:
    ReservationQueue();
    ~ReservationQueue();

    bool enqueue(Reservation reservation);
    void displayReservations() const;

    ReservationNode *getFront() const;

    bool saveToFile(string filename);   // was void; now reports failure
    void loadFromFile(string filename);

    bool dequeueNextForBook(string bookId, Reservation &result);
    bool findReservationForBook(
        string bookId,
        Reservation &result) const;

    bool removeNextReservationForBook(
        string bookId);

    // ---- GUI-layer additions ----
    vector<Reservation> getAllReservations() const;   // front -> rear (FIFO order)
    bool removeReservation(string memberId, string bookId);
    int countForBook(string bookId) const;
    bool hasReservation(string memberId, string bookId) const;
};

#endif
