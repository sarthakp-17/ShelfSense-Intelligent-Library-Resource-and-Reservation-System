#ifndef LIBRARYSERVICE_H
#define LIBRARYSERVICE_H

// ShelfSense GUI service layer.
// Wraps the existing ShelfSense data structures (BookLinkedList,
// MemberLinkedList, BorrowRecordLinkedList, ReservationQueue,
// ReservationHistory) plus TransactionStack, and exposes non-interactive
// operations that apply the same rules as the console functions in
// LibraryManager.cpp (issueBook / returnBook / renewBook / reserveBook),
// so the GUI never needs cin / cout.
//
// Every operation validates first and changes nothing when it fails.
// After a successful change, all files are saved atomically (saveAll).

#include <string>
#include <vector>
#include "BookLinkedList.h"
#include "MemberLinkedList.h"
#include "BorrowRecordLinkedList.h"
#include "ReservationQueue.h"
#include "ReservationHistory.h"
#include "TransactionStack.h"
#include "LibraryManager.h"
#include "LibrarySettings.h"

using namespace std;

struct OpResult
{
    bool ok;
    bool saved;            // false if the change could not be written to disk
    string message;
    int lateDays;
    double fine;
    string autoIssuedTo;   // member who received the book automatically (reservation)
    string borrowerId;     // return preview: current borrower
    string dueDate;        // return preview: current due date
    string nextInQueue;    // return preview: member at the front of the FIFO queue

    OpResult() : ok(false), saved(true), lateDays(0), fine(0.0) {}
};

class LibraryService
{
public:
    // Default fine (Rs. per late day) used by the original console returnBook().
    // The active value lives in settings.finePerDay and can be changed in the GUI.
    static const double FINE_PER_DAY;
    static const int BACKUPS_TO_KEEP = 15;

    BookLinkedList books;
    MemberLinkedList members;
    BorrowRecordLinkedList borrows;
    ReservationQueue queue;
    ReservationHistory history;
    TransactionStack transactions;
    LibrarySettings settings;

    explicit LibraryService(const string &dataDirectory);

    // Makes a backup copy of the existing files, then loads them.
    // Never writes to the data files themselves.
    void loadAll();
    bool saveAll();
    string dataPath(const string &file) const;

    // Problems found while loading (skipped lines, inconsistent records).
    vector<string> loadWarnings;
    string lastBackupDir;
    string lastSaveError;

    // Catalogue
    OpResult addBook(string id, string title, string author, string category);
    OpResult updateBook(string id, string title, string author, string category);
    OpResult deleteBook(string id);

    // Members
    OpResult addMember(string id, string name, string email, string phone);
    OpResult updateMember(string id, string name, string email, string phone);
    OpResult deleteMember(string id);

    // Circulation
    OpResult issueBook(string memberId, string bookId, string issueDate, string dueDate);
    OpResult previewReturn(string bookId, string returnDate);   // read-only
    OpResult returnBook(string bookId, string returnDate, string nextDueDate);
    OpResult renewBook(string bookId, string newDueDate);
    OpResult reserveBook(string memberId, string bookId, string reservationDate);
    OpResult cancelReservation(string memberId, string bookId);
    // Issues a book that is not on loan to the member at the front of its FIFO queue.
    OpResult processNextReservation(string bookId, string issueDate, string dueDate);

    // Settings and maintenance
    OpResult updateSettings(double finePerDay, int loanDays, int dueSoonDays, string theme);
    OpResult createBackup();

    int activeLoansForMember(const string &memberId) const;

    static string today();                       // DD-MM-YYYY from system clock
    static string addDays(const string &date, int days);

    // The data files ShelfSense owns (used for backups and integrity checks)
    static vector<string> dataFileNames();

private:
    string dataDir;
    OpResult finish(OpResult r);                 // saveAll() + report save failures
    bool backupTo(const string &folder);
    void pruneBackups();
    void checkIntegrity();
};

#endif
