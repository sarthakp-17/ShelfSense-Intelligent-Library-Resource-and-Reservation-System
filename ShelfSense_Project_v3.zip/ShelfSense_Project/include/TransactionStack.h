#ifndef TRANSACTIONSTACK_H
#define TRANSACTIONSTACK_H

#include "Transaction.h"
#include <string>
#include <vector>
using namespace std;

// Linked-list based Stack (LIFO) of transactions.
// push / pop / peek are O(1). The top always holds the most recent event,
// which is exactly the order a librarian wants to read an audit trail in.
class TransactionNode
{
public:
    Transaction data;
    TransactionNode *next;
    TransactionNode(Transaction t);
};

class TransactionStack
{
private:
    TransactionNode *top;
    int count;
    long long nextId;

public:
    TransactionStack();
    ~TransactionStack();

    void push(Transaction t);
    bool pop(Transaction &out);
    bool peek(Transaction &out) const;
    bool isEmpty() const;
    int size() const;

    // Create + push a transaction with an auto id and the current timestamp
    void record(string type, string memberId, string bookId, string details);

    vector<Transaction> toVector() const; // top -> bottom (newest first)

    bool saveToFile(const string &filename) const;
    bool loadFromFile(const string &filename);
};

#endif
