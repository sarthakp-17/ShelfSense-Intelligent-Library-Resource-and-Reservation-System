#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <string>
using namespace std;

// One circulation / catalogue event (issue, return, renew, reserve ...)
class Transaction
{
private:
    long long txnId;
    string type;       // ISSUE, RETURN, RENEW, RESERVE, AUTO_ISSUE, CANCEL_RESERVATION,
                       // ADD_BOOK, UPDATE_BOOK, DELETE_BOOK, ADD_MEMBER, UPDATE_MEMBER, DELETE_MEMBER
    string memberId;
    string bookId;
    string timestamp;  // DD-MM-YYYY HH:MM (system clock)
    string details;

public:
    Transaction();
    Transaction(long long id, string txnType, string mId, string bId,
                string time, string info);

    long long getTxnId() const;
    string getType() const;
    string getMemberId() const;
    string getBookId() const;
    string getTimestamp() const;
    string getDetails() const;
};

#endif
