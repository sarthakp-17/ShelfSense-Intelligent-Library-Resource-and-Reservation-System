#ifndef FILESTORE_H
#define FILESTORE_H

// Small, dependency-free helpers that make the existing text-file storage safer.
// The record format written by the original classes is NOT changed; these helpers
// only control *how* files are replaced and backed up.

#include <string>
#include <vector>
using namespace std;

namespace FileStore
{
    string joinPath(const string &a, const string &b);
    bool fileExists(const string &path);
    bool dirExists(const string &path);
    bool makeDir(const string &path);              // true if it exists afterwards
    bool copyFile(const string &from, const string &to);
    bool removeFile(const string &path);
    bool removeEmptyDir(const string &path);

    // Atomically replaces 'target' with 'tempFile' (rename over the old file).
    // If the program stops half-way through a save, the old file stays intact.
    bool replaceFile(const string &tempFile, const string &target);

    // Number of non-empty lines, or -1 when the file cannot be opened.
    int countNonEmptyLines(const string &path);

    // Names of the sub-folders of 'path' (not recursive), unsorted.
    vector<string> listSubdirs(const string &path);

    // Local time as YYYYMMDD-HHMMSS (sortable folder name for backups).
    string timestampForFolder();
}

#endif
