#ifndef DUEDATEHEAP_H
#define DUEDATEHEAP_H

#include <string>
#include <vector>
#include "BorrowRecord.h"
using namespace std;

// Converts DD-MM-YYYY to a day number (days since 01-01-1970).
// Returns -1 when the date is not valid.
long dateToDayNumber(const string &ddmmyyyy);
bool isValidDate(const string &ddmmyyyy);

struct DueEntry
{
    long dueKey;          // day number of the due date (heap key)
    BorrowRecord record;
};

// Array-based Binary Min-Heap keyed on due date.
// The earliest deadline is always at index 0:
//   peekMin O(1), insert O(log n), extractMin O(log n).
class DueDateHeap
{
private:
    vector<DueEntry> heap;

    void siftUp(int index);
    void siftDown(int index);

public:
    void insert(const BorrowRecord &record);
    bool peekMin(DueEntry &out) const;
    bool extractMin(DueEntry &out);
    bool isEmpty() const;
    int size() const;
    void clear();
};

#endif
