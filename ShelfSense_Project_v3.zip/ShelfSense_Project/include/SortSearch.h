#ifndef SORTSEARCH_H
#define SORTSEARCH_H

#include <string>
#include <vector>
#include "Book.h"
#include "Member.h"
using namespace std;

// Merge Sort: O(n log n), stable.
// key: "id", "title", "author", "category", "status"  (books)
//      "id", "name", "email"                          (members)
void mergeSortBooks(vector<Book> &books, const string &key, bool ascending);
void mergeSortMembers(vector<Member> &members, const string &key, bool ascending);

// Binary Search: O(log n) on a vector already sorted by id (ascending).
// Returns index or -1; 'comparisons' reports how many probes were needed.
int binarySearchBookById(const vector<Book> &sortedById, const string &id, int &comparisons);
int binarySearchMemberById(const vector<Member> &sortedById, const string &id, int &comparisons);

// Case-insensitive, "natural" comparison (B2 < B10)
int naturalCompare(const string &a, const string &b);

// Linear Search: O(n). Case-insensitive substring match, used for title,
// author, name and partial-ID searches (binary search needs an exact key).
// field: "all", "id", "title", "author" (books) / "all", "id", "name", "email" (members)
// statusFilter: "" for any, otherwise "Available", "Issued" or "Reserved"
// 'comparisons' counts the records examined.
vector<Book> linearSearchBooks(const vector<Book> &books, const string &query,
                               const string &field, const string &statusFilter,
                               int &comparisons);
vector<Member> linearSearchMembers(const vector<Member> &members, const string &query,
                                   const string &field, int &comparisons);

#endif
