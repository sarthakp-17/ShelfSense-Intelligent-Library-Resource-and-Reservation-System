#ifndef LIBRARYSETTINGS_H
#define LIBRARYSETTINGS_H

// Library policy values that the GUI lets the librarian change.
// Stored in data/settings.txt as simple "key=value" lines.
//
// Where the defaults come from:
//   finePerDay  = 5.0  -> the original console returnBook() (lateDays * 5.0)
//   loanDays    = 14   -> NOT defined by the console version (it asks for a due
//                         date every time); used only to pre-fill the due date
//   dueSoonDays = 3    -> how many days ahead a loan counts as "due soon"
//   theme       = "system" | "light" | "dark"

#include <string>
using namespace std;

class LibrarySettings
{
public:
    static const double DEFAULT_FINE_PER_DAY;
    static const int DEFAULT_LOAN_DAYS;
    static const int DEFAULT_DUE_SOON_DAYS;

    double finePerDay;
    int loanDays;
    int dueSoonDays;
    string theme;

    LibrarySettings();

    // Missing file -> defaults. Unreadable values -> default for that key,
    // and 'warning' describes what was ignored.
    bool loadFromFile(const string &filename, string &warning);
    bool saveToFile(const string &filename) const;

    // Returns "" when the values are acceptable, otherwise an error message.
    static string validate(double fine, int loan, int dueSoon, const string &theme);
};

#endif
