
#ifndef MEMBERLINKEDLIST_H
#define MEMBERLINKEDLIST_H

#include "MemberNode.h"
#include <vector>

class MemberLinkedList
{
private:
    MemberNode *head;

public:
    MemberLinkedList();

    ~MemberLinkedList();

    bool addMember(Member newMember);

    Member *searchMember(string id);

    void displayAllMembers() const;

    bool isEmpty() const;
    bool saveToFile(const string &filename) const;
    bool loadFromFile(const string &filename);

    // ---- GUI-layer additions (non-interactive) ----
    vector<Member> getAllMembers() const;
    bool updateMemberDetails(string id, string newName,
                             string newEmail, string newPhone);
    bool removeMember(string id);
};

#endif