#include "../include/LibraryService.h"
#include "../include/DueDateHeap.h"
#include "../include/FileStore.h"
#include <algorithm>
#include <ctime>
#include <cstdio>
#include <sstream>

using namespace std;

const double LibraryService::FINE_PER_DAY = 5.0;

// ---------------- helpers ----------------

static string trim(const string &s)
{
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == string::npos)
        return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

// Fields are stored with '|' separators, so '|' and line breaks are not allowed.
static bool safeText(const string &s)
{
    return s.find('|') == string::npos && s.find('\n') == string::npos &&
           s.find('\r') == string::npos;
}

static bool validId(const string &id)
{
    if (id.empty() || id.size() > 20)
        return false;
    for (size_t i = 0; i < id.size(); i++)
    {
        char c = id[i];
        bool ok = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                  (c >= '0' && c <= '9') || c == '-' || c == '_';
        if (!ok)
            return false;
    }
    return true;
}

static OpResult fail(const string &msg)
{
    OpResult r;
    r.ok = false;
    r.message = msg;
    return r;
}

static OpResult success(const string &msg)
{
    OpResult r;
    r.ok = true;
    r.message = msg;
    return r;
}

static string money(double v)
{
    char buf[32];
    snprintf(buf, sizeof(buf), "%.2f", v);
    return string(buf);
}

// ---------------- setup / persistence ----------------

LibraryService::LibraryService(const string &dataDirectory)
{
    dataDir = dataDirectory;
}

string LibraryService::dataPath(const string &file) const
{
    if (dataDir.empty())
        return file;
    char last = dataDir[dataDir.size() - 1];
    if (last == '/' || last == '\\')
        return dataDir + file;
#ifdef _WIN32
    return dataDir + "\\" + file;
#else
    return dataDir + "/" + file;
#endif
}

vector<string> LibraryService::dataFileNames()
{
    vector<string> f;
    f.push_back("books.txt");
    f.push_back("members.txt");
    f.push_back("borrow_records.txt");
    f.push_back("reservations.txt");
    f.push_back("reservation_history.txt");
    f.push_back("transactions.txt");
    f.push_back("settings.txt");
    return f;
}

bool LibraryService::backupTo(const string &folder)
{
    if (!FileStore::makeDir(dataPath("backups")) || !FileStore::makeDir(folder))
        return false;
    vector<string> names = dataFileNames();
    bool ok = true;
    for (size_t i = 0; i < names.size(); i++)
    {
        string src = dataPath(names[i]);
        if (FileStore::fileExists(src))
            ok = FileStore::copyFile(src, FileStore::joinPath(folder, names[i])) && ok;
    }
    return ok;
}

// Keeps only the newest BACKUPS_TO_KEEP backup folders.
// Folder names are YYYYMMDD-HHMMSS, so alphabetical order is chronological.
void LibraryService::pruneBackups()
{
    string root = dataPath("backups");
    vector<string> dirs = FileStore::listSubdirs(root);
    sort(dirs.begin(), dirs.end());
    vector<string> names = dataFileNames();
    for (int i = 0; i + BACKUPS_TO_KEEP < (int)dirs.size(); i++)
    {
        string folder = FileStore::joinPath(root, dirs[i]);
        for (size_t k = 0; k < names.size(); k++)
            FileStore::removeFile(FileStore::joinPath(folder, names[k]));
        FileStore::removeEmptyDir(folder);   // only succeeds if nothing else is inside
    }
}

void LibraryService::loadAll()
{
    loadWarnings.clear();

    // 1. Safety copy of whatever is on disk *before* anything can be rewritten.
    bool anyFile = false;
    vector<string> names = dataFileNames();
    for (size_t i = 0; i < names.size(); i++)
        if (FileStore::fileExists(dataPath(names[i])))
            anyFile = true;
    if (anyFile)
    {
        string folder = FileStore::joinPath(dataPath("backups"), FileStore::timestampForFolder());
        if (backupTo(folder))
        {
            lastBackupDir = folder;
            pruneBackups();
        }
        else
            loadWarnings.push_back("Could not create the start-up backup in " + dataPath("backups") + ".");
    }

    // 2. Load with the original classes.
    books.loadFromFile(dataPath("books.txt"));
    members.loadFromFile(dataPath("members.txt"));
    borrows.loadFromFile(dataPath("borrow_records.txt"));
    queue.loadFromFile(dataPath("reservations.txt"));
    history.loadFromFile(dataPath("reservation_history.txt"));
    transactions.loadFromFile(dataPath("transactions.txt"));
    string settingsWarning;
    settings.loadFromFile(dataPath("settings.txt"), settingsWarning);
    if (!settingsWarning.empty())
        loadWarnings.push_back(settingsWarning);

    // 3. Compare lines on disk with records loaded, so skipped (corrupted or
    //    duplicate) lines are reported instead of silently disappearing.
    struct Check { const char *file; int loaded; };
    Check checks[] = {
        {"books.txt", books.countBooks()},
        {"members.txt", (int)members.getAllMembers().size()},
        {"borrow_records.txt", (int)borrows.getAllRecords().size()},
        {"reservations.txt", (int)queue.getAllReservations().size()},
        {"reservation_history.txt", (int)history.getAll().size()},
        {"transactions.txt", transactions.size()},
    };
    for (size_t i = 0; i < sizeof(checks) / sizeof(checks[0]); i++)
    {
        int lines = FileStore::countNonEmptyLines(dataPath(checks[i].file));
        if (lines > checks[i].loaded)
        {
            ostringstream os;
            os << checks[i].file << ": " << (lines - checks[i].loaded) << " of " << lines
               << " line(s) could not be read (invalid or duplicate) and were skipped.";
            if (!lastBackupDir.empty())
                os << " The original file is kept in " << lastBackupDir << ".";
            loadWarnings.push_back(os.str());
        }
    }

    checkIntegrity();
}

// Cross-file consistency checks. Problems are reported, never auto-"fixed",
// so the librarian decides what is correct.
void LibraryService::checkIntegrity()
{
    vector<Book> allBooks = books.getAllBooks();
    for (size_t i = 0; i < allBooks.size(); i++)
    {
        const Book &b = allBooks[i];
        bool active = borrows.findActiveRecord(b.getBookId()) != nullptr;
        if (b.getStatus() == "Issued" && !active)
            loadWarnings.push_back("Book " + b.getBookId() +
                                   " is marked Issued but has no active borrowing record.");
        if (b.getStatus() != "Issued" && active)
            loadWarnings.push_back("Book " + b.getBookId() + " has an active borrowing record but its status is " +
                                   b.getStatus() + ".");
        if (b.getStatus() != "Available" && b.getStatus() != "Issued" && b.getStatus() != "Reserved")
            loadWarnings.push_back("Book " + b.getBookId() + " has an unknown status \"" + b.getStatus() + "\".");
    }
    vector<Reservation> pending = queue.getAllReservations();
    for (size_t i = 0; i < pending.size(); i++)
    {
        if (books.findBook(pending[i].getBookId()) == nullptr)
            loadWarnings.push_back("A reservation refers to book " + pending[i].getBookId() +
                                   ", which is not in the catalogue.");
        if (members.searchMember(pending[i].getMemberId()) == nullptr)
            loadWarnings.push_back("A reservation refers to member " + pending[i].getMemberId() +
                                   ", who is not registered.");
    }
}

// Writes each list to "<file>.tmp", checks the line count, then renames it over
// the real file. A crash during saving leaves the previous file untouched.
bool LibraryService::saveAll()
{
    lastSaveError = "";
    struct Item { string name; bool written; int expected; };
    vector<Item> items;
    Item it;

    it.name = "books.txt";
    it.written = books.saveToFile(dataPath(it.name + ".tmp"));
    it.expected = books.countBooks();
    items.push_back(it);

    it.name = "members.txt";
    it.written = members.saveToFile(dataPath(it.name + ".tmp"));
    it.expected = (int)members.getAllMembers().size();
    items.push_back(it);

    it.name = "borrow_records.txt";
    it.written = borrows.saveToFile(dataPath(it.name + ".tmp"));
    it.expected = (int)borrows.getAllRecords().size();
    items.push_back(it);

    it.name = "reservations.txt";
    it.written = queue.saveToFile(dataPath(it.name + ".tmp"));
    it.expected = (int)queue.getAllReservations().size();
    items.push_back(it);

    it.name = "reservation_history.txt";
    it.written = history.saveToFile(dataPath(it.name + ".tmp"));
    it.expected = (int)history.getAll().size();
    items.push_back(it);

    it.name = "transactions.txt";
    it.written = transactions.saveToFile(dataPath(it.name + ".tmp"));
    it.expected = transactions.size();
    items.push_back(it);

    bool ok = true;
    for (size_t i = 0; i < items.size(); i++)
    {
        string tmp = dataPath(items[i].name + ".tmp");
        bool good = items[i].written &&
                    FileStore::countNonEmptyLines(tmp) == items[i].expected &&
                    FileStore::replaceFile(tmp, dataPath(items[i].name));
        if (!good)
        {
            ok = false;
            FileStore::removeFile(tmp);
            lastSaveError += (lastSaveError.empty() ? "" : ", ") + items[i].name;
        }
    }

    string tmp = dataPath("settings.txt.tmp");
    if (!(settings.saveToFile(tmp) && FileStore::replaceFile(tmp, dataPath("settings.txt"))))
    {
        ok = false;
        FileStore::removeFile(tmp);
        lastSaveError += (lastSaveError.empty() ? "" : ", ") + string("settings.txt");
    }
    return ok;
}

OpResult LibraryService::finish(OpResult r)
{
    if (!r.ok)
        return r;
    r.saved = saveAll();
    if (!r.saved)
        r.message += " Warning: the change could not be saved to disk (" + lastSaveError +
                     "). Check that the data folder is not read-only.";
    return r;
}

string LibraryService::today()
{
    time_t now = time(nullptr);
    tm *local = localtime(&now);
    char buf[32];
    if (local == nullptr)
        return "01-01-2026";
    snprintf(buf, sizeof(buf), "%02d-%02d-%04d", local->tm_mday,
             local->tm_mon + 1, local->tm_year + 1900);
    return string(buf);
}

string LibraryService::addDays(const string &date, int days)
{
    long n = dateToDayNumber(date);
    if (n < 0)
        return date;
    n += days;
    // civil-from-days
    long z = n + 719468;
    long era = (z >= 0 ? z : z - 146096) / 146097;
    long doe = z - era * 146097;
    long yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    long y = yoe + era * 400;
    long doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    long mp = (5 * doy + 2) / 153;
    long d = doy - (153 * mp + 2) / 5 + 1;
    long m = mp + (mp < 10 ? 3 : -9);
    if (m <= 2)
        y++;
    char buf[64];
    snprintf(buf, sizeof(buf), "%02ld-%02ld-%04ld", d, m, y);
    return string(buf);
}

int LibraryService::activeLoansForMember(const string &memberId) const
{
    vector<BorrowRecord> all = borrows.getAllRecords();
    int count = 0;
    for (size_t i = 0; i < all.size(); i++)
    {
        if (all[i].getMemberId() == memberId && all[i].getStatus() == "Issued")
            count++;
    }
    return count;
}

// ---------------- catalogue ----------------

OpResult LibraryService::addBook(string id, string title, string author, string category)
{
    id = trim(id);
    title = trim(title);
    author = trim(author);
    category = trim(category);

    if (!validId(id))
        return fail("Book ID must be 1-20 characters: letters, digits, '-' or '_'.");
    if (title.empty() || author.empty() || category.empty())
        return fail("Title, author and category are required.");
    if (!safeText(title) || !safeText(author) || !safeText(category))
        return fail("The '|' character cannot be used in book details.");
    if (books.findBook(id) != nullptr)
        return fail("Book ID " + id + " already exists.");

    if (!books.addBook(Book(id, title, author, category, "Available")))
        return fail("Could not add the book.");

    transactions.record("ADD_BOOK", "", id, "Added \"" + title + "\" by " + author);
    return finish(success("Book \"" + title + "\" added to the catalogue."));
}

OpResult LibraryService::updateBook(string id, string title, string author, string category)
{
    id = trim(id);
    title = trim(title);
    author = trim(author);
    category = trim(category);

    if (books.findBook(id) == nullptr)
        return fail("Book " + id + " was not found.");
    if (title.empty() || author.empty() || category.empty())
        return fail("Title, author and category are required.");
    if (!safeText(title) || !safeText(author) || !safeText(category))
        return fail("The '|' character cannot be used in book details.");

    books.updateBookDetails(id, title, author, category);
    transactions.record("UPDATE_BOOK", "", id, "Updated details of \"" + title + "\"");
    return finish(success("Book " + id + " updated."));
}

OpResult LibraryService::deleteBook(string id)
{
    id = trim(id);
    Book *book = books.findBook(id);
    if (book == nullptr)
        return fail("Book " + id + " was not found.");
    if (book->getStatus() != "Available")
        return fail("Book " + id + " is " + book->getStatus() +
                    ". Return it before deleting.");
    if (queue.countForBook(id) > 0)
        return fail("Book " + id + " has pending reservations. Cancel them first.");

    string title = book->getTitle();
    books.removeBook(id);
    transactions.record("DELETE_BOOK", "", id, "Removed \"" + title + "\" from catalogue");
    return finish(success("Book \"" + title + "\" deleted."));
}

// ---------------- members ----------------

static string validateMemberFields(const string &name, const string &email, const string &phone)
{
    if (name.empty())
        return "Member name is required.";
    if (!safeText(name) || !safeText(email) || !safeText(phone))
        return "The '|' character cannot be used in member details.";
    if (!email.empty() && (email.find('@') == string::npos || email.find(' ') != string::npos))
        return "Enter a valid email address (or leave it empty).";
    for (size_t i = 0; i < phone.size(); i++)
    {
        char c = phone[i];
        if (!((c >= '0' && c <= '9') || c == '+' || c == ' ' || c == '-'))
            return "Phone may only contain digits, spaces, '+' or '-'.";
    }
    return "";
}

OpResult LibraryService::addMember(string id, string name, string email, string phone)
{
    id = trim(id);
    name = trim(name);
    email = trim(email);
    phone = trim(phone);

    if (!validId(id))
        return fail("Member ID must be 1-20 characters: letters, digits, '-' or '_'.");
    string err = validateMemberFields(name, email, phone);
    if (!err.empty())
        return fail(err);
    if (members.searchMember(id) != nullptr)
        return fail("Member ID " + id + " already exists.");

    if (!members.addMember(Member(id, name, email, phone)))
        return fail("Could not add the member.");

    transactions.record("ADD_MEMBER", id, "", "Registered member " + name);
    return finish(success("Member " + name + " registered."));
}

OpResult LibraryService::updateMember(string id, string name, string email, string phone)
{
    id = trim(id);
    name = trim(name);
    email = trim(email);
    phone = trim(phone);

    if (members.searchMember(id) == nullptr)
        return fail("Member " + id + " was not found.");
    string err = validateMemberFields(name, email, phone);
    if (!err.empty())
        return fail(err);

    members.updateMemberDetails(id, name, email, phone);
    transactions.record("UPDATE_MEMBER", id, "", "Updated details of " + name);
    return finish(success("Member " + id + " updated."));
}

OpResult LibraryService::deleteMember(string id)
{
    id = trim(id);
    Member *member = members.searchMember(id);
    if (member == nullptr)
        return fail("Member " + id + " was not found.");
    int loans = activeLoansForMember(id);
    if (loans > 0)
    {
        ostringstream os;
        os << member->getName() << " still has " << loans
           << " book(s) issued. Return them before deleting.";
        return fail(os.str());
    }
    vector<Reservation> pending = queue.getAllReservations();
    for (size_t i = 0; i < pending.size(); i++)
    {
        if (pending[i].getMemberId() == id)
            return fail(member->getName() + " has pending reservations. Cancel them first.");
    }

    string name = member->getName();
    members.removeMember(id);
    transactions.record("DELETE_MEMBER", id, "", "Removed member " + name);
    return finish(success("Member " + name + " deleted."));
}

// ---------------- circulation ----------------
// Same rules as issueBook() in LibraryManager.cpp, plus date validation.

OpResult LibraryService::issueBook(string memberId, string bookId,
                                   string issueDate, string dueDate)
{
    memberId = trim(memberId);
    bookId = trim(bookId);

    Member *member = members.searchMember(memberId);
    if (member == nullptr)
        return fail("Member " + memberId + " was not found.");

    Book *book = books.findBook(bookId);
    if (book == nullptr)
        return fail("Book " + bookId + " was not found.");

    if (book->getStatus() != "Available")
        return fail("\"" + book->getTitle() + "\" is not available (status: " +
                    book->getStatus() + "). Reserve it instead.");

    if (!isValidDate(issueDate) || !isValidDate(dueDate))
        return fail("Dates must be valid and in DD-MM-YYYY format.");
    if (dateToDayNumber(dueDate) < dateToDayNumber(issueDate))
        return fail("Due date cannot be before the issue date.");

    BorrowRecord record(memberId, bookId, issueDate, dueDate, "Issued");
    if (!borrows.addRecord(record))
        return fail("Could not create the borrowing record.");

    book->setStatus("Issued");
    transactions.record("ISSUE", memberId, bookId,
                        "Issued \"" + book->getTitle() + "\" to " + member->getName() +
                            ", due " + dueDate);
    return finish(success("\"" + book->getTitle() + "\" issued to " + member->getName() +
                   ". Due on " + dueDate + "."));
}

// Same flow as returnBook() in LibraryManager.cpp: fine = late days x Rs.5,
// then the FIFO reservation queue hands the book to the next member automatically.
OpResult LibraryService::returnBook(string bookId, string returnDate, string nextDueDate)
{
    bookId = trim(bookId);

    Book *book = books.findBook(bookId);
    if (book == nullptr)
        return fail("Book " + bookId + " was not found.");
    if (book->getStatus() != "Issued")
        return fail("\"" + book->getTitle() + "\" is not currently issued.");

    BorrowRecord *record = borrows.findActiveRecord(bookId);
    if (record == nullptr)
        return fail("No active borrowing record was found for " + bookId + ".");

    if (!isValidDate(returnDate))
        return fail("Return date must be valid and in DD-MM-YYYY format.");
    if (dateToDayNumber(returnDate) < dateToDayNumber(record->getIssueDate()))
        return fail("Return date cannot be before the issue date (" +
                    record->getIssueDate() + ").");

    // Validate the auto-issue due date up front so nothing changes on error
    Reservation nextReservation;
    bool hasNext = queue.findReservationForBook(bookId, nextReservation);
    if (hasNext)
    {
        if (nextDueDate.empty())
            nextDueDate = addDays(returnDate, settings.loanDays);
        if (!isValidDate(nextDueDate))
            return fail("Due date for the next reserved member must be in DD-MM-YYYY format.");
        if (dateToDayNumber(nextDueDate) < dateToDayNumber(returnDate))
            return fail("Due date for the next member cannot be before the return date.");
    }

    string borrowerId = record->getMemberId();
    int lateDays = calculateLateDays(record->getDueDate(), returnDate);   // original backend function
    double fine = lateDays * settings.finePerDay;   // Rs. 5 by default (console rule)
    record->setFine(fine);

    if (!borrows.returnRecord(bookId))
        return fail("Could not return the book.");

    OpResult result;
    result.ok = true;
    result.lateDays = lateDays;
    result.fine = fine;

    ostringstream msg;
    msg << "\"" << book->getTitle() << "\" returned.";
    if (lateDays > 0)
        msg << " " << lateDays << " day(s) late, fine Rs. " << money(fine) << ".";
    else
        msg << " Returned on time, no fine.";

    {
        ostringstream d;
        d << "Returned \"" << book->getTitle() << "\"";
        if (lateDays > 0)
            d << ", " << lateDays << " day(s) late, fine Rs. " << money(fine);
        transactions.record("RETURN", borrowerId, bookId, d.str());
    }

    if (hasNext)
    {
        string nextMemberId = nextReservation.getMemberId();
        Member *nextMember = members.searchMember(nextMemberId);

        if (nextMember == nullptr)
        {
            book->setStatus("Reserved");
            msg << " Reserved member " << nextMemberId << " not found; book stays Reserved.";
        }
        else
        {
            BorrowRecord newRecord(nextMemberId, bookId, returnDate, nextDueDate, "Issued");
            if (borrows.addRecord(newRecord))
            {
                history.markFulfilled(nextReservation.getMemberId(),
                                      nextReservation.getBookId(),
                                      nextReservation.getReservationDate());
                queue.removeNextReservationForBook(bookId);
                book->setStatus("Issued");
                result.autoIssuedTo = nextMemberId;
                msg << " Next in queue: issued automatically to " << nextMember->getName()
                    << ", due " << nextDueDate << ".";
                transactions.record("AUTO_ISSUE", nextMemberId, bookId,
                                    "Reservation fulfilled: \"" + book->getTitle() +
                                        "\" issued to " + nextMember->getName() +
                                        ", due " + nextDueDate);
            }
            else
            {
                book->setStatus("Reserved");
                msg << " Could not create a record for the next member; book stays Reserved.";
            }
        }
    }
    else
    {
        book->setStatus("Available");
    }

    result.message = msg.str();
    return finish(result);
}

OpResult LibraryService::renewBook(string bookId, string newDueDate)
{
    bookId = trim(bookId);
    BorrowRecord *record = borrows.findActiveRecord(bookId);
    if (record == nullptr)
        return fail("No active borrowing record was found for " + bookId + ".");
    if (!isValidDate(newDueDate))
        return fail("New due date must be valid and in DD-MM-YYYY format.");
    if (dateToDayNumber(newDueDate) <= dateToDayNumber(record->getDueDate()))
        return fail("New due date must be after the current due date (" +
                    record->getDueDate() + ").");

    string oldDue = record->getDueDate();
    string memberId = record->getMemberId();
    if (!borrows.renewRecord(bookId, newDueDate))
        return fail("Could not renew the book.");

    Book *book = books.findBook(bookId);
    string title = book ? book->getTitle() : bookId;
    transactions.record("RENEW", memberId, bookId,
                        "Renewed \"" + title + "\": " + oldDue + " to " + newDueDate);
    return finish(success("\"" + title + "\" renewed. New due date " + newDueDate + "."));
}

// Same rules as reserveBook() in LibraryManager.cpp, plus duplicate checks.
OpResult LibraryService::reserveBook(string memberId, string bookId, string reservationDate)
{
    memberId = trim(memberId);
    bookId = trim(bookId);

    Member *member = members.searchMember(memberId);
    if (member == nullptr)
        return fail("Member " + memberId + " was not found.");

    Book *book = books.findBook(bookId);
    if (book == nullptr)
        return fail("Book " + bookId + " was not found.");

    if (book->getStatus() == "Available")
        return fail("\"" + book->getTitle() + "\" is available. Issue it directly instead.");

    BorrowRecord *active = borrows.findActiveRecord(bookId);
    // A "Reserved" book has no loan but already has a queue: joining it is allowed.
    if (active == nullptr && book->getStatus() != "Reserved")
        return fail("No active borrowing record was found for this book.");
    if (active != nullptr && active->getMemberId() == memberId)
        return fail(member->getName() + " already has this book issued.");
    if (queue.hasReservation(memberId, bookId))
        return fail(member->getName() + " is already in the queue for this book.");
    if (!isValidDate(reservationDate))
        return fail("Reservation date must be valid and in DD-MM-YYYY format.");

    Reservation reservation(memberId, bookId, reservationDate);
    if (!queue.enqueue(reservation))
        return fail("Could not add the reservation.");
    history.addReservation(reservation);

    int position = queue.countForBook(bookId);
    ostringstream os;
    os << member->getName() << " reserved \"" << book->getTitle()
       << "\". Queue position #" << position << ".";
    transactions.record("RESERVE", memberId, bookId, os.str());
    return finish(success(os.str()));
}

OpResult LibraryService::cancelReservation(string memberId, string bookId)
{
    memberId = trim(memberId);
    bookId = trim(bookId);
    if (!queue.removeReservation(memberId, bookId))
        return fail("That reservation is no longer in the queue.");
    history.markCancelled(memberId, bookId);

    Member *member = members.searchMember(memberId);
    Book *book = books.findBook(bookId);

    // Fix: a book left "Reserved" (no loan, waiting for its queue) used to stay
    // Reserved forever once its last reservation was cancelled.
    if (book != nullptr && book->getStatus() == "Reserved" && queue.countForBook(bookId) == 0)
        book->setStatus("Available");
    string who = member ? member->getName() : memberId;
    string what = book ? book->getTitle() : bookId;
    transactions.record("CANCEL_RESERVATION", memberId, bookId,
                        "Cancelled reservation of \"" + what + "\" for " + who);
    return finish(success("Reservation of \"" + what + "\" for " + who + " cancelled."));
}

// ---------------- additions for the GUI ----------------

// Read-only: what would happen if this book were returned on 'returnDate'.
// Uses the original calculateLateDays() so the preview matches the real return.
OpResult LibraryService::previewReturn(string bookId, string returnDate)
{
    bookId = trim(bookId);
    Book *book = books.findBook(bookId);
    if (book == nullptr)
        return fail("Book " + bookId + " was not found.");
    BorrowRecord *record = borrows.findActiveRecord(bookId);
    if (book->getStatus() != "Issued" || record == nullptr)
        return fail("\"" + book->getTitle() + "\" is not currently issued.");
    if (!isValidDate(returnDate))
        return fail("Return date must be valid and in DD-MM-YYYY format.");
    if (dateToDayNumber(returnDate) < dateToDayNumber(record->getIssueDate()))
        return fail("Return date cannot be before the issue date (" + record->getIssueDate() + ").");

    OpResult r;
    r.ok = true;
    r.borrowerId = record->getMemberId();
    r.dueDate = record->getDueDate();
    r.lateDays = calculateLateDays(record->getDueDate(), returnDate);
    r.fine = r.lateDays * settings.finePerDay;
    Reservation next;
    if (queue.findReservationForBook(bookId, next))
        r.nextInQueue = next.getMemberId();
    r.message = r.lateDays > 0 ? "Overdue" : "On time";
    return r;
}

// FIFO: the earliest reservation for this book is served first.
// Used for books that are not on loan but have a queue (status "Reserved").
// While a book is on loan, its queue is served automatically by returnBook().
OpResult LibraryService::processNextReservation(string bookId, string issueDate, string dueDate)
{
    bookId = trim(bookId);
    Book *book = books.findBook(bookId);
    if (book == nullptr)
        return fail("Book " + bookId + " was not found.");
    if (book->getStatus() == "Issued")
        return fail("\"" + book->getTitle() + "\" is on loan. Its queue is served automatically when it is returned.");

    Reservation next;
    if (!queue.findReservationForBook(bookId, next))
        return fail("There are no reservations waiting for \"" + book->getTitle() + "\".");

    Member *member = members.searchMember(next.getMemberId());
    if (member == nullptr)
        return fail("Member " + next.getMemberId() +
                    " at the front of the queue is not registered. Cancel that reservation first.");

    if (!isValidDate(issueDate) || !isValidDate(dueDate))
        return fail("Dates must be valid and in DD-MM-YYYY format.");
    if (dateToDayNumber(dueDate) < dateToDayNumber(issueDate))
        return fail("Due date cannot be before the issue date.");

    BorrowRecord record(next.getMemberId(), bookId, issueDate, dueDate, "Issued");
    if (!borrows.addRecord(record))
        return fail("Could not create the borrowing record.");

    history.markFulfilled(next.getMemberId(), next.getBookId(), next.getReservationDate());
    queue.removeNextReservationForBook(bookId);
    book->setStatus("Issued");
    transactions.record("AUTO_ISSUE", next.getMemberId(), bookId,
                        "Reservation fulfilled: \"" + book->getTitle() + "\" issued to " +
                            member->getName() + ", due " + dueDate);

    OpResult r = success("\"" + book->getTitle() + "\" issued to " + member->getName() +
                         " (first in the queue). Due on " + dueDate + ".");
    r.autoIssuedTo = next.getMemberId();
    return finish(r);
}

OpResult LibraryService::updateSettings(double finePerDay, int loanDays, int dueSoonDays, string theme)
{
    string err = LibrarySettings::validate(finePerDay, loanDays, dueSoonDays, theme);
    if (!err.empty())
        return fail(err);

    bool policyChanged = finePerDay != settings.finePerDay || loanDays != settings.loanDays ||
                         dueSoonDays != settings.dueSoonDays;
    settings.finePerDay = finePerDay;
    settings.loanDays = loanDays;
    settings.dueSoonDays = dueSoonDays;
    settings.theme = theme;
    if (policyChanged)
    {
        ostringstream d;
        d << "Fine Rs. " << money(finePerDay) << "/day, loan " << loanDays
          << " days, due-soon window " << dueSoonDays << " days";
        transactions.record("SETTINGS", "", "", d.str());
    }
    return finish(success("Settings saved."));
}

OpResult LibraryService::createBackup()
{
    // Save first so the backup contains the current state.
    if (!saveAll())
        return fail("Could not save the current data (" + lastSaveError + "), so no backup was made.");
    string folder = FileStore::joinPath(dataPath("backups"), FileStore::timestampForFolder());
    if (FileStore::dirExists(folder))
        folder += "b";   // two backups within the same second
    if (!backupTo(folder))
        return fail("Could not write the backup to " + folder + ".");
    lastBackupDir = folder;
    pruneBackups();
    return success("Backup saved to " + folder + ".");
}
