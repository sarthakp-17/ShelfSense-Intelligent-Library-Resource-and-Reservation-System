#include "../include/FileStore.h"

#include <fstream>
#include <cstdio>
#include <ctime>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#else
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#endif

using namespace std;

namespace FileStore
{

string joinPath(const string &a, const string &b)
{
    if (a.empty())
        return b;
    char last = a[a.size() - 1];
    if (last == '/' || last == '\\')
        return a + b;
#ifdef _WIN32
    return a + "\\" + b;
#else
    return a + "/" + b;
#endif
}

bool fileExists(const string &path)
{
#ifdef _WIN32
    DWORD attr = GetFileAttributesA(path.c_str());
    return attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY);
#else
    struct stat st;
    return stat(path.c_str(), &st) == 0 && S_ISREG(st.st_mode);
#endif
}

bool dirExists(const string &path)
{
#ifdef _WIN32
    DWORD attr = GetFileAttributesA(path.c_str());
    return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY);
#else
    struct stat st;
    return stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
#endif
}

bool makeDir(const string &path)
{
    if (dirExists(path))
        return true;
#ifdef _WIN32
    CreateDirectoryA(path.c_str(), NULL);
#else
    mkdir(path.c_str(), 0755);
#endif
    return dirExists(path);
}

bool copyFile(const string &from, const string &to)
{
    ifstream in(from.c_str(), ios::in | ios::binary);
    if (!in.is_open())
        return false;
    ofstream out(to.c_str(), ios::out | ios::binary | ios::trunc);
    if (!out.is_open())
        return false;
    out << in.rdbuf();
    out.flush();
    return out.good();
}

bool removeFile(const string &path)
{
    return std::remove(path.c_str()) == 0;
}

bool removeEmptyDir(const string &path)
{
#ifdef _WIN32
    return RemoveDirectoryA(path.c_str()) != 0;
#else
    return rmdir(path.c_str()) == 0;
#endif
}

bool replaceFile(const string &tempFile, const string &target)
{
#ifdef _WIN32
    // MOVEFILE_REPLACE_EXISTING: overwrite the old file in one step.
    // MOVEFILE_WRITE_THROUGH: do not return until the move is on disk.
    return MoveFileExA(tempFile.c_str(), target.c_str(),
                       MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) != 0;
#else
    return std::rename(tempFile.c_str(), target.c_str()) == 0;
#endif
}

int countNonEmptyLines(const string &path)
{
    ifstream in(path.c_str());
    if (!in.is_open())
        return -1;
    string line;
    int count = 0;
    while (getline(in, line))
    {
        if (!line.empty() && line[line.size() - 1] == '\r')
            line.erase(line.size() - 1);
        if (line.find_first_not_of(" \t") != string::npos)
            count++;
    }
    return count;
}

vector<string> listSubdirs(const string &path)
{
    vector<string> names;
#ifdef _WIN32
    WIN32_FIND_DATAA data;
    string pattern = joinPath(path, "*");
    HANDLE h = FindFirstFileA(pattern.c_str(), &data);
    if (h == INVALID_HANDLE_VALUE)
        return names;
    do
    {
        string name = data.cFileName;
        if ((data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && name != "." && name != "..")
            names.push_back(name);
    } while (FindNextFileA(h, &data));
    FindClose(h);
#else
    DIR *d = opendir(path.c_str());
    if (d == NULL)
        return names;
    struct dirent *e;
    while ((e = readdir(d)) != NULL)
    {
        string name = e->d_name;
        if (name == "." || name == "..")
            continue;
        if (dirExists(joinPath(path, name)))
            names.push_back(name);
    }
    closedir(d);
#endif
    return names;
}

string timestampForFolder()
{
    time_t now = time(NULL);
    tm *t = localtime(&now);
    char buf[32];
    if (t == NULL)
        return "00000000-000000";
    snprintf(buf, sizeof(buf), "%04d%02d%02d-%02d%02d%02d", t->tm_year + 1900,
             t->tm_mon + 1, t->tm_mday, t->tm_hour, t->tm_min, t->tm_sec);
    return string(buf);
}

} // namespace FileStore
