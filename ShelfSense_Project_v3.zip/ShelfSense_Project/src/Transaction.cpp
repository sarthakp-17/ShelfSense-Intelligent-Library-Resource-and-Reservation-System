#include "../include/Transaction.h"

Transaction::Transaction()
{
    txnId = 0;
    type = "";
    memberId = "";
    bookId = "";
    timestamp = "";
    details = "";
}

Transaction::Transaction(long long id, string txnType, string mId, string bId,
                         string time, string info)
{
    txnId = id;
    type = txnType;
    memberId = mId;
    bookId = bId;
    timestamp = time;
    details = info;
}

long long Transaction::getTxnId() const { return txnId; }
string Transaction::getType() const { return type; }
string Transaction::getMemberId() const { return memberId; }
string Transaction::getBookId() const { return bookId; }
string Transaction::getTimestamp() const { return timestamp; }
string Transaction::getDetails() const { return details; }
