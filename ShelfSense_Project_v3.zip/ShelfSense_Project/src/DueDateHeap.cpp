#include "../include/DueDateHeap.h"
#include <cstdio>

using namespace std;

// Days-from-civil algorithm (proleptic Gregorian calendar)
static long daysFromCivil(int y, int m, int d)
{
    y -= (m <= 2) ? 1 : 0;
    long era = (y >= 0 ? y : y - 399) / 400;
    long yoe = y - era * 400;
    long doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    long doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + doe - 719468;
}

static bool isLeap(int y)
{
    return (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
}

bool isValidDate(const string &s)
{
    if (s.size() != 10 || s[2] != '-' || s[5] != '-')
        return false;
    for (int i = 0; i < 10; i++)
    {
        if (i == 2 || i == 5)
            continue;
        if (s[i] < '0' || s[i] > '9')
            return false;
    }
    int d = 0, m = 0, y = 0;
    if (sscanf(s.c_str(), "%d-%d-%d", &d, &m, &y) != 3)
        return false;
    if (y < 1900 || y > 2200 || m < 1 || m > 12 || d < 1)
        return false;
    int mdays[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int maxDay = mdays[m - 1] + ((m == 2 && isLeap(y)) ? 1 : 0);
    return d <= maxDay;
}

long dateToDayNumber(const string &s)
{
    if (!isValidDate(s))
        return -1;
    int d = 0, m = 0, y = 0;
    sscanf(s.c_str(), "%d-%d-%d", &d, &m, &y);
    return daysFromCivil(y, m, d);
}

void DueDateHeap::siftUp(int index)
{
    while (index > 0)
    {
        int parent = (index - 1) / 2;
        if (heap[index].dueKey >= heap[parent].dueKey)
            break;
        DueEntry temp = heap[index];
        heap[index] = heap[parent];
        heap[parent] = temp;
        index = parent;
    }
}

void DueDateHeap::siftDown(int index)
{
    int n = static_cast<int>(heap.size());
    while (true)
    {
        int left = 2 * index + 1;
        int right = 2 * index + 2;
        int smallest = index;
        if (left < n && heap[left].dueKey < heap[smallest].dueKey)
            smallest = left;
        if (right < n && heap[right].dueKey < heap[smallest].dueKey)
            smallest = right;
        if (smallest == index)
            break;
        DueEntry temp = heap[index];
        heap[index] = heap[smallest];
        heap[smallest] = temp;
        index = smallest;
    }
}

void DueDateHeap::insert(const BorrowRecord &record)
{
    DueEntry entry;
    entry.dueKey = dateToDayNumber(record.getDueDate());
    entry.record = record;
    heap.push_back(entry);
    siftUp(static_cast<int>(heap.size()) - 1);
}

bool DueDateHeap::peekMin(DueEntry &out) const
{
    if (heap.empty())
        return false;
    out = heap[0];
    return true;
}

bool DueDateHeap::extractMin(DueEntry &out)
{
    if (heap.empty())
        return false;
    out = heap[0];
    heap[0] = heap.back();
    heap.pop_back();
    if (!heap.empty())
        siftDown(0);
    return true;
}

bool DueDateHeap::isEmpty() const { return heap.empty(); }
int DueDateHeap::size() const { return static_cast<int>(heap.size()); }
void DueDateHeap::clear() { heap.clear(); }
