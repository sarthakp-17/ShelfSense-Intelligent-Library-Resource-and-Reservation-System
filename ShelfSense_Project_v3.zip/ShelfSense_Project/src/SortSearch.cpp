#include "../include/SortSearch.h"
#include <cctype>

using namespace std;

int naturalCompare(const string &a, const string &b)
{
    size_t i = 0, j = 0;
    while (i < a.size() && j < b.size())
    {
        if (isdigit((unsigned char)a[i]) && isdigit((unsigned char)b[j]))
        {
            size_t si = i, sj = j;
            while (si < a.size() && a[si] == '0') si++;
            while (sj < b.size() && b[sj] == '0') sj++;
            size_t ei = si, ej = sj;
            while (ei < a.size() && isdigit((unsigned char)a[ei])) ei++;
            while (ej < b.size() && isdigit((unsigned char)b[ej])) ej++;
            size_t li = ei - si, lj = ej - sj;
            if (li != lj)
                return li < lj ? -1 : 1;
            for (size_t k = 0; k < li; k++)
            {
                if (a[si + k] != b[sj + k])
                    return a[si + k] < b[sj + k] ? -1 : 1;
            }
            i = ei;
            j = ej;
        }
        else
        {
            char ca = (char)tolower((unsigned char)a[i]);
            char cb = (char)tolower((unsigned char)b[j]);
            if (ca != cb)
                return ca < cb ? -1 : 1;
            i++;
            j++;
        }
    }
    if (i < a.size()) return 1;
    if (j < b.size()) return -1;
    return 0;
}

static string bookKey(const Book &b, const string &key)
{
    if (key == "title") return b.getTitle();
    if (key == "author") return b.getAuthor();
    if (key == "category") return b.getCategory();
    if (key == "status") return b.getStatus();
    return b.getBookId();
}

static string memberKey(const Member &m, const string &key)
{
    if (key == "name") return m.getName();
    if (key == "email") return m.getEmail();
    return m.getMemberId();
}

template <typename T, typename KeyFn>
static void mergeSortRange(vector<T> &v, vector<T> &tmp, int lo, int hi,
                           KeyFn keyOf, bool asc)
{
    if (hi - lo < 1)
        return;
    int mid = lo + (hi - lo) / 2;
    mergeSortRange(v, tmp, lo, mid, keyOf, asc);
    mergeSortRange(v, tmp, mid + 1, hi, keyOf, asc);

    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi)
    {
        int c = naturalCompare(keyOf(v[i]), keyOf(v[j]));
        bool takeLeft = asc ? (c <= 0) : (c >= 0);
        if (takeLeft)
            tmp[k++] = v[i++];
        else
            tmp[k++] = v[j++];
    }
    while (i <= mid) tmp[k++] = v[i++];
    while (j <= hi) tmp[k++] = v[j++];
    for (int x = lo; x <= hi; x++)
        v[x] = tmp[x];
}

struct BookKeyFn
{
    string key;
    string operator()(const Book &b) const { return bookKey(b, key); }
};

struct MemberKeyFn
{
    string key;
    string operator()(const Member &m) const { return memberKey(m, key); }
};

void mergeSortBooks(vector<Book> &books, const string &key, bool ascending)
{
    if (books.size() < 2) return;
    vector<Book> tmp(books.size());
    BookKeyFn fn;
    fn.key = key;
    mergeSortRange(books, tmp, 0, (int)books.size() - 1, fn, ascending);
}

void mergeSortMembers(vector<Member> &members, const string &key, bool ascending)
{
    if (members.size() < 2) return;
    vector<Member> tmp(members.size());
    MemberKeyFn fn;
    fn.key = key;
    mergeSortRange(members, tmp, 0, (int)members.size() - 1, fn, ascending);
}

int binarySearchBookById(const vector<Book> &v, const string &id, int &comparisons)
{
    comparisons = 0;
    int lo = 0, hi = (int)v.size() - 1;
    while (lo <= hi)
    {
        int mid = lo + (hi - lo) / 2;
        comparisons++;
        int c = naturalCompare(v[mid].getBookId(), id);
        if (c == 0) return mid;
        if (c < 0) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}

int binarySearchMemberById(const vector<Member> &v, const string &id, int &comparisons)
{
    comparisons = 0;
    int lo = 0, hi = (int)v.size() - 1;
    while (lo <= hi)
    {
        int mid = lo + (hi - lo) / 2;
        comparisons++;
        int c = naturalCompare(v[mid].getMemberId(), id);
        if (c == 0) return mid;
        if (c < 0) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}

// ================= Linear search (GUI search pages) =================

static string lowerCopy(const string &s)
{
    string o = s;
    for (size_t i = 0; i < o.size(); i++)
        o[i] = (char)tolower((unsigned char)o[i]);
    return o;
}

static bool containsNoCase(const string &haystack, const string &needleLower)
{
    return needleLower.empty() || lowerCopy(haystack).find(needleLower) != string::npos;
}

vector<Book> linearSearchBooks(const vector<Book> &books, const string &query,
                               const string &field, const string &statusFilter,
                               int &comparisons)
{
    vector<Book> out;
    string q = lowerCopy(query);
    comparisons = 0;
    for (size_t i = 0; i < books.size(); i++)
    {
        const Book &b = books[i];
        comparisons++;
        if (!statusFilter.empty() && b.getStatus() != statusFilter)
            continue;
        bool match;
        if (field == "id")
            match = containsNoCase(b.getBookId(), q);
        else if (field == "title")
            match = containsNoCase(b.getTitle(), q);
        else if (field == "author")
            match = containsNoCase(b.getAuthor(), q);
        else
            match = containsNoCase(b.getBookId(), q) || containsNoCase(b.getTitle(), q) ||
                    containsNoCase(b.getAuthor(), q) || containsNoCase(b.getCategory(), q);
        if (match)
            out.push_back(b);
    }
    return out;
}

vector<Member> linearSearchMembers(const vector<Member> &members, const string &query,
                                   const string &field, int &comparisons)
{
    vector<Member> out;
    string q = lowerCopy(query);
    comparisons = 0;
    for (size_t i = 0; i < members.size(); i++)
    {
        const Member &m = members[i];
        comparisons++;
        bool match;
        if (field == "id")
            match = containsNoCase(m.getMemberId(), q);
        else if (field == "name")
            match = containsNoCase(m.getName(), q);
        else if (field == "email")
            match = containsNoCase(m.getEmail(), q);
        else
            match = containsNoCase(m.getMemberId(), q) || containsNoCase(m.getName(), q) ||
                    containsNoCase(m.getEmail(), q) || containsNoCase(m.getPhone(), q);
        if (match)
            out.push_back(m);
    }
    return out;
}
