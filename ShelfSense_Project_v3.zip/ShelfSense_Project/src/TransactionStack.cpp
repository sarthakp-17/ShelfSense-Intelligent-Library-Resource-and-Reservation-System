#include "../include/TransactionStack.h"
#include <fstream>
#include <sstream>
#include <ctime>
#include <cstdio>
#include <cstdlib>

using namespace std;

TransactionNode::TransactionNode(Transaction t)
{
    data = t;
    next = nullptr;
}

TransactionStack::TransactionStack()
{
    top = nullptr;
    count = 0;
    nextId = 1;
}

TransactionStack::~TransactionStack()
{
    Transaction ignored;
    while (pop(ignored))
    {
    }
}

void TransactionStack::push(Transaction t)
{
    TransactionNode *node = new TransactionNode(t);
    node->next = top;
    top = node;
    count++;
    if (t.getTxnId() >= nextId)
        nextId = t.getTxnId() + 1;
}

bool TransactionStack::pop(Transaction &out)
{
    if (top == nullptr)
        return false;
    TransactionNode *temp = top;
    out = temp->data;
    top = top->next;
    delete temp;
    count--;
    return true;
}

bool TransactionStack::peek(Transaction &out) const
{
    if (top == nullptr)
        return false;
    out = top->data;
    return true;
}

bool TransactionStack::isEmpty() const { return top == nullptr; }
int TransactionStack::size() const { return count; }

static string currentTimestamp()
{
    time_t now = time(nullptr);
    tm *local = localtime(&now);
    char buffer[64];
    if (local == nullptr)
        return "";
    snprintf(buffer, sizeof(buffer), "%02d-%02d-%04d %02d:%02d",
             local->tm_mday, local->tm_mon + 1, local->tm_year + 1900,
             local->tm_hour, local->tm_min);
    return string(buffer);
}

void TransactionStack::record(string type, string memberId, string bookId, string details)
{
    push(Transaction(nextId, type, memberId, bookId, currentTimestamp(), details));
}

vector<Transaction> TransactionStack::toVector() const
{
    vector<Transaction> all;
    for (TransactionNode *current = top; current != nullptr; current = current->next)
        all.push_back(current->data);
    return all;
}

// File stores bottom -> top so that re-loading (pushing in file order)
// rebuilds exactly the same stack.
bool TransactionStack::saveToFile(const string &filename) const
{
    ofstream file(filename);
    if (!file.is_open())
        return false;

    vector<Transaction> all = toVector();
    for (int i = static_cast<int>(all.size()) - 1; i >= 0; i--)
    {
        file << all[i].getTxnId() << "|" << all[i].getType() << "|"
             << all[i].getMemberId() << "|" << all[i].getBookId() << "|"
             << all[i].getTimestamp() << "|" << all[i].getDetails() << "\n";
    }
    return file.good();
}

bool TransactionStack::loadFromFile(const string &filename)
{
    ifstream file(filename);
    if (!file.is_open())
        return true; // first run

    string line;
    while (getline(file, line))
    {
        if (!line.empty() && line[line.size() - 1] == '\r')
            line.erase(line.size() - 1);
        stringstream ss(line);
        string f[6];
        bool valid = true;
        for (int i = 0; i < 5; i++)
        {
            if (!getline(ss, f[i], '|'))
            {
                valid = false;
                break;
            }
        }
        if (!valid)
            continue;
        getline(ss, f[5]); // details (may be empty)
        long long id = atoll(f[0].c_str());
        if (id <= 0)
            continue;
        push(Transaction(id, f[1], f[2], f[3], f[4], f[5]));
    }
    return true;
}
