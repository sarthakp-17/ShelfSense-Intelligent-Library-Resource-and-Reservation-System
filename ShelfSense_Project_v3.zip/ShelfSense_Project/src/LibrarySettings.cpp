#include "../include/LibrarySettings.h"

#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cstdio>

using namespace std;

const double LibrarySettings::DEFAULT_FINE_PER_DAY = 5.0;
const int LibrarySettings::DEFAULT_LOAN_DAYS = 14;
const int LibrarySettings::DEFAULT_DUE_SOON_DAYS = 3;

LibrarySettings::LibrarySettings()
{
    finePerDay = DEFAULT_FINE_PER_DAY;
    loanDays = DEFAULT_LOAN_DAYS;
    dueSoonDays = DEFAULT_DUE_SOON_DAYS;
    theme = "system";
}

string LibrarySettings::validate(double fine, int loan, int dueSoon, const string &t)
{
    if (!(fine >= 0.0 && fine <= 1000.0))
        return "Fine per late day must be between 0 and 1000.";
    if (loan < 1 || loan > 365)
        return "Default loan period must be between 1 and 365 days.";
    if (dueSoon < 0 || dueSoon > 60)
        return "The 'due soon' window must be between 0 and 60 days.";
    if (t != "system" && t != "light" && t != "dark")
        return "Theme must be system, light or dark.";
    return "";
}

static bool parseDouble(const string &s, double &out)
{
    if (s.empty())
        return false;
    char *end = NULL;
    out = strtod(s.c_str(), &end);
    return end != NULL && *end == '\0';
}

static bool parseInt(const string &s, int &out)
{
    if (s.empty())
        return false;
    char *end = NULL;
    long v = strtol(s.c_str(), &end, 10);
    if (end == NULL || *end != '\0')
        return false;
    out = (int)v;
    return true;
}

bool LibrarySettings::loadFromFile(const string &filename, string &warning)
{
    warning = "";
    ifstream file(filename.c_str());
    if (!file.is_open())
        return true; // first run: keep defaults

    LibrarySettings defaults;
    string line, ignored;
    while (getline(file, line))
    {
        if (!line.empty() && line[line.size() - 1] == '\r')
            line.erase(line.size() - 1);
        if (line.empty() || line[0] == '#')
            continue;
        size_t eq = line.find('=');
        if (eq == string::npos)
            continue;
        string key = line.substr(0, eq);
        string value = line.substr(eq + 1);

        double d = 0;
        int i = 0;
        bool ok = true;
        if (key == "finePerDay")
        {
            ok = parseDouble(value, d) && validate(d, loanDays, dueSoonDays, theme).empty();
            if (ok) finePerDay = d;
        }
        else if (key == "loanDays")
        {
            ok = parseInt(value, i) && validate(finePerDay, i, dueSoonDays, theme).empty();
            if (ok) loanDays = i;
        }
        else if (key == "dueSoonDays")
        {
            ok = parseInt(value, i) && validate(finePerDay, loanDays, i, theme).empty();
            if (ok) dueSoonDays = i;
        }
        else if (key == "theme")
        {
            ok = validate(finePerDay, loanDays, dueSoonDays, value).empty();
            if (ok) theme = value;
        }
        if (!ok)
            ignored += (ignored.empty() ? "" : ", ") + key;
    }
    if (!ignored.empty())
        warning = "settings.txt: invalid value for " + ignored + "; default used.";
    return true;
}

bool LibrarySettings::saveToFile(const string &filename) const
{
    ofstream file(filename.c_str());
    if (!file.is_open())
        return false;
    char fine[32];
    snprintf(fine, sizeof(fine), "%.2f", finePerDay);
    file << "# ShelfSense settings (edit through the Settings page)\n"
         << "finePerDay=" << fine << "\n"
         << "loanDays=" << loanDays << "\n"
         << "dueSoonDays=" << dueSoonDays << "\n"
         << "theme=" << theme << "\n";
    return file.good();
}
