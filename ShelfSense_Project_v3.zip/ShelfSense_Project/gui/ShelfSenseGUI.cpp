// =====================================================================
//  ShelfSense GUI host
//  - Owns one LibraryService (the existing C++ data structures)
//  - Serves the interface (assets/index.html) and a small JSON API on
//    127.0.0.1 only (never reachable from the network)
//  - On Windows: opens the interface in a chromeless Microsoft Edge /
//    Google Chrome "app" window and exits when that window is closed.
// =====================================================================

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <windows.h>
#include <shellapi.h>
typedef SOCKET sock_t;
#define CLOSESOCK closesocket
#else
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
typedef int sock_t;
#ifndef INVALID_SOCKET
#define INVALID_SOCKET (-1)
#endif
#define CLOSESOCK close
#endif

#include <string>
#include <vector>
#include <map>
#include <set>
#include <sstream>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <random>

#include "../include/LibraryService.h"
#include "../include/FileStore.h"
#include "../include/DueDateHeap.h"
#include "../include/SortSearch.h"
#include "embedded_index.h"

using namespace std;

// ------------------------------------------------------------------
// Globals
// ------------------------------------------------------------------
static LibraryService *g_lib = nullptr;
static string g_exeDir;
static string g_dataDir;
static string g_assetsDir;
static volatile time_t g_lastHeartbeat = 0;
static volatile time_t g_byeAt = 0;
static volatile bool g_byePending = false;
static string g_token;   // per-session secret; required on every /api/ call (see handleRequest)
static const char *APP_VERSION = "3.0";

#ifdef _WIN32
static CRITICAL_SECTION g_cs;
static void lockInit() { InitializeCriticalSection(&g_cs); }
static void lockAll() { EnterCriticalSection(&g_cs); }
static void unlockAll() { LeaveCriticalSection(&g_cs); }
static void sleepSeconds(int s) { Sleep((DWORD)s * 1000); }
static const char PATH_SEP = '\\';
#else
static pthread_mutex_t g_mx = PTHREAD_MUTEX_INITIALIZER;
static void lockInit() {}
static void lockAll() { pthread_mutex_lock(&g_mx); }
static void unlockAll() { pthread_mutex_unlock(&g_mx); }
static void sleepSeconds(int s) { sleep((unsigned)s); }
static const char PATH_SEP = '/';
#endif

struct Guard
{
    Guard() { lockAll(); }
    ~Guard() { unlockAll(); }
};

// Random 32-hex-character token. It is written into the page when the page is
// served, and the page sends it back in the X-ShelfSense-Token header. Other
// web pages open in a browser cannot read it, so they cannot drive the API.
static string makeToken()
{
    std::random_device rd;
    unsigned long long seed = ((unsigned long long)rd() << 32) ^ rd() ^
                              (unsigned long long)time(nullptr) ^
                              ((unsigned long long)clock() << 16) ^
                              (unsigned long long)(size_t)&seed;
    std::mt19937_64 gen(seed);
    const char *hex = "0123456789abcdef";
    string t;
    for (int i = 0; i < 32; i++)
        t += hex[gen() & 15];
    return t;
}

// ------------------------------------------------------------------
// Small utilities
// ------------------------------------------------------------------
static string joinPath(const string &a, const string &b)
{
    if (a.empty())
        return b;
    char last = a[a.size() - 1];
    if (last == '/' || last == '\\')
        return a + b;
    return a + PATH_SEP + b;
}

static void makeDir(const string &path)
{
#ifdef _WIN32
    CreateDirectoryA(path.c_str(), NULL);
#else
    mkdir(path.c_str(), 0755);
#endif
}

static string getExeDir()
{
#ifdef _WIN32
    char buf[4096];
    DWORD n = GetModuleFileNameA(NULL, buf, sizeof(buf));
    if (n == 0 || n >= sizeof(buf))
        return ".";
    string p(buf, n);
#else
    char buf[4096];
    ssize_t n = readlink("/proc/self/exe", buf, sizeof(buf) - 1);
    if (n <= 0)
        return ".";
    string p(buf, (size_t)n);
#endif
    size_t pos = p.find_last_of("/\\");
    if (pos == string::npos)
        return ".";
    return p.substr(0, pos);
}

static bool readFile(const string &path, string &out)
{
    ifstream f(path.c_str(), ios::in | ios::binary);
    if (!f.is_open())
        return false;
    ostringstream ss;
    ss << f.rdbuf();
    out = ss.str();
    return true;
}

static string jstr(const string &s)
{
    string o;
    o.reserve(s.size() + 2);
    o += '"';
    for (size_t i = 0; i < s.size(); i++)
    {
        unsigned char c = (unsigned char)s[i];
        switch (c)
        {
        case '"': o += "\\\""; break;
        case '\\': o += "\\\\"; break;
        case '\n': o += "\\n"; break;
        case '\r': o += "\\r"; break;
        case '\t': o += "\\t"; break;
        default:
            if (c < 0x20)
            {
                char b[8];
                snprintf(b, sizeof(b), "\\u%04x", c);
                o += b;
            }
            else
                o += (char)c;
        }
    }
    o += '"';
    return o;
}

static string jnum(double v)
{
    char b[64];
    snprintf(b, sizeof(b), "%.2f", v);
    return b;
}

static string jint(long long v)
{
    ostringstream o;
    o << v;
    return o.str();
}

static int hexVal(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static string urlDecode(const string &s)
{
    string o;
    for (size_t i = 0; i < s.size(); i++)
    {
        if (s[i] == '+')
            o += ' ';
        else if (s[i] == '%' && i + 2 < s.size() && hexVal(s[i + 1]) >= 0 && hexVal(s[i + 2]) >= 0)
        {
            o += (char)(hexVal(s[i + 1]) * 16 + hexVal(s[i + 2]));
            i += 2;
        }
        else
            o += s[i];
    }
    return o;
}

static map<string, string> parseForm(const string &s)
{
    map<string, string> m;
    size_t start = 0;
    while (start <= s.size())
    {
        size_t amp = s.find('&', start);
        if (amp == string::npos)
            amp = s.size();
        string pair = s.substr(start, amp - start);
        if (!pair.empty())
        {
            size_t eq = pair.find('=');
            if (eq == string::npos)
                m[urlDecode(pair)] = "";
            else
                m[urlDecode(pair.substr(0, eq))] = urlDecode(pair.substr(eq + 1));
        }
        start = amp + 1;
    }
    return m;
}

static string field(map<string, string> &m, const string &key)
{
    map<string, string>::iterator it = m.find(key);
    return it == m.end() ? string() : it->second;
}

// ------------------------------------------------------------------
// JSON views of the backend structures
// ------------------------------------------------------------------
static string resultJson(const OpResult &r)
{
    ostringstream o;
    o << "{\"ok\":" << (r.ok ? "true" : "false")
      << ",\"message\":" << jstr(r.message)
      << ",\"lateDays\":" << r.lateDays
      << ",\"fine\":" << jnum(r.fine)
      << ",\"autoIssuedTo\":" << jstr(r.autoIssuedTo)
      << ",\"saved\":" << (r.saved ? "true" : "false")
      << ",\"borrowerId\":" << jstr(r.borrowerId)
      << ",\"dueDate\":" << jstr(r.dueDate)
      << ",\"nextInQueue\":" << jstr(r.nextInQueue) << "}";
    return o.str();
}

// Everything the interface displays, computed from the backend structures.
// The page never invents numbers: counts, days left and fines all come from here.
static string stateJson()
{
    LibraryService &L = *g_lib;
    const LibrarySettings &S = L.settings;
    string today = LibraryService::today();
    long todayNum = dateToDayNumber(today);

    vector<Book> books = L.books.getAllBooks();               // linked-list traversal
    vector<Member> members = L.members.getAllMembers();
    vector<BorrowRecord> records = L.borrows.getAllRecords();
    vector<Reservation> queue = L.queue.getAllReservations(); // FIFO order
    vector<Reservation> hist = L.history.getAll();
    vector<Transaction> txns = L.transactions.toVector();     // stack: newest first

    map<string, BorrowRecord> activeByBook;
    map<string, int> borrowCountMember, activeCountMember, overdueCountMember, borrowCountBook;
    map<string, double> finesMember;
    for (size_t i = 0; i < records.size(); i++)
    {
        BorrowRecord r = records[i];
        borrowCountMember[r.getMemberId()]++;
        borrowCountBook[r.getBookId()]++;
        finesMember[r.getMemberId()] += r.getFine();
        if (r.getStatus() == "Issued")
        {
            activeByBook[r.getBookId()] = r;
            activeCountMember[r.getMemberId()]++;
            long due = dateToDayNumber(r.getDueDate());
            if (due >= 0 && todayNum >= 0 && due < todayNum)
                overdueCountMember[r.getMemberId()]++;
        }
    }
    map<string, int> pendingMember;
    for (size_t i = 0; i < queue.size(); i++)
        pendingMember[queue[i].getMemberId()]++;

    int available = 0, issued = 0, reserved = 0;
    ostringstream o;
    o << "{\"version\":" << jstr(APP_VERSION)
      << ",\"today\":" << jstr(today)
      << ",\"dataDir\":" << jstr(g_dataDir)
      << ",\"lastBackup\":" << jstr(L.lastBackupDir)
      << ",\"settings\":{\"finePerDay\":" << jnum(S.finePerDay)
      << ",\"loanDays\":" << S.loanDays << ",\"dueSoonDays\":" << S.dueSoonDays
      << ",\"theme\":" << jstr(S.theme)
      << ",\"defaultFinePerDay\":" << jnum(LibrarySettings::DEFAULT_FINE_PER_DAY)
      << ",\"defaultLoanDays\":" << LibrarySettings::DEFAULT_LOAN_DAYS
      << ",\"defaultDueSoonDays\":" << LibrarySettings::DEFAULT_DUE_SOON_DAYS << "}";

    o << ",\"warnings\":[";
    for (size_t i = 0; i < L.loadWarnings.size(); i++)
        o << (i ? "," : "") << jstr(L.loadWarnings[i]);
    o << "]";

    // Books in linked-list order (new books are appended at the tail, so the
    // last entries are the most recently added ones).
    o << ",\"books\":[";
    for (size_t i = 0; i < books.size(); i++)
    {
        const Book &b = books[i];
        if (b.getStatus() == "Available") available++;
        else if (b.getStatus() == "Issued") issued++;
        else if (b.getStatus() == "Reserved") reserved++;
        string borrower, due, issuedOn;
        map<string, BorrowRecord>::iterator it = activeByBook.find(b.getBookId());
        if (it != activeByBook.end())
        {
            borrower = it->second.getMemberId();
            due = it->second.getDueDate();
            issuedOn = it->second.getIssueDate();
        }
        if (i) o << ",";
        o << "{\"id\":" << jstr(b.getBookId()) << ",\"title\":" << jstr(b.getTitle())
          << ",\"author\":" << jstr(b.getAuthor()) << ",\"category\":" << jstr(b.getCategory())
          << ",\"status\":" << jstr(b.getStatus())
          << ",\"queue\":" << L.queue.countForBook(b.getBookId())
          << ",\"borrower\":" << jstr(borrower) << ",\"due\":" << jstr(due)
          << ",\"issued\":" << jstr(issuedOn)
          << ",\"timesIssued\":" << borrowCountBook[b.getBookId()]
          << ",\"listIndex\":" << i << "}";
    }
    o << "]";

    o << ",\"members\":[";
    for (size_t i = 0; i < members.size(); i++)
    {
        const Member &m = members[i];
        string id = m.getMemberId();
        if (i) o << ",";
        o << "{\"id\":" << jstr(id) << ",\"name\":" << jstr(m.getName())
          << ",\"email\":" << jstr(m.getEmail()) << ",\"phone\":" << jstr(m.getPhone())
          << ",\"activeLoans\":" << activeCountMember[id]
          << ",\"overdue\":" << overdueCountMember[id]
          << ",\"pending\":" << pendingMember[id]
          << ",\"totalBorrows\":" << borrowCountMember[id]
          << ",\"fines\":" << jnum(finesMember[id]) << "}";
    }
    o << "]";

    // Borrow records in insertion order (chronological). For active loans the
    // estimated fine uses the same rule as a return today: late days x rate.
    int overdue = 0, dueSoon = 0, activeLoans = 0, returned = 0, returnedLate = 0;
    double finesCollected = 0, finesAccruing = 0;
    o << ",\"records\":[";
    for (size_t i = 0; i < records.size(); i++)
    {
        BorrowRecord r = records[i];
        long dueNum = dateToDayNumber(r.getDueDate());
        long daysLeft = (dueNum >= 0 && todayNum >= 0) ? dueNum - todayNum : 0;
        double est = 0;
        string state = "returned";
        if (r.getStatus() == "Issued")
        {
            activeLoans++;
            if (daysLeft < 0)
            {
                overdue++;
                state = "overdue";
                est = -daysLeft * S.finePerDay;
                finesAccruing += est;
            }
            else if (daysLeft <= S.dueSoonDays)
            {
                dueSoon++;
                state = "dueSoon";
            }
            else
                state = "onLoan";
        }
        else
        {
            returned++;
            if (r.getFine() > 0) returnedLate++;
            finesCollected += r.getFine();
        }
        if (i) o << ",";
        o << "{\"seq\":" << i << ",\"memberId\":" << jstr(r.getMemberId())
          << ",\"bookId\":" << jstr(r.getBookId())
          << ",\"issueDate\":" << jstr(r.getIssueDate()) << ",\"dueDate\":" << jstr(r.getDueDate())
          << ",\"status\":" << jstr(r.getStatus()) << ",\"state\":" << jstr(state)
          << ",\"fine\":" << jnum(r.getFine())
          << ",\"daysLeft\":" << daysLeft << ",\"estFine\":" << jnum(est) << "}";
    }
    o << "]";

    // Reservation queue (FIFO order) with each member's position for that book
    map<string, int> posCounter;
    o << ",\"queue\":[";
    for (size_t i = 0; i < queue.size(); i++)
    {
        int pos = ++posCounter[queue[i].getBookId()];
        if (i) o << ",";
        o << "{\"memberId\":" << jstr(queue[i].getMemberId())
          << ",\"bookId\":" << jstr(queue[i].getBookId())
          << ",\"date\":" << jstr(queue[i].getReservationDate())
          << ",\"position\":" << pos << ",\"order\":" << (i + 1) << "}";
    }
    o << "]";

    o << ",\"history\":[";
    for (size_t i = 0; i < hist.size(); i++)
    {
        if (i) o << ",";
        o << "{\"memberId\":" << jstr(hist[i].getMemberId())
          << ",\"bookId\":" << jstr(hist[i].getBookId())
          << ",\"date\":" << jstr(hist[i].getReservationDate())
          << ",\"status\":" << jstr(hist[i].getStatus()) << "}";
    }
    o << "]";

    // Transaction stack, top -> bottom (newest first)
    o << ",\"transactions\":[";
    for (size_t i = 0; i < txns.size(); i++)
    {
        if (i) o << ",";
        o << "{\"id\":" << jint(txns[i].getTxnId()) << ",\"type\":" << jstr(txns[i].getType())
          << ",\"memberId\":" << jstr(txns[i].getMemberId())
          << ",\"bookId\":" << jstr(txns[i].getBookId())
          << ",\"time\":" << jstr(txns[i].getTimestamp())
          << ",\"details\":" << jstr(txns[i].getDetails()) << "}";
    }
    o << "]";

    // Due-date Min-Heap: every active loan, extracted in deadline order
    DueDateHeap heap;
    for (map<string, BorrowRecord>::iterator it = activeByBook.begin(); it != activeByBook.end(); ++it)
        heap.insert(it->second);
    int heapSize = heap.size();
    o << ",\"dueOrder\":[";
    DueEntry e;
    bool first = true;
    while (heap.extractMin(e))
    {
        if (!first) o << ",";
        first = false;
        o << "{\"bookId\":" << jstr(e.record.getBookId())
          << ",\"memberId\":" << jstr(e.record.getMemberId())
          << ",\"issueDate\":" << jstr(e.record.getIssueDate())
          << ",\"dueDate\":" << jstr(e.record.getDueDate())
          << ",\"daysLeft\":" << (todayNum >= 0 && e.dueKey >= 0 ? e.dueKey - todayNum : 0) << "}";
    }
    o << "]";

    o << ",\"stats\":{\"totalBooks\":" << books.size()
      << ",\"available\":" << available << ",\"issued\":" << issued
      << ",\"reserved\":" << reserved << ",\"members\":" << members.size()
      << ",\"activeLoans\":" << activeLoans << ",\"overdue\":" << overdue
      << ",\"dueSoon\":" << dueSoon << ",\"pendingReservations\":" << queue.size()
      << ",\"returned\":" << returned << ",\"returnedLate\":" << returnedLate
      << ",\"finesCollected\":" << jnum(finesCollected)
      << ",\"finesAccruing\":" << jnum(finesAccruing)
      << ",\"transactions\":" << L.transactions.size()
      << ",\"heapSize\":" << heapSize
      << ",\"totalRecords\":" << records.size() << "}";
    o << "}";
    return o.str();
}

// Search endpoint: linear search over the linked-list traversal, then merge
// sort. For an ID query the exact match is also looked up with binary search.
static string searchJson(map<string, string> &q)
{
    string entity = field(q, "entity");
    string text = field(q, "q");
    string fieldName = field(q, "field");
    string status = field(q, "status");
    string key = field(q, "sort");
    bool asc = field(q, "dir") != "desc";
    if (key.empty()) key = "id";

    size_t a = text.find_first_not_of(" \t");
    size_t b = text.find_last_not_of(" \t");
    text = (a == string::npos) ? "" : text.substr(a, b - a + 1);

    int linearComparisons = 0, binaryComparisons = 0, exactIndex = -1;
    size_t scanned = 0;
    string exactId;
    ostringstream o;
    o << "{\"query\":" << jstr(text) << ",\"ids\":[";
    if (entity == "members")
    {
        vector<Member> all = g_lib->members.getAllMembers();
        scanned = all.size();
        vector<Member> hits = linearSearchMembers(all, text, fieldName, linearComparisons);
        mergeSortMembers(hits, key, asc);
        for (size_t i = 0; i < hits.size(); i++)
            o << (i ? "," : "") << jstr(hits[i].getMemberId());
        if (!text.empty())
        {
            mergeSortMembers(all, "id", true);
            exactIndex = binarySearchMemberById(all, text, binaryComparisons);
            if (exactIndex >= 0) exactId = all[exactIndex].getMemberId();
        }
    }
    else
    {
        vector<Book> all = g_lib->books.getAllBooks();
        scanned = all.size();
        vector<Book> hits = linearSearchBooks(all, text, fieldName, status, linearComparisons);
        mergeSortBooks(hits, key, asc);
        for (size_t i = 0; i < hits.size(); i++)
            o << (i ? "," : "") << jstr(hits[i].getBookId());
        if (!text.empty())
        {
            mergeSortBooks(all, "id", true);
            exactIndex = binarySearchBookById(all, text, binaryComparisons);
            if (exactIndex >= 0) exactId = all[exactIndex].getBookId();
        }
    }
    o << "],\"scanned\":" << scanned << ",\"linearComparisons\":" << linearComparisons
      << ",\"sortKey\":" << jstr(key) << ",\"ascending\":" << (asc ? "true" : "false")
      << ",\"exactId\":" << jstr(exactId) << ",\"binaryComparisons\":" << binaryComparisons << "}";
    return o.str();
}

static string sortJson(map<string, string> &q)
{
    string entity = field(q, "entity");
    string key = field(q, "key");
    bool asc = field(q, "dir") != "desc";
    ostringstream o;
    o << "{\"algorithm\":\"Merge Sort\",\"key\":" << jstr(key) << ",\"ids\":[";
    if (entity == "members")
    {
        vector<Member> v = g_lib->members.getAllMembers();
        mergeSortMembers(v, key, asc);
        for (size_t i = 0; i < v.size(); i++)
            o << (i ? "," : "") << jstr(v[i].getMemberId());
        o << "],\"n\":" << v.size() << "}";
    }
    else
    {
        vector<Book> v = g_lib->books.getAllBooks();
        mergeSortBooks(v, key, asc);
        for (size_t i = 0; i < v.size(); i++)
            o << (i ? "," : "") << jstr(v[i].getBookId());
        o << "],\"n\":" << v.size() << "}";
    }
    return o.str();
}

static string findJson(map<string, string> &q)
{
    string entity = field(q, "entity");
    string id = field(q, "id");
    size_t a = id.find_first_not_of(" \t");
    size_t b = id.find_last_not_of(" \t");
    id = (a == string::npos) ? "" : id.substr(a, b - a + 1);
    int comparisons = 0, index = -1;
    size_t n = 0;
    string foundId;
    if (entity == "members")
    {
        vector<Member> v = g_lib->members.getAllMembers();
        mergeSortMembers(v, "id", true);
        n = v.size();
        index = binarySearchMemberById(v, id, comparisons);
        if (index >= 0) foundId = v[index].getMemberId();
    }
    else
    {
        vector<Book> v = g_lib->books.getAllBooks();
        mergeSortBooks(v, "id", true);
        n = v.size();
        index = binarySearchBookById(v, id, comparisons);
        if (index >= 0) foundId = v[index].getBookId();
    }
    ostringstream o;
    o << "{\"found\":" << (index >= 0 ? "true" : "false") << ",\"id\":" << jstr(foundId)
      << ",\"query\":" << jstr(id) << ",\"comparisons\":" << comparisons
      << ",\"index\":" << index << ",\"n\":" << n << "}";
    return o.str();
}

// ------------------------------------------------------------------
// HTTP
// ------------------------------------------------------------------
static void sendAll(sock_t s, const string &data)
{
    size_t sent = 0;
    while (sent < data.size())
    {
        int chunk = (int)((data.size() - sent) > 65536 ? 65536 : (data.size() - sent));
        int n = send(s, data.data() + sent, chunk, 0);
        if (n <= 0)
            return;
        sent += (size_t)n;
    }
}

static void respond(sock_t s, int code, const string &type, const string &body)
{
    const char *text = "OK";
    if (code == 400) text = "Bad Request";
    else if (code == 403) text = "Forbidden";
    else if (code == 404) text = "Not Found";
    else if (code == 405) text = "Method Not Allowed";
    else if (code == 413) text = "Payload Too Large";
    else if (code == 500) text = "Internal Server Error";
    ostringstream h;
    h << "HTTP/1.1 " << code << " " << text << "\r\n"
      << "Content-Type: " << type << "\r\n"
      << "Content-Length: " << body.size() << "\r\n"
      << "Cache-Control: no-store\r\n"
      << "X-Content-Type-Options: nosniff\r\n"
      << "Connection: close\r\n\r\n";
    sendAll(s, h.str() + body);
}

static string toLower(string s)
{
    for (size_t i = 0; i < s.size(); i++)
        if (s[i] >= 'A' && s[i] <= 'Z') s[i] = (char)(s[i] - 'A' + 'a');
    return s;
}

static void scheduleShutdown();

static void handleRequest(sock_t s, const string &method, const string &path,
                          map<string, string> &query, const string &body,
                          const string &host, const string &token)
{
    const string JSON = "application/json; charset=utf-8";

    // Only answer requests addressed to this machine (blocks DNS-rebinding tricks)
    string h = toLower(host);
    size_t colon = h.rfind(':');
    string hostOnly = (colon == string::npos) ? h : h.substr(0, colon);
    if (!hostOnly.empty() && hostOnly != "127.0.0.1" && hostOnly != "localhost")
    {
        respond(s, 400, "text/plain", "Bad host");
        return;
    }

    if (method == "GET" && (path == "/" || path == "/index.html"))
    {
        string html;
        if (!readFile(joinPath(g_assetsDir, "index.html"), html))
            html.assign((const char *)EMBEDDED_INDEX_HTML, EMBEDDED_INDEX_HTML_LEN);
        // Hand the session token to this page only
        size_t at = html.find("__SHELFSENSE_TOKEN__");
        if (at != string::npos)
            html.replace(at, strlen("__SHELFSENSE_TOKEN__"), g_token);
        respond(s, 200, "text/html; charset=utf-8", html);
        return;
    }
    if (method == "GET" && path == "/favicon.ico")
    {
        string ico;
        if (readFile(joinPath(g_assetsDir, "shelfsense.ico"), ico))
            respond(s, 200, "image/x-icon", ico);
        else
            respond(s, 404, "text/plain", "none");
        return;
    }

    if (path.compare(0, 5, "/api/") != 0)
    {
        respond(s, 404, "text/plain", "Not found");
        return;
    }

    if (path == "/api/heartbeat" || path == "/api/bye")
    {
        Guard g;
        time_t now = time(nullptr);
        if (path == "/api/heartbeat")
        {
            g_lastHeartbeat = now;
            g_byePending = false;
        }
        else
        {
            g_byeAt = now;
            g_byePending = true;
        }
        respond(s, 200, JSON, "{\"ok\":true}");
        return;
    }

    // Every other API call must carry the session token (blocks requests made by
    // other web pages, which can reach 127.0.0.1 but cannot read the token).
    if (token != g_token)
    {
        respond(s, 403, JSON, "{\"ok\":false,\"message\":\"This request did not come from the ShelfSense window. Reload the window.\"}");
        return;
    }

    Guard g; // one request at a time touches the data structures

    if (method == "GET")
    {
        if (path == "/api/state")
            respond(s, 200, JSON, stateJson());
        else if (path == "/api/sort")
            respond(s, 200, JSON, sortJson(query));
        else if (path == "/api/find")
            respond(s, 200, JSON, findJson(query));
        else if (path == "/api/search")
            respond(s, 200, JSON, searchJson(query));
        else if (path == "/api/return/preview")
            respond(s, 200, JSON, resultJson(g_lib->previewReturn(field(query, "bookId"), field(query, "date"))));
        else
            respond(s, 404, JSON, "{\"ok\":false,\"message\":\"Unknown endpoint\"}");
        return;
    }

    if (method != "POST")
    {
        respond(s, 405, JSON, "{\"ok\":false,\"message\":\"Method not allowed\"}");
        return;
    }

    map<string, string> f = parseForm(body);
    LibraryService &L = *g_lib;
    OpResult r;
    bool known = true;

    if (path == "/api/books/add")
        r = L.addBook(field(f, "id"), field(f, "title"), field(f, "author"), field(f, "category"));
    else if (path == "/api/books/update")
        r = L.updateBook(field(f, "id"), field(f, "title"), field(f, "author"), field(f, "category"));
    else if (path == "/api/books/delete")
        r = L.deleteBook(field(f, "id"));
    else if (path == "/api/members/add")
        r = L.addMember(field(f, "id"), field(f, "name"), field(f, "email"), field(f, "phone"));
    else if (path == "/api/members/update")
        r = L.updateMember(field(f, "id"), field(f, "name"), field(f, "email"), field(f, "phone"));
    else if (path == "/api/members/delete")
        r = L.deleteMember(field(f, "id"));
    else if (path == "/api/issue")
        r = L.issueBook(field(f, "memberId"), field(f, "bookId"), field(f, "issueDate"), field(f, "dueDate"));
    else if (path == "/api/return")
        r = L.returnBook(field(f, "bookId"), field(f, "returnDate"), field(f, "nextDueDate"));
    else if (path == "/api/renew")
        r = L.renewBook(field(f, "bookId"), field(f, "newDueDate"));
    else if (path == "/api/reserve")
        r = L.reserveBook(field(f, "memberId"), field(f, "bookId"), field(f, "date"));
    else if (path == "/api/reservations/cancel")
        r = L.cancelReservation(field(f, "memberId"), field(f, "bookId"));
    else if (path == "/api/reservations/process")
        r = L.processNextReservation(field(f, "bookId"), field(f, "issueDate"), field(f, "dueDate"));
    else if (path == "/api/settings")
    {
        char *end1 = NULL, *end2 = NULL, *end3 = NULL;
        string fine = field(f, "finePerDay"), loan = field(f, "loanDays"), soon = field(f, "dueSoonDays");
        double fineValue = strtod(fine.c_str(), &end1);
        long loanValue = strtol(loan.c_str(), &end2, 10);
        long soonValue = strtol(soon.c_str(), &end3, 10);
        if (fine.empty() || loan.empty() || soon.empty() || *end1 || *end2 || *end3)
            r.message = "Enter numbers for the fine, loan period and due-soon window.";
        else
            r = L.updateSettings(fineValue, (int)loanValue, (int)soonValue, field(f, "theme"));
    }
    else if (path == "/api/backup")
        r = L.createBackup();
    else if (path == "/api/open-data-folder")
    {
#ifdef _WIN32
        HINSTANCE h = ShellExecuteA(NULL, "open", g_dataDir.c_str(), NULL, NULL, SW_SHOWNORMAL);
        r.ok = (INT_PTR)h > 32;
        r.message = r.ok ? "Data folder opened in File Explorer." : "Could not open " + g_dataDir + ".";
#else
        r.ok = true;
        r.message = "Data folder: " + g_dataDir;
#endif
    }
    else if (path == "/api/shutdown")
    {
        r.ok = L.saveAll();
        r.saved = r.ok;
        r.message = r.ok ? "All data saved. ShelfSense is closing."
                         : "Could not save " + L.lastSaveError + ". ShelfSense is closing anyway.";
        respond(s, 200, JSON, resultJson(r));
        scheduleShutdown();
        return;
    }
    else
        known = false;

    if (!known)
        respond(s, 404, JSON, "{\"ok\":false,\"message\":\"Unknown endpoint\"}");
    else
        respond(s, 200, JSON, resultJson(r));
}

static void handleConnection(sock_t s)
{
#ifdef _WIN32
    DWORD tv = 15000;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof(tv));
#else
    struct timeval tv;
    tv.tv_sec = 15;
    tv.tv_usec = 0;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof(tv));
#endif

    string data;
    char buf[8192];
    size_t headerEnd = string::npos;
    while (headerEnd == string::npos)
    {
        int n = recv(s, buf, sizeof(buf), 0);
        if (n <= 0)
        {
            CLOSESOCK(s);
            return;
        }
        data.append(buf, (size_t)n);
        headerEnd = data.find("\r\n\r\n");
        if (headerEnd == string::npos && data.size() > 65536)
        {
            respond(s, 413, "text/plain", "Header too large");
            CLOSESOCK(s);
            return;
        }
    }

    string head = data.substr(0, headerEnd);
    string body = data.substr(headerEnd + 4);

    size_t lineEnd = head.find("\r\n");
    string requestLine = head.substr(0, lineEnd);
    istringstream rl(requestLine);
    string method, target, version;
    rl >> method >> target >> version;

    size_t contentLength = 0;
    string host, token;
    size_t pos = lineEnd;
    while (pos != string::npos && pos < head.size())
    {
        size_t next = head.find("\r\n", pos + 2);
        string line = head.substr(pos + 2, (next == string::npos ? head.size() : next) - pos - 2);
        size_t c = line.find(':');
        if (c != string::npos)
        {
            string name = toLower(line.substr(0, c));
            string value = line.substr(c + 1);
            size_t v0 = value.find_first_not_of(" \t");
            value = (v0 == string::npos) ? "" : value.substr(v0);
            size_t v1 = value.find_last_not_of(" \t");
            value = (v1 == string::npos) ? "" : value.substr(0, v1 + 1);
            if (name == "content-length")
                contentLength = (size_t)strtoul(value.c_str(), NULL, 10);
            else if (name == "host")
                host = value;
            else if (name == "x-shelfsense-token")
                token = value;
        }
        pos = next;
    }

    if (contentLength > 1024 * 1024)
    {
        respond(s, 413, "text/plain", "Body too large");
        CLOSESOCK(s);
        return;
    }
    while (body.size() < contentLength)
    {
        int n = recv(s, buf, sizeof(buf), 0);
        if (n <= 0)
            break;
        body.append(buf, (size_t)n);
    }
    if (body.size() > contentLength)
        body.resize(contentLength);

    string path = target, qs;
    size_t qm = target.find('?');
    if (qm != string::npos)
    {
        path = target.substr(0, qm);
        qs = target.substr(qm + 1);
    }
    map<string, string> query = parseForm(qs);

    handleRequest(s, method, path, query, body, host, token);
    CLOSESOCK(s);
}

#ifdef _WIN32
static DWORD WINAPI connThreadProc(LPVOID p)
{
    handleConnection((sock_t)(UINT_PTR)p);
    return 0;
}
static void spawnConnection(sock_t c)
{
    HANDLE h = CreateThread(NULL, 0, connThreadProc, (LPVOID)(UINT_PTR)c, 0, NULL);
    if (h != NULL)
        CloseHandle(h);
    else
        handleConnection(c);
}
#else
static void *connThreadProc(void *p)
{
    handleConnection((sock_t)(intptr_t)p);
    return NULL;
}
static void spawnConnection(sock_t c)
{
    pthread_t t;
    if (pthread_create(&t, NULL, connThreadProc, (void *)(intptr_t)c) == 0)
        pthread_detach(t);
    else
        handleConnection(c);
}
#endif

static sock_t g_listen = INVALID_SOCKET;

static int openListener(int firstPort, int attempts)
{
    for (int port = firstPort; port < firstPort + attempts; port++)
    {
        sock_t s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (s == INVALID_SOCKET)
            return -1;
#ifndef _WIN32
        int yes = 1;
        setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(yes));
#endif
        struct sockaddr_in addr;
        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        addr.sin_port = htons((unsigned short)port);
        if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) == 0 && listen(s, 64) == 0)
        {
            g_listen = s;
            return port;
        }
        CLOSESOCK(s);
    }
    return -1;
}

static void acceptLoop()
{
    while (true)
    {
        struct sockaddr_in client;
#ifdef _WIN32
        int len = sizeof(client);
#else
        socklen_t len = sizeof(client);
#endif
        sock_t c = accept(g_listen, (struct sockaddr *)&client, &len);
        if (c == INVALID_SOCKET)
        {
            sleepSeconds(1);
            continue;
        }
        spawnConnection(c);
    }
}

#ifdef _WIN32
static DWORD WINAPI acceptThreadProc(LPVOID)
{
    acceptLoop();
    return 0;
}
#else
static void *acceptThreadProc(void *)
{
    acceptLoop();
    return NULL;
}
#endif

static bool startAcceptThread()
{
#ifdef _WIN32
    HANDLE h = CreateThread(NULL, 0, acceptThreadProc, NULL, 0, NULL);
    if (h == NULL)
        return false;
    CloseHandle(h);
    return true;
#else
    pthread_t t;
    if (pthread_create(&t, NULL, acceptThreadProc, NULL) != 0)
        return false;
    pthread_detach(t);
    return true;
#endif
}

// ------------------------------------------------------------------
// Lifetime: exit when the interface window is gone
// ------------------------------------------------------------------
static void shutdownAndExit()
{
    {
        Guard g;
        if (g_lib)
            g_lib->saveAll();
    }
#ifdef _WIN32
    ExitProcess(0);
#else
    _exit(0);
#endif
}

// "Exit application" from the sidebar: the reply is sent first, then the
// process saves again and exits half a second later.
#ifdef _WIN32
static DWORD WINAPI shutdownThreadProc(LPVOID)
{
    Sleep(500);
    shutdownAndExit();
    return 0;
}
static void scheduleShutdown()
{
    HANDLE h = CreateThread(NULL, 0, shutdownThreadProc, NULL, 0, NULL);
    if (h != NULL)
        CloseHandle(h);
}
#else
static void *shutdownThreadProc(void *)
{
    usleep(500000);
    shutdownAndExit();
    return NULL;
}
static void scheduleShutdown()
{
    pthread_t t;
    if (pthread_create(&t, NULL, shutdownThreadProc, NULL) == 0)
        pthread_detach(t);
}
#endif

// Returns when the UI has gone away:
//  - the browser window we launched was closed (processHandle signalled), or
//  - the page said goodbye and did not come back within 6 s (window closed), or
//  - no heartbeat for 3 minutes.
static void watchLifetime(void *processHandle)
{
    time_t started = time(nullptr);
    bool watchProcess = processHandle != nullptr;
    while (true)
    {
        sleepSeconds(1);
        time_t now = time(nullptr);
#ifdef _WIN32
        if (watchProcess)
        {
            if (WaitForSingleObject((HANDLE)processHandle, 0) == WAIT_OBJECT_0)
            {
                // A browser that exits within seconds handed the window to an
                // already-running instance; fall back to heartbeat tracking.
                if (now - started >= 10)
                    return;
                watchProcess = false;
            }
        }
#endif
        time_t last, byeAt;
        bool byePending;
        {
            Guard g;
            last = g_lastHeartbeat;
            byeAt = g_byeAt;
            byePending = g_byePending;
        }
        if (byePending && now - byeAt >= 6)
            return;
        if (last != 0 && now - last > 180)
            return;
        if (last == 0 && !watchProcess && now - started > 180)
            return;
    }
}

// ------------------------------------------------------------------
// Windows: find Edge / Chrome and open a chromeless app window
// ------------------------------------------------------------------
#ifdef _WIN32
static bool fileExists(const string &p)
{
    DWORD a = GetFileAttributesA(p.c_str());
    return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY);
}

static string envStr(const char *name)
{
    const char *v = getenv(name);
    return v ? string(v) : string();
}

static string appPathFromRegistry(HKEY root, const char *exe)
{
    string sub = string("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\") + exe;
    HKEY key;
    if (RegOpenKeyExA(root, sub.c_str(), 0, KEY_READ, &key) != ERROR_SUCCESS)
        return "";
    char buf[2048];
    DWORD size = sizeof(buf) - 1;
    DWORD type = 0;
    LONG rc = RegQueryValueExA(key, NULL, NULL, &type, (LPBYTE)buf, &size);
    RegCloseKey(key);
    if (rc != ERROR_SUCCESS || (type != REG_SZ && type != REG_EXPAND_SZ))
        return "";
    buf[size < sizeof(buf) ? size : sizeof(buf) - 1] = 0;
    string s(buf);
    if (s.size() >= 2 && s[0] == '"')
        s = s.substr(1, s.find('"', 1) - 1);
    return s;
}

static string findBrowser()
{
    vector<string> c;
    c.push_back(appPathFromRegistry(HKEY_LOCAL_MACHINE, "msedge.exe"));
    c.push_back(appPathFromRegistry(HKEY_CURRENT_USER, "msedge.exe"));
    string pf86 = envStr("ProgramFiles(x86)"), pf = envStr("ProgramFiles"), lad = envStr("LOCALAPPDATA");
    if (!pf86.empty()) c.push_back(pf86 + "\\Microsoft\\Edge\\Application\\msedge.exe");
    if (!pf.empty()) c.push_back(pf + "\\Microsoft\\Edge\\Application\\msedge.exe");
    if (!lad.empty()) c.push_back(lad + "\\Microsoft\\Edge\\Application\\msedge.exe");
    c.push_back(appPathFromRegistry(HKEY_LOCAL_MACHINE, "chrome.exe"));
    c.push_back(appPathFromRegistry(HKEY_CURRENT_USER, "chrome.exe"));
    if (!pf.empty()) c.push_back(pf + "\\Google\\Chrome\\Application\\chrome.exe");
    if (!pf86.empty()) c.push_back(pf86 + "\\Google\\Chrome\\Application\\chrome.exe");
    if (!lad.empty()) c.push_back(lad + "\\Google\\Chrome\\Application\\chrome.exe");
    for (size_t i = 0; i < c.size(); i++)
        if (!c[i].empty() && fileExists(c[i]))
            return c[i];
    return "";
}

// Returns the browser process handle (or NULL if no app-capable browser was found)
static HANDLE openAppWindow(const string &url)
{
    string browser = findBrowser();
    if (browser.empty())
        return NULL;

    string base = envStr("LOCALAPPDATA");
    if (base.empty())
        base = envStr("TEMP");
    string profile = base + "\\ShelfSense";
    makeDir(profile);
    profile += "\\WindowProfile";
    makeDir(profile);

    string cmd = "\"" + browser + "\" --app=" + url +
                 " --user-data-dir=\"" + profile + "\"" +
                 " --no-first-run --no-default-browser-check --disable-background-mode"
                 " --disable-sync --start-maximized";
    vector<char> line(cmd.begin(), cmd.end());
    line.push_back(0);

    STARTUPINFOA si;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi;
    ZeroMemory(&pi, sizeof(pi));
    if (!CreateProcessA(NULL, &line[0], NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
        return NULL;
    CloseHandle(pi.hThread);
    return pi.hProcess;
}

static void showError(const string &msg)
{
    MessageBoxA(NULL, msg.c_str(), "ShelfSense", MB_OK | MB_ICONERROR);
}
#endif

static void writePortFile(int port)
{
    ofstream f(joinPath(g_dataDir, ".instance_port").c_str());
    f << port;
}

#ifdef _WIN32
static int readPortFile()
{
    ifstream f(joinPath(g_dataDir, ".instance_port").c_str());
    int port = 0;
    f >> port;
    return port;
}
#endif

// ------------------------------------------------------------------
// main
// ------------------------------------------------------------------
int main(int argc, char **argv)
{
    bool openWindow = true;   // Windows: open the app window
    bool watch = false;       // Linux test mode: exit on heartbeat loss
    int preferredPort = 47821;
    for (int i = 1; i < argc; i++)
    {
        string a = argv[i];
        if (a == "--no-window") openWindow = false;
        else if (a == "--watch") watch = true;
        else if (a == "--port" && i + 1 < argc) preferredPort = atoi(argv[++i]);
    }

    g_exeDir = getExeDir();
    g_dataDir = joinPath(g_exeDir, "data");
    g_assetsDir = joinPath(g_exeDir, "assets");
    makeDir(g_dataDir);
    lockInit();

#ifdef _WIN32
    // Single instance: a second double-click just opens another window
    HANDLE instanceMutex = CreateMutexA(NULL, TRUE, "Local\\ShelfSenseLibraryGUI");
    if (instanceMutex != NULL && GetLastError() == ERROR_ALREADY_EXISTS)
    {
        int port = readPortFile();
        if (port > 0)
        {
            char url[64];
            snprintf(url, sizeof(url), "http://127.0.0.1:%d/", port);
            if (openAppWindow(url) == NULL)
                ShellExecuteA(NULL, "open", url, NULL, NULL, SW_SHOWNORMAL);
        }
        return 0;
    }

    // Double-clicking the exe inside a ZIP runs it from a temp folder
    // without the data/ and assets/ folders next to it.
    {
        DWORD attr = GetFileAttributesA(g_assetsDir.c_str());
        bool hasAssets = attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY);
        if (!hasAssets)
        {
            int choice = MessageBoxA(NULL,
                "ShelfSense could not find its 'assets' folder next to ShelfSense.exe.\n\n"
                "If you opened ShelfSense from inside the ZIP file, close this message,\n"
                "right-click the ZIP and choose 'Extract All', then run ShelfSense.exe\n"
                "from the extracted folder.\n\n"
                "Click OK to continue anyway with an empty library, or Cancel to exit.",
                "ShelfSense", MB_OKCANCEL | MB_ICONWARNING);
            if (choice != IDOK)
                return 0;
        }
    }

    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
    {
        showError("Could not start Windows networking (WSAStartup failed).");
        return 1;
    }
#else
    signal(SIGPIPE, SIG_IGN);
#endif

    g_token = makeToken();
    g_lib = new LibraryService(g_dataDir);
    g_lib->loadAll();   // makes a start-up backup, never overwrites the files

    int port = openListener(preferredPort, 30);
    if (port < 0)
    {
#ifdef _WIN32
        showError("ShelfSense could not open a local port (47821-47850).\n"
                  "Close other copies of ShelfSense and try again.");
#else
        fprintf(stderr, "Could not open a local port.\n");
#endif
        return 1;
    }
    writePortFile(port);

    char url[64];
    snprintf(url, sizeof(url), "http://127.0.0.1:%d/", port);

#ifdef _WIN32
    (void)watch;
    if (!startAcceptThread())
    {
        showError("ShelfSense could not start its server thread.");
        return 1;
    }
    if (!openWindow)
    {
        watchLifetime(NULL);
        shutdownAndExit();
    }
    HANDLE browser = openAppWindow(url);
    if (browser != NULL)
    {
        watchLifetime((void *)browser);
        CloseHandle(browser);
        shutdownAndExit();
    }
    // No Edge/Chrome found: use the default browser and keep running until OK is pressed
    ShellExecuteA(NULL, "open", url, NULL, NULL, SW_SHOWNORMAL);
    string msg = string("ShelfSense is open in your web browser at\n") + url +
                 "\n\nKeep this box open while you use ShelfSense.\n"
                 "Click OK to close ShelfSense.";
    MessageBoxA(NULL, msg.c_str(), "ShelfSense is running", MB_OK | MB_ICONINFORMATION | MB_TOPMOST);
    shutdownAndExit();
    return 0;
#else
    (void)openWindow;
    printf("ShelfSense GUI running at %s\n", url);
    printf("Data folder: %s\n", g_dataDir.c_str());
    fflush(stdout);
    if (watch)
    {
        if (!startAcceptThread())
            return 1;
        watchLifetime(NULL);
        printf("Interface closed, shutting down.\n");
        fflush(stdout);
        shutdownAndExit();
    }
    acceptLoop();
    return 0;
#endif
}
