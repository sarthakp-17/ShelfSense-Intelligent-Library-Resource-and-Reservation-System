SHELFSENSE - Intelligent Library Resource and Reservation System
================================================================

HOW TO RUN
  1. Extract the ZIP (right-click > Extract All). Do not run it from inside the ZIP.
  2. Open the ShelfSense folder and double-click ShelfSense.exe.
  3. To quit, click Exit Application in the sidebar or close the window.
     Every change is saved as soon as you make it.

REQUIREMENTS
  Windows 10 or 11. The window is drawn by Microsoft Edge, which is part of
  Windows (Google Chrome also works). Nothing else to install.
  If neither is found, ShelfSense opens in your default browser and shows a
  small "ShelfSense is running" box - click OK there to quit.

WHAT IS IN THIS FOLDER
  ShelfSense.exe   The application (C++ engine + window launcher)
  assets\          The interface and the app icon
  data\            YOUR LIBRARY - plain text files (books.txt, members.txt,
                   borrow_records.txt, reservations.txt,
                   reservation_history.txt, transactions.txt, settings.txt)
  data\backups\    A copy of all data files made each time ShelfSense starts
                   (the newest 15 are kept)
  sample_data\     A clean copy of the demo library

SETTINGS
  Settings in the sidebar: light/dark theme, fine per late day (default
  Rs. 5, the original console rule), default loan period, the "due soon"
  window, Open data folder, Back up now, and a data check.

RESTORE A BACKUP
  Exit ShelfSense, open data\backups\, choose a dated folder, and copy its
  files into data\ (replace the existing files).

RESET TO THE DEMO LIBRARY
  Exit ShelfSense, then copy every file from sample_data\ into data\.

START WITH AN EMPTY LIBRARY
  Exit ShelfSense and delete the .txt files inside data\.

NOTES
  - Due dates and fines use this computer's date. The demo loans are dated
    around October 2026, so the overdue count depends on today's date.
  - ShelfSense listens only on 127.0.0.1 (this computer). It does not use the
    internet and needs no firewall permission.
  - Do not keep this folder in Program Files or another read-only place:
    ShelfSense must be able to write to data\.
  - Double-clicking ShelfSense.exe while it is open opens another window onto
    the same library.
