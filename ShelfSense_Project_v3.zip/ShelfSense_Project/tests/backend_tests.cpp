// Backend tests for the ShelfSense service layer (no GUI involved).
// Build & run (from the project folder):
//   g++ -std=c++11 -Iinclude tests/backend_tests.cpp src/*.cpp -o backend_tests   (exclude src/main.cpp)
//   ./backend_tests
// The tests work in a temporary folder and never touch data/.

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include "../include/LibraryService.h"
#include "../include/FileStore.h"
#include "../include/SortSearch.h"

using namespace std;

static int passed = 0, failed = 0;

static void check(bool cond, const string &name)
{
    if (cond)
        passed++;
    else
    {
        failed++;
        cout << "  FAIL: " << name << "\n";
    }
}

static string freshDir(const string &name)
{
    string dir = "test_tmp_" + name;
    // remove files from a previous run
    vector<string> files = LibraryService::dataFileNames();
    for (size_t i = 0; i < files.size(); i++)
        FileStore::removeFile(FileStore::joinPath(dir, files[i]));
    FileStore::makeDir(dir);
    return dir;
}

static void seed(LibraryService &L)
{
    L.addBook("B1", "Algorithms", "Sedgewick", "DSA");
    L.addBook("B2", "Clean Code", "Martin", "Programming");
    L.addBook("B10", "Compilers", "Aho", "Systems");
    L.addMember("M1", "Asha", "asha@example.edu", "9000000001");
    L.addMember("M2", "Ravi", "ravi@example.edu", "9000000002");
    L.addMember("M3", "Meena", "", "");
}

int main()
{
    // ---------- catalogue validation ----------
    {
        LibraryService L(freshDir("catalogue"));
        L.loadAll();
        check(L.addBook("B1", "Algorithms", "Sedgewick", "DSA").ok, "add book");
        check(!L.addBook("B1", "Other", "X", "Y").ok, "duplicate book ID rejected");
        check(!L.addBook("B 2", "T", "A", "C").ok, "ID with space rejected");
        check(!L.addBook("B3", "Bad|Title", "A", "C").ok, "pipe in title rejected");
        check(!L.addBook("B4", "", "A", "C").ok, "empty title rejected");
        check(L.updateBook("B1", "Algorithms 4e", "Sedgewick", "DSA").ok, "update book");
        check(L.books.findBook("B1")->getTitle() == "Algorithms 4e", "update stored");
        check(!L.updateBook("NOPE", "T", "A", "C").ok, "update missing book rejected");
        check(L.deleteBook("B1").ok, "delete available book");
        check(L.books.findBook("B1") == nullptr, "book removed from linked list");
        check(!L.addMember("M1", "A", "not-an-email", "").ok, "invalid email rejected");
        check(!L.addMember("M1", "A", "", "12ab").ok, "invalid phone rejected");
    }

    // ---------- issue / return / fines / FIFO ----------
    {
        LibraryService L(freshDir("circulation"));
        L.loadAll();
        seed(L);

        check(L.issueBook("M1", "B1", "01-10-2026", "15-10-2026").ok, "issue B1 to M1");
        check(L.books.findBook("B1")->getStatus() == "Issued", "B1 status Issued");
        check(!L.issueBook("M2", "B1", "01-10-2026", "15-10-2026").ok, "cannot issue unavailable book");
        check(!L.issueBook("M2", "B2", "15-10-2026", "01-10-2026").ok, "due before issue rejected");
        check(!L.issueBook("M2", "B2", "31-02-2026", "05-03-2026").ok, "invalid date rejected");
        check(!L.issueBook("M9", "B2", "01-10-2026", "15-10-2026").ok, "unknown member rejected");

        check(!L.reserveBook("M2", "B2", "02-10-2026").ok, "cannot reserve an available book");
        check(!L.reserveBook("M1", "B1", "02-10-2026").ok, "borrower cannot reserve own book");
        check(L.reserveBook("M2", "B1", "02-10-2026").ok, "M2 reserves B1 (position 1)");
        check(L.reserveBook("M3", "B1", "03-10-2026").ok, "M3 reserves B1 (position 2)");
        check(!L.reserveBook("M2", "B1", "04-10-2026").ok, "duplicate reservation rejected");
        check(L.queue.countForBook("B1") == 2, "queue has 2 entries");

        OpResult p = L.previewReturn("B1", "20-10-2026");
        check(p.ok && p.lateDays == 5 && p.fine == 25.0 && p.nextInQueue == "M2",
              "preview: 5 days late, Rs.25, next M2");
        check(L.books.findBook("B1")->getStatus() == "Issued", "preview changes nothing");

        check(!L.returnBook("B2", "20-10-2026", "").ok, "cannot return a book that is not issued");
        OpResult r = L.returnBook("B1", "20-10-2026", "");
        check(r.ok && r.lateDays == 5 && r.fine == 25.0, "return: fine = 5 days x Rs.5");
        check(r.autoIssuedTo == "M2", "FIFO: first reserver (M2) gets the book");
        BorrowRecord *active = L.borrows.findActiveRecord("B1");
        check(active && active->getMemberId() == "M2", "new active loan belongs to M2");
        check(active && active->getDueDate() == "03-11-2026", "auto-issue due = return + loan period (14)");
        check(L.queue.countForBook("B1") == 1, "queue shrank to 1 (M3 left)");

        check(!L.deleteMember("M2").ok, "member with active loan cannot be deleted");
        check(!L.deleteMember("M3").ok, "member with pending reservation cannot be deleted");
        check(!L.deleteBook("B1").ok, "issued book cannot be deleted");

        check(!L.renewBook("B1", "01-11-2026").ok, "renewal must extend due date");
        check(L.renewBook("B1", "10-11-2026").ok, "renew B1");

        // configurable fine
        check(!L.updateSettings(-1, 14, 3, "light").ok, "negative fine rejected");
        check(L.updateSettings(10, 7, 2, "dark").ok, "update settings");
        OpResult r2 = L.returnBook("B1", "12-11-2026", "");
        check(r2.ok && r2.lateDays == 2 && r2.fine == 20.0, "fine uses configured rate (2 x Rs.10)");
        check(r2.autoIssuedTo == "M3", "FIFO: M3 served next");
        check(L.borrows.findActiveRecord("B1")->getDueDate() == "19-11-2026", "configured loan period (7)");
    }

    // ---------- 'Reserved' status recovery and manual FIFO processing ----------
    {
        LibraryService L(freshDir("reserved"));
        L.loadAll();
        seed(L);
        L.issueBook("M1", "B2", "01-10-2026", "15-10-2026");
        L.reserveBook("M2", "B2", "02-10-2026");
        L.reserveBook("M3", "B2", "03-10-2026");
        // Simulate the console situation that leaves a book "Reserved" with no loan
        L.borrows.returnRecord("B2");
        L.books.findBook("B2")->setStatus("Reserved");

        check(L.reserveBook("M1", "B2", "04-10-2026").ok, "can join the queue of a Reserved book");
        OpResult p = L.processNextReservation("B2", "05-10-2026", "19-10-2026");
        check(p.ok && p.autoIssuedTo == "M2", "process next: FIFO front (M2) gets the book");
        check(L.books.findBook("B2")->getStatus() == "Issued", "status Issued after processing");
        check(!L.processNextReservation("B2", "05-10-2026", "19-10-2026").ok,
              "cannot process while on loan");

        // cancel all reservations of a Reserved book -> Available again
        L.addBook("B5", "Networks", "Tanenbaum", "Systems");
        L.issueBook("M1", "B5", "01-10-2026", "15-10-2026");
        L.reserveBook("M2", "B5", "02-10-2026");
        L.borrows.returnRecord("B5");
        L.books.findBook("B5")->setStatus("Reserved");
        check(L.cancelReservation("M2", "B5").ok, "cancel reservation");
        check(L.books.findBook("B5")->getStatus() == "Available", "Reserved book becomes Available");
    }

    // ---------- persistence, order and integrity ----------
    {
        string dir = freshDir("persist");
        {
            LibraryService L(dir);
            L.loadAll();
            seed(L);
            L.issueBook("M1", "B1", "01-10-2026", "15-10-2026");
            L.reserveBook("M2", "B1", "02-10-2026");
        }
        vector<string> order1, order2;
        {
            LibraryService L(dir);
            L.loadAll();
            check(L.books.countBooks() == 3, "books persisted");
            check(L.members.getAllMembers().size() == 3, "members persisted");
            check(L.borrows.findActiveRecord("B1") != nullptr, "loan persisted");
            check(L.queue.countForBook("B1") == 1, "reservation persisted");
            check(L.transactions.size() >= 8, "transaction stack persisted");
            check(L.loadWarnings.empty(), "no warnings on clean data");
            vector<Member> m = L.members.getAllMembers();
            for (size_t i = 0; i < m.size(); i++) order1.push_back(m[i].getMemberId());
            L.saveAll();
        }
        {
            LibraryService L(dir);
            L.loadAll();
            vector<Member> m = L.members.getAllMembers();
            for (size_t i = 0; i < m.size(); i++) order2.push_back(m[i].getMemberId());
        }
        check(order1 == order2, "member order stable across load/save cycles");
        check(!FileStore::fileExists(FileStore::joinPath(dir, "books.txt.tmp")), "no temp files left");

        // corrupt a line and add an inconsistent status
        {
            ofstream f(FileStore::joinPath(dir, "books.txt").c_str(), ios::app);
            f << "BROKEN LINE WITHOUT SEPARATORS\n";
            f << "B1|Duplicate|X|Y|Available\n";
        }
        {
            LibraryService L(dir);
            L.loadAll();
            check(L.books.countBooks() == 3, "corrupted and duplicate lines skipped");
            bool warned = false;
            for (size_t i = 0; i < L.loadWarnings.size(); i++)
                if (L.loadWarnings[i].find("books.txt: 2 of 5") != string::npos) warned = true;
            check(warned, "skipped lines reported as a warning");
            check(!L.lastBackupDir.empty() &&
                      FileStore::countNonEmptyLines(FileStore::joinPath(L.lastBackupDir, "books.txt")) == 5,
                  "start-up backup keeps the original (corrupted) file");
        }
    }

    // ---------- search & sort ----------
    {
        vector<Book> v;
        v.push_back(Book("B10", "Compilers", "Aho", "Systems", "Available"));
        v.push_back(Book("B2", "Clean Code", "Martin", "Programming", "Issued"));
        v.push_back(Book("B1", "Algorithms", "Sedgewick", "DSA", "Available"));
        int comps = 0;
        vector<Book> r = linearSearchBooks(v, "co", "title", "", comps);
        check(r.size() == 2 && comps == 3, "linear search title 'co' -> 2 hits, 3 comparisons");
        r = linearSearchBooks(v, "", "all", "Available", comps);
        check(r.size() == 2, "status filter Available");
        mergeSortBooks(v, "id", true);
        check(v[0].getBookId() == "B1" && v[1].getBookId() == "B2" && v[2].getBookId() == "B10",
              "merge sort uses natural order (B2 < B10)");
        int idx = binarySearchBookById(v, "B10", comps);
        check(idx == 2, "binary search finds B10");
    }

    cout << passed << " passed, " << failed << " failed\n";
    return failed == 0 ? 0 : 1;
}
