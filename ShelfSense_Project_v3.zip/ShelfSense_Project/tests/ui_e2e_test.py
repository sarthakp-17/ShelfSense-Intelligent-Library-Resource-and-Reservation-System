"""End-to-end test: drives the real ShelfSense interface in Chromium against a
running engine (Linux test build) and checks the engine's state after each step.

Usage:  python3 tests/ui_e2e_test.py <path-to-engine-exe> <chrome-path>
The test copies data/ into a temporary folder and never touches the real data.
"""
import asyncio, os, shutil, subprocess, sys, tempfile, time, urllib.request, json
from playwright.async_api import async_playwright

ENGINE, CHROME = sys.argv[1], sys.argv[2]
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import socket
def free_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0)); return sock.getsockname()[1]
PORT = free_port()   # never reuse a port another (possibly stale) engine holds
BASE = f"http://127.0.0.1:{PORT}/"
results = []

def check(cond, name):
    results.append((bool(cond), name))
    print(("  PASS " if cond else "  FAIL ") + name)

def start_engine(folder):
    p = subprocess.Popen([os.path.join(folder, "shelfsense"), "--port", str(PORT)],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    engines.append(p)
    for _ in range(50):
        try:
            urllib.request.urlopen(BASE, timeout=1); return p
        except Exception: time.sleep(0.1)
    raise RuntimeError("engine did not start")

async def state(pg):
    return await pg.evaluate("fetch('/api/state',{headers:{'X-ShelfSense-Token':TOKEN}}).then(r=>r.json())")

async def confirm(pg, selector=".dialog-foot .btn.primary, .dialog-foot .btn.danger"):
    await pg.wait_for_selector(".scrim .dialog"); await pg.click(selector); await pg.wait_for_timeout(350)

async def pick(pg, container, text):
    await pg.fill(f"{container} input", text); await pg.wait_for_timeout(120)
    await pg.press(f"{container} input", "Enter"); await pg.wait_for_timeout(150)

engines = []

async def main():
    folder = tempfile.mkdtemp(prefix="shelfsense_e2e_")
    shutil.copy(ENGINE, os.path.join(folder, "shelfsense"))
    shutil.copytree(os.path.join(ROOT, "assets"), os.path.join(folder, "assets"))
    shutil.copytree(os.path.join(ROOT, "data"), os.path.join(folder, "data"))
    engine = start_engine(folder)
    errors = []
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=CHROME, args=["--no-sandbox"])
        ctx = await b.new_context(viewport={"width": 1440, "height": 900}, accept_downloads=True)
        pg = await ctx.new_page()
        pg.on("pageerror", lambda e: errors.append(str(e)))
        # the deliberate no-token request near the end logs a 403; every other console error counts
        pg.on("console", lambda m: errors.append("console: " + m.text) if m.type == "error" and "status of 403" not in m.text else None)
        # async click handlers fail as unhandled rejections, which "pageerror" does not report
        await pg.add_init_script("window.addEventListener('unhandledrejection', e => console.error('Unhandled: ' + (e.reason && e.reason.stack || e.reason)))")
        await pg.goto(BASE); await pg.wait_for_selector(".desk")

        s = await state(pg)
        desk = await pg.inner_text(".desk")
        check(str(s["stats"]["totalBooks"]) in desk and str(s["stats"]["overdue"]) in desk, "dashboard numbers come from engine state")

        print("Book management")
        await pg.click('[data-q="addBook"]')
        await pg.fill("#f_id", "B101"); await pg.fill("#f_category", "Testing"); await pg.fill("#f_title", "Dup"); await pg.fill("#f_author", "X")
        await pg.click(".dialog-foot .btn.primary"); await pg.wait_for_timeout(200)
        check("already exists" in await pg.inner_text('[data-err="id"]'), "duplicate book ID shows inline error")
        await pg.fill("#f_id", "B900"); await pg.fill("#f_title", "Bad | title")
        await pg.click(".dialog-foot .btn.primary"); await pg.wait_for_timeout(200)
        check("not allowed" in await pg.inner_text('[data-err="title"]'), "pipe character rejected")
        await pg.fill("#f_title", "Software Testing Basics"); await pg.fill("#f_author", "R. Patton")
        await pg.click(".dialog-foot .btn.primary"); await pg.wait_for_timeout(500)
        s = await state(pg)
        check(any(x["id"] == "B900" for x in s["books"]), "book B900 added through the dialog")
        await pg.goto(BASE + "#/books"); await pg.wait_for_selector("#btable table")
        await pg.fill("#bq", "testing basics"); await pg.wait_for_timeout(450)
        rows = await pg.locator("#btable tbody tr").count()
        check(rows == 1, "book search finds the new book (linear search in C++)")
        await pg.click('[data-edit="B900"]'); await pg.fill("#f_title", "Software Testing Basics, 2nd ed.")
        await pg.click(".dialog-foot .btn.primary"); await pg.wait_for_timeout(500)
        s = await state(pg)
        check(next(x for x in s["books"] if x["id"] == "B900")["title"].endswith("2nd ed."), "book edited")
        await pg.fill("#bq", ""); await pg.wait_for_timeout(300)
        await pg.click('#bstatus button[data-s="Issued"]'); await pg.wait_for_timeout(400)
        statuses = await pg.locator("#btable tbody .pill.blue").count()
        check(statuses == s["stats"]["issued"], "availability filter shows only issued books")
        await pg.click('#bstatus button[data-s=""]'); await pg.wait_for_timeout(300)
        check(await pg.locator('[data-del="B101"]').is_disabled(), "delete disabled for an issued book")

        print("Member management")
        await pg.goto(BASE + "#/members"); await pg.wait_for_selector("#mtable")
        await pg.click("#addMember")
        await pg.fill("#f_id", "M900"); await pg.fill("#f_name", "Test Student"); await pg.fill("#f_email", "bad-email")
        await pg.click(".dialog-foot .btn.primary"); await pg.wait_for_timeout(200)
        check("valid email" in await pg.inner_text('[data-err="email"]'), "invalid email rejected")
        await pg.fill("#f_email", "")   # empty email and phone: exercises the load fix
        await pg.click(".dialog-foot .btn.primary"); await pg.wait_for_timeout(500)
        s = await state(pg)
        check(any(m["id"] == "M900" for m in s["members"]), "member M900 registered with empty email/phone")

        print("Issue")
        await pg.goto(BASE + "#/circulation?tab=issue"); await pg.wait_for_selector("#pkMember")
        await pick(pg, "#pkMember", "M900"); await pick(pg, "#pkBook", "B101")
        check(await pg.locator("#doIssue").is_disabled(), "issue button disabled for an unavailable book")
        check("Reserve it instead" in await pg.inner_text("#issueChecks"), "unavailable book offers reservation")
        await pg.click("#pkBook .chosen button")
        await pick(pg, "#pkBook", "B900")
        await pg.fill("#issueDate", "2026-10-01"); await pg.dispatch_event("#issueDate", "change")
        check(await pg.input_value("#dueDate") == "2026-10-15", "due date pre-filled from loan period (14 days)")
        await pg.click("#doIssue"); await confirm(pg)
        s = await state(pg)
        rec = [r for r in s["records"] if r["bookId"] == "B900" and r["status"] == "Issued"]
        check(rec and rec[0]["memberId"] == "M900" and rec[0]["dueDate"] == "15-10-2026", "B900 issued to M900, due 15-10-2026")
        check(next(x for x in s["books"] if x["id"] == "B900")["status"] == "Issued", "book status updated to Issued")

        print("Reservations (FIFO)")
        await pg.goto(BASE + "#/reservations?book=B900"); await pg.wait_for_selector("#rMember")
        await pick(pg, "#rMember", "M101"); await pg.click("#doReserve"); await pg.wait_for_timeout(500)
        await pg.goto(BASE + "#/reservations?book=B900"); await pg.wait_for_selector("#rMember")
        await pick(pg, "#rMember", "M102"); await pg.click("#doReserve"); await pg.wait_for_timeout(500)
        await pg.goto(BASE + "#/reservations?book=B900"); await pg.wait_for_selector("#rMember")
        await pick(pg, "#rMember", "M101")
        check(await pg.locator("#doReserve").is_disabled(), "duplicate reservation blocked in the form")
        r = await pg.evaluate("api('/api/reserve',{memberId:'M101',bookId:'B900',date:'18-10-2026'})")
        check(not r["ok"] and "already in the queue" in r["message"], "duplicate reservation rejected by the engine")
        s = await state(pg)
        q = [x for x in s["queue"] if x["bookId"] == "B900"]
        check([x["memberId"] for x in q] == ["M101", "M102"] and [x["position"] for x in q] == [1, 2], "queue order M101 (#1), M102 (#2)")
        r = await pg.evaluate("api('/api/reserve',{memberId:'M101',bookId:'B103',date:'18-10-2026'})")
        check(not r["ok"], "cannot reserve an available book")

        print("Return with fine and automatic FIFO issue")
        await pg.goto(BASE + "#/circulation?tab=return&book=B900"); await pg.wait_for_selector("#retSummary dl")
        await pg.fill("#retDate", "2026-10-20"); await pg.dispatch_event("#retDate", "change"); await pg.wait_for_timeout(400)
        summary = await pg.inner_text("#retSummary")
        check("5 days" in summary and "Rs. 25.00" in summary, "return preview: 5 days late, Rs. 25.00 fine")
        check("M101" in await pg.inner_text("#nextBox"), "preview names M101 as next in queue")
        await pg.click("#doReturn"); await confirm(pg)
        s = await state(pg)
        old = [r for r in s["records"] if r["bookId"] == "B900" and r["memberId"] == "M900"][0]
        new = [r for r in s["records"] if r["bookId"] == "B900" and r["status"] == "Issued"]
        check(old["status"] == "Returned" and abs(old["fine"] - 25.0) < 0.01, "fine Rs. 25 stored on the returned record")
        check(new and new[0]["memberId"] == "M101", "book automatically issued to M101 (first in queue)")
        check([x["memberId"] for x in s["queue"] if x["bookId"] == "B900"] == ["M102"], "M102 moved up to #1")
        r = await pg.evaluate("api('/api/return',{bookId:'B103',returnDate:'18-10-2026'})")
        check(not r["ok"] and "not currently issued" in r["message"], "cannot return a book that is not issued")

        print("Cancel reservation, deletes")
        await pg.goto(BASE + "#/reservations"); await pg.wait_for_selector("#queues")
        await pg.click('[data-cancel="M102|B900"]'); await confirm(pg)
        s = await state(pg)
        check(not any(x["bookId"] == "B900" for x in s["queue"]), "reservation cancelled")
        check(any(h["memberId"] == "M102" and h["bookId"] == "B900" and h["status"] == "Cancelled" for h in s["history"]), "history marks it Cancelled")
        r = await pg.evaluate("api('/api/members/delete',{id:'M101'})")
        check(not r["ok"], "member with an active loan cannot be deleted")
        await pg.goto(BASE + "#/members"); await pg.wait_for_selector("#mtable table")
        await pg.click('[data-del="M900"]'); await confirm(pg)
        s = await state(pg)
        check(not any(m["id"] == "M900" for m in s["members"]), "member without loans deleted after confirmation")

        print("Search, due dates, history, reports")
        await pg.goto(BASE + "#/search"); await pg.wait_for_selector("#searchInput")
        await pg.fill("#searchInput", "B110"); await pg.wait_for_timeout(400)
        check("binary search" in await pg.inner_text("#salgo"), "exact ID located by binary search")
        check("Computer Networks" in await pg.inner_text("#sdetail"), "detail panel shows the selected book")
        await pg.goto(BASE + "#/due?tab=overdue"); await pg.wait_for_selector("#dtable")
        s = await state(pg)
        check(await pg.locator("#dtable tbody tr").count() == s["stats"]["overdue"], "overdue tab lists every overdue loan")
        await pg.goto(BASE + "#/transactions"); await pg.wait_for_selector("#txTable")
        await pg.select_option("#txType", "RETURN"); await pg.wait_for_timeout(300)
        types = await pg.locator("#txTable tbody .pill").all_inner_texts()
        check(types and all(t == "Return" for t in types), "transaction type filter")
        await pg.fill("#txBook", "B900"); await pg.wait_for_timeout(300)
        check(await pg.locator("#txTable tbody tr").count() == 1, "transaction book filter")
        async with pg.expect_download() as dl:
            await pg.click("#txExport")
        path = await (await dl.value).path()
        check(open(path, encoding="utf-8-sig").read().startswith("No.,Date and time"), "CSV export downloads")
        await pg.goto(BASE + "#/reports"); await pg.wait_for_selector(".bars")
        check("Introduction to Algorithms" in await pg.inner_text(".bars"), "most-issued report computed")

        print("Settings, security, exit")
        await pg.goto(BASE + "#/settings"); await pg.wait_for_selector("#sFine")
        await pg.fill("#sFine", "-3"); await pg.click("#sSave"); await pg.wait_for_timeout(400)
        s = await state(pg)
        check(s["settings"]["finePerDay"] == 5, "invalid fine rejected")
        await pg.fill("#sFine", "10"); await pg.click("#sSave"); await pg.wait_for_timeout(400)
        await pg.click('#themeSeg button[data-k="dark"]'); await pg.wait_for_timeout(400)
        check(await pg.evaluate("document.documentElement.dataset.theme") == "dark", "theme switched to dark")
        status = await pg.evaluate("fetch('/api/books/delete',{method:'POST',body:'id=B103'}).then(r=>r.status)")
        check(status == 403, "request without the session token is refused (403)")
        s = await state(pg)
        check(any(x["id"] == "B103" for x in s["books"]), "refused request changed nothing")
        await pg.click("#exitBtn"); await confirm(pg); await pg.wait_for_timeout(1200)
        check(await pg.locator(".closed-screen").count() == 1, "exit shows the closed screen")
        await b.close()

    check(engine.wait(timeout=5) == 0, "engine process exited after Exit Application")

    print("Persistence after restart")
    engine = start_engine(folder)
    with urllib.request.urlopen(BASE) as r:
        html = r.read().decode()
    token = html.split('name="shelfsense-token" content="')[1].split('"')[0]
    req = urllib.request.Request(BASE + "api/state", headers={"X-ShelfSense-Token": token})
    s = json.loads(urllib.request.urlopen(req).read())
    check(any(x["id"] == "B900" and x["status"] == "Issued" for x in s["books"]), "B900 still issued after restart")
    check(not any(m["id"] == "M900" for m in s["members"]), "deleted member stays deleted")
    check(s["settings"]["finePerDay"] == 10 and s["settings"]["theme"] == "dark", "settings persisted")
    check(not s["warnings"], "no data problems after the session")
    backups = os.listdir(os.path.join(folder, "data", "backups"))
    check(len(backups) >= 2, "a start-up backup was made for each session")
    check(not any(f.endswith(".tmp") for f in os.listdir(os.path.join(folder, "data"))), "no temporary files left behind")
    engine.terminate(); engine.wait()
    check(not errors, "no JavaScript errors" + (": " + "; ".join(errors) if errors else ""))
    shutil.rmtree(folder)

try:
    asyncio.run(main())
finally:
    for e in engines:          # never leave an engine running, even if a step crashes
        if e.poll() is None: e.terminate(); e.wait()
failed = [n for ok, n in results if not ok]
print(f"\n{len(results) - len(failed)} passed, {len(failed)} failed")
sys.exit(1 if failed else 0)
