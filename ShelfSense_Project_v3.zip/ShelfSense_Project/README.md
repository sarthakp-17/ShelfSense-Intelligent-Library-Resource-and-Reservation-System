# ShelfSense: Intelligent Library Resource and Reservation System

A Windows desktop GUI for the ShelfSense C++ library system. The interface is new;
the rules, data structures and data files are your existing C++ backend (linked lists,
FIFO reservation queue, reservation history, transaction stack, due-date min-heap,
merge sort, binary search), extended where the GUI needed it.

## Build status (read first)

| What | Status |
|---|---|
| Backend rules (`tests/backend_tests.cpp`) | **63/63 pass** (compiled and run with g++ 13 on Linux) |
| Full interface, end to end (`tests/ui_e2e_test.py`) | **49/49 checks pass**, 8 consecutive runs, in Chromium against the real engine (Linux build) |
| Windows-only code (Explorer launch, atomic file replace, threads, Winsock) | Type-checked against Win32 declarations; **not compiled or run on Windows** |
| `ShelfSense.exe` | **Not included.** Build it once with `BUILD_WINDOWS.bat` (below) |

The package was prepared without a Windows compiler, so the first Windows build is the
one remaining step that has not been tested. If it fails, send the compiler output.

## Run it on Windows

1. Extract this ZIP to a normal folder (not inside the ZIP, not a read-only location).
2. Double-click **`BUILD_WINDOWS.bat`**.
   If it says *No C++ compiler was found*: download the x64 `w64devkit-x64-….exe` from
   <https://github.com/skeeto/w64devkit/releases>, run it, extract it **into this folder**
   (so `w64devkit\bin\g++.exe` exists), and run `BUILD_WINDOWS.bat` again.
   MSYS2 / MinGW-w64 / Code::Blocks-MinGW also work if `g++` is installed.
3. The script runs the backend tests, compiles, and creates:
   - `ShelfSense\` — the app folder: `ShelfSense.exe`, `assets\`, `data\`, `sample_data\`, `README.txt`
   - `ShelfSense_Portable.zip` — the same folder, zipped, to copy to another PC
4. From then on, double-click **`ShelfSense\ShelfSense.exe`**. No command prompt is needed.
   Close the window or use **Exit Application** in the sidebar to quit; data is saved after every change.

Rebuilding is safe: `ShelfSense\data` (your live library) is created on the first build only
and is never overwritten. (The previous script deleted the whole output folder on every build.)

The exe is statically linked, so it needs only DLLs that ship with Windows. The window is
drawn by Microsoft Edge (part of Windows 10/11) in "app" mode; Google Chrome also works.

## How it fits together

```
ShelfSense.exe  (one process, C++)
 ├─ LibraryService ── your classes: BookLinkedList, MemberLinkedList,
 │                    BorrowRecordLinkedList, ReservationQueue, ReservationHistory,
 │                    TransactionStack, DueDateHeap, SortSearch, LibrarySettings
 ├─ JSON API on 127.0.0.1 only; every call must carry a per-session token
 └─ opens Edge/Chrome with --app: its own window, no address bar; exits when closed
assets/index.html ── the interface (HTML/CSS/JS, works offline, no CDN)
data/*.txt        ── the same pipe-separated files the console version uses
```

Every button calls the C++ engine. The engine validates, updates the data structures,
saves the files and replies; the page then reloads the state and redraws. The page holds
no data and computes no statistics of its own.

**Why not PySide6 or Qt?** The backend is C++. PySide6 would mean rewriting the rules in
Python or building a C binding; Qt adds about 50 MB of runtime DLLs and `windeployqt`.
This design reuses the classes directly and ships as one static exe. The trade-off: the
window is rendered by Edge, so Edge (or Chrome) must be installed.

## Pages

| Page | What it does | Backend used |
|---|---|---|
| Dashboard | Six live totals, quick search, quick actions, overdue notifications, upcoming due dates, recent issues/returns/additions | stats from all structures, min-heap order, transaction stack |
| Book Management | Add, edit, delete (with confirmation), search by ID/title/author, availability filter, sort | `LibraryService`, linear search, merge sort, binary search |
| Member Management | Register, edit, delete, profile with current loans, overdue books, reservations, history | `MemberLinkedList`, borrow records, queue |
| Issue & Return | Issue with availability checks; return with overdue days, fine and automatic hand-off to the next reserver; renew | `issueBook` / `returnBook` / `renewBook` rules, `calculateLateDays()` |
| Reservations | Reserve, per-book FIFO queues with positions, cancel, issue to #1, history | `ReservationQueue`, `ReservationHistory` |
| Search & Explore | Search with field and status filters, sorting, detail panel | linear search, merge sort, binary search |
| Due Dates & Fines | Overdue, due soon, all loans, fines recorded; CSV export | min-heap, borrow records |
| Transaction History | Filter by text, type, member, book and date range; CSV export | `TransactionStack` |
| Reports | Totals, most-issued books (needs at least 5 loans), categories, issued and overdue lists, member activity, reservation outcomes; print and CSV | all structures |
| Settings | Theme (light/dark/match Windows), fine per day, default loan period, due-soon window, data folder, backups, data check | `LibrarySettings`, `FileStore` |

## Data storage

Files in `data\` keep the console version's format:

| File | Format |
|---|---|
| `books.txt` | `id|title|author|category|status` |
| `members.txt` | `id|name|email|phone` |
| `borrow_records.txt` | `memberId|bookId|issueDate|dueDate|status|fine` |
| `reservations.txt` | `memberId|bookId|date` (FIFO order) |
| `reservation_history.txt` | `memberId|bookId|date|status` |
| `transactions.txt` | `id|type|memberId|bookId|timestamp|details` (stack, bottom to top) |
| `settings.txt` | `key=value` (new) |

Safety measures:

- **Start-up backup.** Before loading, every data file is copied to `data\backups\YYYYMMDD-HHMMSS\`. The newest 15 are kept.
- **Atomic saves.** Each list is written to `file.tmp`, its line count is checked, then it replaces the old file in one step (`MoveFileExA`). An interrupted save leaves the previous file intact.
- **No silent loss.** Lines that cannot be read are counted and reported on the dashboard and in Settings, with the backup location. Cross-file problems (e.g. a book marked Issued with no loan) are reported, never auto-"fixed".
- **Save failures are visible.** If a file cannot be written (e.g. read-only folder), the action shows a warning instead of claiming success.
- Startup never writes to the data files; missing files mean an empty library.

## Fine policy

Rs. 5 per late day: the rule from the original `returnBook()` (`lateDays * 5.0`).
It is now configurable in Settings. A new rate applies to future returns; recorded fines
do not change. For books still on loan, the fine shown is an estimate (if returned today).

The default loan period (14 days) was **not** defined by the console version, which asks for
a due date each time. It only pre-fills the due date and can be changed per loan or in Settings.

## Changes to your existing backend

All original files are kept, and the console program still builds and runs.

**Bug fixes in your original code:**

- `MemberLinkedList::loadFromFile`: a member with an empty phone (`M3|Meena||`) was **silently dropped on load**, because `getline` fails on an empty final field. Now a line needs exactly three `|` separators and the phone may be empty.
- `MemberLinkedList::loadFromFile`: inserted each line at the head, so member order **reversed on every load/save cycle** (the sample `members.txt` is stored M112→M101 because of this). Now appends at the tail; `addMember()` is unchanged.
- `ReservationQueue::saveToFile`: returned `void`, so a failed save was invisible. Now returns `bool`.
- `BorrowRecord` 5-argument constructor: `fine` was uninitialised (fixed earlier, kept).

**Fixes to the service layer:**

- A book could be left "Reserved" forever: its last reservation cancelled, or the reserved member missing. Cancelling now returns it to Available, members can join a Reserved book's queue, and **Issue to #1** (`processNextReservation`) serves the queue in FIFO order.

**Additions:**

- `FileStore`: atomic replace, backups, line counting.
- `LibrarySettings`: fine rate, loan period, due-soon window, theme.
- `LibraryService`:
  - `previewReturn`: read-only, and uses your `calculateLateDays()`.
  - `processNextReservation`, `updateSettings` and `createBackup`.
  - Load warnings and integrity checks.
  - Save-failure reporting.
- `SortSearch`: `linearSearchBooks`, `linearSearchMembers` (case-insensitive substring), used with your merge sort and binary search.
- GUI host:
  - Per-session token, which blocks other web pages from driving the local API.
  - Endpoints for search, return preview, queue processing, settings, backups, opening the data folder, and Exit.

## Tests

Backend (any g++; `BUILD_WINDOWS.bat` runs these automatically):

```bat
g++ -std=gnu++11 -Iinclude tests\backend_tests.cpp src\Book.cpp src\BookNode.cpp src\BookLinkedList.cpp src\BorrowRecord.cpp src\BorrowRecordNode.cpp src\BorrowRecordLinkedList.cpp src\DueDateHeap.cpp src\FileStore.cpp src\LibraryManager.cpp src\LibraryService.cpp src\LibrarySettings.cpp src\Member.cpp src\MemberNode.cpp src\MemberLinkedList.cpp src\Reservation.cpp src\ReservationNode.cpp src\ReservationQueue.cpp src\ReservationHistory.cpp src\SortSearch.cpp src\Transaction.cpp src\TransactionStack.cpp -o backend_tests.exe
backend_tests.exe
```

On Linux/macOS: `g++ -std=gnu++11 -Iinclude tests/backend_tests.cpp $(ls src/*.cpp | grep -v main.cpp) -o backend_tests && ./backend_tests`

End-to-end interface test (Linux, needs Python with Playwright and a Chromium binary):

```sh
g++ -std=gnu++11 -O1 -Iinclude $(ls src/*.cpp | grep -v main.cpp) gui/ShelfSenseGUI.cpp -o shelfsense -lpthread
python3 tests/ui_e2e_test.py ./shelfsense /path/to/chrome
```

Both tests work on copies in temporary folders and never touch `data/`.

## Editing the interface

The interface source is in `ui/` (`styles.css`, `core.js`, `shell.js`, `pages-*.js`,
`index.template.html`). After editing, run `python tools/build_ui.py` to regenerate
`assets/index.html` and `gui/embedded_index.h`, then rebuild the exe.
`assets/index.html` next to the exe is used when present; otherwise the copy compiled into the exe.

## Console version

Still builds and runs unchanged:
`g++ -std=c++11 -Iinclude src\*.cpp -o ShelfSenseConsole.exe`

Note: it reads and writes `books.txt` etc. in the **current folder**, not `data\`. It also
does not record transactions, so console changes do not appear in Transaction History.
To use both on the same library, run the console program from inside `ShelfSense\data`.

## Project layout

```
include/, src/        backend (original classes + FileStore, LibrarySettings, service layer)
src/main.cpp          console program (not part of the GUI build)
gui/ShelfSenseGUI.cpp GUI host: local API, window launcher, lifetime handling
gui/embedded_index.h  generated copy of the interface built into the exe
ui/                   interface source (edit here)
assets/               built interface (index.html) and icon
data/                 sample library (24 books, 12 members, 27 loans, 4 reservations)
tests/                backend_tests.cpp, ui_e2e_test.py
tools/build_ui.py     builds assets/index.html and gui/embedded_index.h from ui/
docs/                 Phase 1 proposal
BUILD_WINDOWS.bat     tests + build + portable ZIP
README_APP.txt        user guide copied into the app folder
```

## Troubleshooting

| Problem | Fix |
|---|---|
| *No C++ compiler was found* | Install w64devkit as in step 2. |
| `undefined reference to WinMain` or other link errors | The MinGW is very old. Use w64devkit. |
| *Backend tests FAILED* | Open `build\backend_tests.log`; the `FAIL:` lines name the broken rule. |
| *ShelfSense is running* during a build | Use Exit Application in the app, or end ShelfSense.exe in Task Manager. |
| SmartScreen: "Windows protected your PC" | The exe is unsigned. Click *More info* → *Run anyway*. |
| *could not find its 'assets' folder* | You ran the exe from inside the ZIP. Extract first. |
| Opens in a normal browser tab with a "ShelfSense is running" box | Edge/Chrome was not found. It works; click OK in that box to quit. |
| *could not open a local port (47821-47850)* | Another program uses those ports, or many copies are running. Restart and try again. |
| Changes show a "could not be saved" warning | The folder is read-only (e.g. Program Files or a locked ZIP). Move the app folder to Documents or Desktop. |
| A data problem banner after start | See Settings → Data check. Originals are in `data\backups\`. |
| Dates show as MM/DD/YYYY | Date fields follow the Windows region format (Settings → Time & language → Region). Stored dates stay DD-MM-YYYY. |
| Antivirus quarantines the exe | Add an exception for the project folder; small unsigned MinGW programs are sometimes flagged. |
| Reset to the demo library | Exit ShelfSense, copy `sample_data\*.txt` into `data\`. Delete the `.txt` files for an empty library. |

## Known limitations

- Single user on one PC, as in the Phase 1 assumptions. No login.
- No undo. The proposal describes the stack as "undoable"; the history is recorded but undoing a transaction is not implemented.
- `borrow_records.txt` has no return-date field (kept for console compatibility). Return dates appear in Transaction History.
- The demo data's transaction timestamps were back-dated out of order, so Transaction History (stack order) does not show strictly falling dates for the sample entries. New entries are in order.
- Linear search remains inside the linked lists (e.g. `findBook`); binary search runs on a sorted copy.
- Overdue counts use the PC's date; the demo loans are dated around October 2026.
