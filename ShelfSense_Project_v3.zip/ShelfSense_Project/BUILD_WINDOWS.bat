@echo off
setlocal EnableExtensions EnableDelayedExpansion
title ShelfSense - Windows build
cd /d "%~dp0"

echo.
echo  ==========================================================
echo     ShelfSense - building the Windows application
echo  ==========================================================
echo.

rem ---------- 1. Find a g++ compiler (w64devkit / MinGW-w64 / MSYS2) ----------
if exist "%~dp0w64devkit\bin\g++.exe" set "PATH=%~dp0w64devkit\bin;!PATH!"
if exist "%~dp0w64devkit\w64devkit\bin\g++.exe" set "PATH=%~dp0w64devkit\w64devkit\bin;!PATH!"
for %%D in ("C:\w64devkit\bin" "C:\msys64\ucrt64\bin" "C:\msys64\mingw64\bin" "C:\mingw64\bin" "C:\MinGW\bin" "C:\TDM-GCC-64\bin" "C:\Program Files\CodeBlocks\MinGW\bin" "C:\Program Files (x86)\CodeBlocks\MinGW\bin") do (
    if exist "%%~D\g++.exe" set "PATH=!PATH!;%%~D"
)
where g++ >nul 2>nul
if errorlevel 1 goto :nocompiler

set "GXX="
for /f "delims=" %%G in ('where g++') do if not defined GXX set "GXX=%%G"
for %%P in ("!GXX!") do set "GXXDIR=%%~dpP"
set "GVER="
for /f "delims=" %%V in ('g++ --version') do if not defined GVER set "GVER=%%V"
echo  Compiler : !GXX!
echo  Version  : !GVER!
echo.

set "OUT=ShelfSense"
if exist "%OUT%\ShelfSense.exe" (
    tasklist /fi "imagename eq ShelfSense.exe" 2>nul | find /i "ShelfSense.exe" >nul
    if not errorlevel 1 (
        echo  ShelfSense is running. Use Exit Application in its sidebar, then run this script again.
        goto :fail
    )
)
if not exist build mkdir build
if not exist "%OUT%" mkdir "%OUT%"

rem Backend sources: every src\*.cpp except the console program's main.cpp
set "SRCS="
for %%F in (src\*.cpp) do if /I not "%%~nxF"=="main.cpp" set "SRCS=!SRCS! %%F"
set "STATIC=-static -static-libgcc -static-libstdc++"

rem ---------- 2. Backend tests (stop if any rule is broken) ----------
echo  [1/5] Building and running the backend tests ...
g++ -std=gnu++11 -O1 -Iinclude tests\backend_tests.cpp !SRCS! -o build\backend_tests.exe %STATIC%
if errorlevel 1 goto :buildfailed
pushd build
for /d %%T in (test_tmp_*) do rmdir /s /q "%%T"
backend_tests.exe > backend_tests.log 2>&1
set "TESTRESULT=!errorlevel!"
for /d %%T in (test_tmp_*) do rmdir /s /q "%%T"
popd
for /f "delims=" %%L in ('findstr /c:"passed," build\backend_tests.log') do echo         %%L
if not "!TESTRESULT!"=="0" (
    echo  Backend tests FAILED - see build\backend_tests.log. The exe was not rebuilt.
    goto :fail
)

rem ---------- 3. Application icon (optional) ----------
set "RES="
where windres >nul 2>nul
if not errorlevel 1 (
    windres ShelfSense.rc -O coff -o build\ShelfSense.res >nul 2>nul
    if not errorlevel 1 set "RES=build\ShelfSense.res"
)
if defined RES (echo  [2/5] Icon resource compiled) else (echo  [2/5] windres not found - building without a custom icon)

rem ---------- 4. Compile the application ----------
echo  [3/5] Compiling ShelfSense.exe ^(about a minute^) ...
if exist "%OUT%\ShelfSense.exe" del /q "%OUT%\ShelfSense.exe"
g++ -std=gnu++11 -O2 -Iinclude !SRCS! gui\ShelfSenseGUI.cpp !RES! -o "%OUT%\ShelfSense.exe" %STATIC% -mwindows -lws2_32 -lshell32 -luser32 -ladvapi32
if errorlevel 1 goto :buildfailed
if not exist "%OUT%\ShelfSense.exe" goto :buildfailed

rem ---------- 5. Assets, data, README ----------
rem The interface and sample data are refreshed on every build.
rem ShelfSense\data (your live library) is created only on the FIRST build and
rem is never overwritten afterwards.
echo  [4/5] Copying the interface and README
if exist "%OUT%\assets" rmdir /s /q "%OUT%\assets"
xcopy /e /i /y /q assets "%OUT%\assets" >nul
if exist "%OUT%\sample_data" rmdir /s /q "%OUT%\sample_data"
mkdir "%OUT%\sample_data"
copy /y data\*.txt "%OUT%\sample_data\" >nul
if exist "%OUT%\data\" (
    echo         Kept your existing library in %OUT%\data
) else (
    mkdir "%OUT%\data"
    copy /y data\*.txt "%OUT%\data\" >nul
    echo         Created %OUT%\data from the sample library
)
if exist "%OUT%\data\.instance_port" del /q "%OUT%\data\.instance_port"
copy /y README_APP.txt "%OUT%\README.txt" >nul

rem Only Windows system DLLs should be listed
where objdump >nul 2>nul
if not errorlevel 1 (
    echo.
    echo  DLLs required by ShelfSense.exe:
    objdump -p "%OUT%\ShelfSense.exe" | findstr /i /c:"DLL Name"
    objdump -p "%OUT%\ShelfSense.exe" | findstr /i /l "libstdc++ libgcc_s libwinpthread" >nul
    if not errorlevel 1 (
        echo  Non-system runtime DLLs detected - copying them next to the exe.
        for %%L in (libstdc++-6.dll libgcc_s_seh-1.dll libgcc_s_dw2-1.dll libwinpthread-1.dll) do (
            if exist "!GXXDIR!%%L" copy /y "!GXXDIR!%%L" "%OUT%\" >nul
        )
    )
    echo.
)

rem ---------- 6. Portable ZIP ----------
echo  [5/5] Creating ShelfSense_Portable.zip (includes the current data folder)
if exist ShelfSense_Portable.zip del /q ShelfSense_Portable.zip
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'ShelfSense' -DestinationPath 'ShelfSense_Portable.zip' -Force"
if errorlevel 1 echo  Could not create the ZIP automatically. The folder "%OUT%" is ready to use as it is.

echo.
echo  ==========================================================
echo   DONE.
echo   App folder : %~dp0%OUT%
echo   Portable   : %~dp0ShelfSense_Portable.zip
echo   From now on just double-click  %OUT%\ShelfSense.exe
echo  ==========================================================
echo.
choice /c YN /m "  Open ShelfSense now"
if errorlevel 2 goto :end
start "" "%OUT%\ShelfSense.exe"
goto :end

:nocompiler
echo  No C++ compiler (g++) was found on this computer.
echo.
echo  One-time setup (about 5 minutes, no installer, no admin rights):
echo    1. Open  https://github.com/skeeto/w64devkit/releases
echo    2. Download the x64 file, e.g. w64devkit-x64-2.x.x.exe
echo    3. Run it and extract into THIS folder:
echo         %~dp0
echo       so that this file exists:
echo         %~dp0w64devkit\bin\g++.exe
echo    4. Double-click BUILD_WINDOWS.bat again.
echo.
echo  (MinGW-w64, MSYS2 or Code::Blocks-with-MinGW also work if g++ is installed.)
goto :fail

:buildfailed
echo.
echo  BUILD FAILED. The compiler messages above show the reason.
echo  See "Troubleshooting" in README.md.
goto :fail

:fail
echo.
pause
exit /b 1

:end
endlocal
exit /b 0
