#ifndef BOOKNODE_H
#define BOOKNODE_H

#include "Book.h"

class BookNode
{
public:
    Book book;
    BookNode* next;
    BookNode* prev;   // doubly linked: O(1) unlink when deleting

    BookNode(Book newBook);
};

#endif