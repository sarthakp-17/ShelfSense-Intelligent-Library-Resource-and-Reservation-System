#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <string>
#include <cstddef>

// Generic hash table (separate chaining) that maps a string key
// to a pointer of type V.
//
//  - Hash function : djb2 (string -> unsigned long)
//  - Collisions    : handled by chaining (each bucket is a small linked chain)
//  - Resizing      : table grows when load factor > 0.75 so chains stay short
//
// Average time complexity: insert / find / remove = O(1)
// Worst case (all keys collide)                   = O(n)
//
// The table does NOT own the values; it only stores pointers to them.
template <typename V>
class HashTable
{
private:
    struct Entry
    {
        std::string key;
        V *value;
        Entry *next;

        Entry(const std::string &k, V *v) : key(k), value(v), next(nullptr) {}
    };

    Entry **buckets;
    std::size_t capacity;
    std::size_t count;

    static const std::size_t INITIAL_CAPACITY = 101; // prime number

    static std::size_t hashKey(const std::string &key, std::size_t cap)
    {
        unsigned long h = 5381; // djb2
        for (std::size_t i = 0; i < key.size(); i++)
        {
            h = ((h << 5) + h) + static_cast<unsigned char>(key[i]);
        }
        return static_cast<std::size_t>(h % cap);
    }

    void rehash()
    {
        std::size_t newCapacity = capacity * 2 + 1;
        Entry **newBuckets = new Entry *[newCapacity];
        for (std::size_t i = 0; i < newCapacity; i++)
            newBuckets[i] = nullptr;

        for (std::size_t i = 0; i < capacity; i++)
        {
            Entry *e = buckets[i];
            while (e != nullptr)
            {
                Entry *nextEntry = e->next;
                std::size_t idx = hashKey(e->key, newCapacity);
                e->next = newBuckets[idx];
                newBuckets[idx] = e;
                e = nextEntry;
            }
        }

        delete[] buckets;
        buckets = newBuckets;
        capacity = newCapacity;
    }

    // Non-copyable (owns raw memory)
    HashTable(const HashTable &);
    HashTable &operator=(const HashTable &);

public:
    HashTable() : buckets(nullptr), capacity(INITIAL_CAPACITY), count(0)
    {
        buckets = new Entry *[capacity];
        for (std::size_t i = 0; i < capacity; i++)
            buckets[i] = nullptr;
    }

    ~HashTable()
    {
        clear();
        delete[] buckets;
    }

    // Insert key -> value. Duplicate keys are allowed (they sit in the
    // same chain); callers that need unique keys check find() first.
    void insert(const std::string &key, V *value)
    {
        if (count + 1 > capacity * 3 / 4)
            rehash();

        std::size_t idx = hashKey(key, capacity);
        Entry *e = new Entry(key, value);
        e->next = buckets[idx];
        buckets[idx] = e;
        count++;
    }

    // Returns the first value stored under key, or nullptr.
    V *find(const std::string &key) const
    {
        Entry *e = buckets[hashKey(key, capacity)];
        while (e != nullptr)
        {
            if (e->key == key)
                return e->value;
            e = e->next;
        }
        return nullptr;
    }

    // Returns the first value under key for which pred(*value) is true.
    // Used when many items share a key (e.g. many borrow records per book).
    template <typename Pred>
    V *findIf(const std::string &key, Pred pred) const
    {
        Entry *e = buckets[hashKey(key, capacity)];
        while (e != nullptr)
        {
            if (e->key == key && pred(*(e->value)))
                return e->value;
            e = e->next;
        }
        return nullptr;
    }

    // Removes the entry (key, value). Returns true if it existed.
    bool remove(const std::string &key, V *value)
    {
        std::size_t idx = hashKey(key, capacity);
        Entry *e = buckets[idx];
        Entry *prev = nullptr;

        while (e != nullptr)
        {
            if (e->key == key && e->value == value)
            {
                if (prev == nullptr)
                    buckets[idx] = e->next;
                else
                    prev->next = e->next;
                delete e;
                count--;
                return true;
            }
            prev = e;
            e = e->next;
        }
        return false;
    }

    void clear()
    {
        for (std::size_t i = 0; i < capacity; i++)
        {
            Entry *e = buckets[i];
            while (e != nullptr)
            {
                Entry *tmp = e;
                e = e->next;
                delete tmp;
            }
            buckets[i] = nullptr;
        }
        count = 0;
    }

    std::size_t size() const { return count; }
};

#endif
