#ifndef BOOKLINKEDLIST_H
#define BOOKLINKEDLIST_H

#include "BookNode.h"
#include "ReservationQueue.h"
#include "HashTable.h"

class BookLinkedList
{
private:
    BookNode *head;
    BookNode *tail;

    // Hash index: Book ID -> node. Gives O(1) average search.
    // The linked list is only kept to preserve insertion order
    // for display and file saving.
    HashTable<BookNode> index;

    void clearAll();

public:
    BookLinkedList();
    ~BookLinkedList();

    bool addBook(Book newBook);
    void displayBooks(const ReservationQueue &reservationQueue) const;
    void searchBook(string bookId) const;
    void updateBook(string bookId);
    void deleteBook(string bookId);
    bool saveToFile(const string &filename) const;
    bool loadFromFile(const string &filename);
    Book *findBook(string bookId);
};

#endif