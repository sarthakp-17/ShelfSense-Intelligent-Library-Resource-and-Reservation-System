
#ifndef BORROWRECORDLINKEDLIST_H
#define BORROWRECORDLINKEDLIST_H

#include "BorrowRecordNode.h"
#include "HashTable.h"
#include <string>
using namespace std;

class BorrowRecordLinkedList
{
private:
    BorrowRecordNode *head;
    BorrowRecordNode *tail;

    // Hash index: Book ID -> record nodes of that book.
    // findActiveRecord() only scans the records of ONE book
    // instead of the whole list.
    HashTable<BorrowRecordNode> index;

public:
    BorrowRecordLinkedList();
    ~BorrowRecordLinkedList();

    bool addRecord(BorrowRecord newRecord);

    BorrowRecord *findActiveRecord(string bookId);

    void displayAllRecords() const;

    bool saveToFile(const string &filename) const;
    bool loadFromFile(const string &filename);
    bool returnRecord(string bookId);
    bool renewRecord(string bookId, string newDueDate);
};

#endif