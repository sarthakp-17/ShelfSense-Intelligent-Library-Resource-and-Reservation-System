#include "../include/BookLinkedList.h"
#include "../include/ReservationQueue.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

BookLinkedList::BookLinkedList()
{
    head = nullptr;
    tail = nullptr;
}

BookLinkedList::~BookLinkedList()
{
    clearAll();
}

void BookLinkedList::clearAll()
{
    BookNode *current = head;

    while (current != nullptr)
    {
        BookNode *temp = current;
        current = current->next;
        delete temp;
    }

    head = nullptr;
    tail = nullptr;
    index.clear();
}

// Average O(1): duplicate check via hash table, insert at tail.
bool BookLinkedList::addBook(Book newBook)
{
    if (index.find(newBook.getBookId()) != nullptr)
    {
        cout << "\nError: Book ID already exists!\n";
        return false;
    }

    BookNode *newNode = new BookNode(newBook);

    if (head == nullptr)
    {
        head = tail = newNode;
    }
    else
    {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }

    index.insert(newBook.getBookId(), newNode);
    return true;
}

// Average O(1) using hash table lookup.
void BookLinkedList::searchBook(string bookId) const
{
    BookNode *node = index.find(bookId);

    if (node != nullptr)
    {
        cout << "\nBook Found!\n";
        node->book.displayBook();
        return;
    }

    cout << "\nBook not found!\n";
}

// Average O(1) using hash table lookup.
Book *BookLinkedList::findBook(string bookId)
{
    BookNode *node = index.find(bookId);

    if (node != nullptr)
    {
        return &(node->book);
    }

    return nullptr;
}

void BookLinkedList::updateBook(string bookId)
{
    BookNode *node = index.find(bookId);

    if (node == nullptr)
    {
        cout << "\nBook not found! Cannot update.\n";
        return;
    }

    string newTitle;
    string newAuthor;
    string newCategory;

    cout << "\n========== UPDATE BOOK ==========\n";

    cout << "Enter new title: ";
    getline(cin >> ws, newTitle);

    cout << "Enter new author: ";
    getline(cin >> ws, newAuthor);

    cout << "Enter new category: ";
    getline(cin >> ws, newCategory);

    node->book.setTitle(newTitle);
    node->book.setAuthor(newAuthor);
    node->book.setCategory(newCategory);

    cout << "\nBook updated successfully!\n";
}

// Average O(1): find via hash, unlink via prev/next pointers.
void BookLinkedList::deleteBook(string bookId)
{
    if (head == nullptr)
    {
        cout << "\nNo books available to delete!\n";
        return;
    }

    BookNode *node = index.find(bookId);

    if (node == nullptr)
    {
        cout << "\nBook not found! Cannot delete.\n";
        return;
    }

    if (node->prev != nullptr)
        node->prev->next = node->next;
    else
        head = node->next;

    if (node->next != nullptr)
        node->next->prev = node->prev;
    else
        tail = node->prev;

    index.remove(bookId, node);
    delete node;

    cout << "\nBook deleted successfully!\n";
}

bool BookLinkedList::saveToFile(const string &filename) const
{
    ofstream file(filename);

    if (!file.is_open())
    {
        cout << "\nError: Could not open file for saving!\n";
        return false;
    }

    BookNode *current = head;

    while (current != nullptr)
    {
        file << current->book.getBookId() << "|"
             << current->book.getTitle() << "|"
             << current->book.getAuthor() << "|"
             << current->book.getCategory() << "|"
             << current->book.getStatus() << "\n";

        current = current->next;
    }

    file.close();
    return true;
}

bool BookLinkedList::loadFromFile(const string &filename)
{
    ifstream file(filename);

    if (!file.is_open())
    {
        // The file may not exist on the first run.
        return true;
    }

    string line;

    while (getline(file, line))
    {
        string fields[5];
        stringstream ss(line);
        bool valid = true;

        for (int i = 0; i < 5; i++)
        {
            if (!getline(ss, fields[i], '|'))
            {
                valid = false;
                break;
            }
        }

        // Reject incomplete records or extra fields.
        string extra;
        if (!valid || getline(ss, extra, '|'))
        {
            cout << "\nSkipping invalid book record.\n";
            continue;
        }

        // Prevent duplicate IDs while loading (O(1) hash lookup).
        bool duplicate = (index.find(fields[0]) != nullptr);

        if (duplicate)
        {
            cout << "\nSkipping duplicate Book ID: "
                 << fields[0] << "\n";
            continue;
        }

        Book newBook(
            fields[0],
            fields[1],
            fields[2],
            fields[3],
            fields[4]);

        addBook(newBook);
    }

    file.close();
    return true;
}

void BookLinkedList::displayBooks(
    const ReservationQueue &reservationQueue) const
{
    BookNode *current = head;

    while (current != nullptr)
    {
        current->book.displayBook();

        if (current->book.getStatus() == "Reserved")
        {
            Reservation reservation;

            if (reservationQueue.findReservationForBook(
                    current->book.getBookId(), reservation))
            {
                cout << "Reserved for Member ID: "
                     << reservation.getMemberId() << '\n';
            }
        }

        current = current->next;
    }
}