# ShelfSense-Intelligent-Library-Resource-and-Reservation-System
A digital library management system designed to make borrowing, returning, and tracking books simple and organized. Built using C++ and DSA to manage library operations efficientl.

## Search optimisation (Hashing)
Searching by Book ID / Member ID / Borrow record previously scanned a linked list (O(n)).
Each list now keeps a hash table index (`include/HashTable.h`, djb2 hash + separate chaining
+ auto-resize at load factor 0.75) giving **O(1) average** search, duplicate check and delete.
The linked list is retained only to preserve insertion order for display and file saving.
